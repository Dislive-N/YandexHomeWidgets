package ru.dislive.yandexhomewidgets

/** Offline Russian labels for common Yandex IoT API names and enum values. */
object ApiTextRu {
    private val exact = mapOf(
        "on" to "Включено", "off" to "Выключено", "true" to "Да", "false" to "Нет",
        "open" to "Открыто", "opened" to "Открыто", "closed" to "Закрыто",
        "locked" to "Заблокировано", "unlocked" to "Разблокировано",
        "detected" to "Обнаружено", "not_detected" to "Не обнаружено",
        "motion" to "Движение обнаружено", "no_motion" to "Движения нет",
        "online" to "В сети", "offline" to "Не в сети", "low" to "Низкий", "normal" to "Нормальный", "high" to "Высокий",
        "auto" to "Автоматически", "manual" to "Вручную", "heat" to "Обогрев", "cool" to "Охлаждение",
        "fan_only" to "Вентиляция", "dry" to "Осушение", "sleep" to "Ночной режим", "eco" to "Эко-режим",
        "idle" to "Ожидание", "running" to "Работает", "paused" to "Приостановлено", "error" to "Ошибка",
        "movie" to "Кино", "dinner" to "Ужин", "reading" to "Чтение", "rest" to "Отдых",
        "night" to "Ночь", "morning" to "Утро", "candle" to "Свеча", "party" to "Вечеринка",
        "neon" to "Неон", "alarm" to "Тревога", "alice" to "Алиса", "garland" to "Гирлянда",
        "ocean" to "Океан", "jungle" to "Джунгли", "fantasy" to "Фантазия", "siren" to "Сирена",
        "devices.types.light" to "Освещение", "devices.types.socket" to "Розетка",
        "devices.types.switch" to "Выключатель", "devices.types.sensor" to "Датчик",
        "devices.types.sensor.climate" to "Климатический датчик", "devices.types.sensor.motion" to "Датчик движения",
        "devices.types.sensor.open" to "Датчик открытия", "devices.types.sensor.water_leak" to "Датчик протечки",
        "devices.types.sensor.smoke" to "Датчик дыма", "devices.types.sensor.gas" to "Датчик газа",
        "devices.types.media_device.tv" to "Телевизор", "devices.types.media_device.tv_box" to "ТВ-приставка",
        "devices.types.cooking.kettle" to "Чайник", "devices.types.cooking.coffee_maker" to "Кофемашина",
        "devices.types.thermostat" to "Термостат", "devices.types.thermostat.ac" to "Кондиционер",
        "devices.types.openable.curtain" to "Шторы", "devices.types.openable.valve" to "Кран с приводом",
        "devices.types.openable.door_lock" to "Умный замок", "devices.types.vacuum_cleaner" to "Робот-пылесос",
        "devices.types.washing_machine" to "Стиральная машина", "devices.types.dishwasher" to "Посудомоечная машина",
        "devices.types.humidifier" to "Увлажнитель", "devices.types.purifier" to "Очиститель воздуха"
    )

    private val words = mapOf(
        "light" to "свет", "socket" to "розетка", "switch" to "выключатель", "sensor" to "датчик",
        "temperature" to "температура", "humidity" to "влажность", "pressure" to "давление",
        "battery" to "батарея", "level" to "уровень", "power" to "мощность", "voltage" to "напряжение",
        "current" to "ток", "illumination" to "освещённость", "motion" to "движение", "open" to "открытие",
        "water" to "вода", "leak" to "протечка", "smoke" to "дым", "gas" to "газ", "co2" to "CO₂",
        "fan" to "вентилятор", "speed" to "скорость", "mode" to "режим", "auto" to "авто",
        "manual" to "ручной", "heat" to "обогрев", "cool" to "охлаждение", "dry" to "осушение",
        "curtain" to "штора", "door" to "дверь", "lock" to "замок", "camera" to "камера",
        "speaker" to "колонка", "tv" to "телевизор", "vacuum" to "пылесос", "cleaner" to "уборщик",
        "washing" to "стиральная", "machine" to "машина", "dishwasher" to "посудомоечная",
        "kettle" to "чайник", "coffee" to "кофе", "maker" to "машина", "humidifier" to "увлажнитель",
        "purifier" to "очиститель", "online" to "в сети", "offline" to "не в сети", "unknown" to "неизвестно"
    )

    fun translate(value: String): String {
        val source = value.trim()
        if (source.isEmpty()) return source
        exact[source.lowercase()]?.let { return it }
        val normalized = source.lowercase()
            .removePrefix("devices.types.")
            .replace('.', '_').replace('-', '_')
            .replace(Regex("_+"), "_")
            .trim('_')
        exact[normalized]?.let { return it }
        val translated = normalized.split('_').filter(String::isNotBlank).map { token ->
            words[token] ?: token.replaceFirstChar { it.uppercase() }
        }
        return translated.joinToString(" ").replaceFirstChar { it.uppercase() }
    }
}
