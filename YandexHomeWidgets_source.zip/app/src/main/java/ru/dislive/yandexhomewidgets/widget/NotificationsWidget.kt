package ru.dislive.yandexhomewidgets.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import ru.dislive.yandexhomewidgets.data.HomeHistoryStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationsWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val changes = HomeHistoryStore.load(context).take(4)
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        provideContent {
            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(ColorProvider(Color(0xFF172238)))
                    .padding(12.dp),
                verticalAlignment = Alignment.Vertical.Top
            ) {
                Row(verticalAlignment = Alignment.Vertical.CenterVertically) {
                    Text(
                        "Уведомления",
                        modifier = GlanceModifier.defaultWeight(),
                        style = TextStyle(color = ColorProvider(Color.White), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        changes.size.toString(),
                        style = TextStyle(color = ColorProvider(Color(0xFFC7B2FF)), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(GlanceModifier.height(7.dp))
                if (changes.isEmpty()) {
                    Text(
                        "Новых событий пока нет. Здесь появятся изменения устройств и датчиков.",
                        style = TextStyle(color = ColorProvider(Color(0xFFC2CAD8)), fontSize = 11.sp)
                    )
                } else {
                    changes.forEachIndexed { index, change ->
                        Column(
                            modifier = GlanceModifier.fillMaxWidth()
                                .background(ColorProvider(Color(0xFF24334B)))
                                .padding(horizontal = 9.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.Vertical.CenterVertically) {
                                Text(
                                    change.title,
                                    modifier = GlanceModifier.defaultWeight(),
                                    maxLines = 1,
                                    style = TextStyle(color = ColorProvider(Color(0xFFE5D8FF)), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    timeFormat.format(Date(change.timestamp)),
                                    style = TextStyle(color = ColorProvider(Color(0xFF9FAFC4)), fontSize = 9.sp)
                                )
                            }
                            Text(
                                change.detail,
                                maxLines = 2,
                                style = TextStyle(color = ColorProvider(Color.White), fontSize = 10.sp)
                            )
                        }
                        if (index != changes.lastIndex) Spacer(GlanceModifier.height(5.dp))
                    }
                }
            }
        }
    }
}

class NotificationsWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = NotificationsWidget()
}
