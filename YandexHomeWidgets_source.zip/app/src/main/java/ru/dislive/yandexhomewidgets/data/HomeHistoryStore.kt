package ru.dislive.yandexhomewidgets.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HomeHistoryStore {
    private const val PREFS = "home_history"
    private const val KEY_ITEMS = "items"
    private const val MAX_ITEMS = 300

    @Synchronized
    fun append(context: Context, changes: List<HomeChange>) {
        if (changes.isEmpty()) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = try { JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val combined = JSONArray()
        val now = System.currentTimeMillis()
        changes.forEach { change ->
            combined.put(JSONObject()
                .put("kind", change.kind.name)
                .put("title", change.title)
                .put("detail", change.detail)
                .put("timestamp", now)
                .put("deviceId", change.deviceId ?: ""))
        }
        for (index in 0 until minOf(existing.length(), MAX_ITEMS - changes.size)) {
            combined.put(existing.optJSONObject(index) ?: continue)
        }
        prefs.edit().putString(KEY_ITEMS, combined.toString()).apply()
    }

    fun load(context: Context): List<HomeChange> {
        val raw = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        val array = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val kind = runCatching { HomeChangeKind.valueOf(item.optString("kind")) }.getOrDefault(HomeChangeKind.DEVICE)
            HomeChange(kind, item.optString("title"), item.optString("detail"), item.optLong("timestamp"), item.optString("deviceId").takeIf(String::isNotBlank))
        }
    }

    fun clear(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_ITEMS).apply()
    }
}
