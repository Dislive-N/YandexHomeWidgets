package ru.dislive.yandexhomewidgets.data

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import ru.dislive.yandexhomewidgets.MainActivity
import ru.dislive.yandexhomewidgets.R

/** User-side notification preferences. */
data class HomeNotificationOptions(
    val enabled: Boolean = true,
    val deviceChanges: Boolean = true,
    val capabilityChanges: Boolean = true,
    val sensorChanges: Boolean = true,
    val groupScenarioChanges: Boolean = true
)

object HomeNotificationSettings {
    private const val PREFS = "home_notification_settings"

    fun load(context: Context): HomeNotificationOptions {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return HomeNotificationOptions(
            enabled = p.getBoolean("enabled", true),
            deviceChanges = p.getBoolean("devices", true),
            capabilityChanges = p.getBoolean("capabilities", true),
            sensorChanges = p.getBoolean("sensors", true),
            groupScenarioChanges = p.getBoolean("groups_scenarios", true)
        )
    }

    fun save(context: Context, value: HomeNotificationOptions) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", value.enabled)
            .putBoolean("devices", value.deviceChanges)
            .putBoolean("capabilities", value.capabilityChanges)
            .putBoolean("sensors", value.sensorChanges)
            .putBoolean("groups_scenarios", value.groupScenarioChanges)
            .apply()
    }
}

enum class HomeChangeKind { DEVICE, CAPABILITY, SENSOR, GROUP_SCENARIO }
data class HomeChange(
    val kind: HomeChangeKind,
    val title: String,
    val detail: String,
    val timestamp: Long = System.currentTimeMillis(),
    val deviceId: String? = null
)

/**
 * Compares consecutive GET /v1.0/user/info responses. This is polling-based
 * change detection, not a subscription to Yandex's provider callback service.
 */
object HomeChangeDetector {
    private const val PREFS = "home_change_detector"
    private const val SNAPSHOT_KEY = "last_api_snapshot_v2"

    @Synchronized
    fun collect(context: Context, home: HomeData): List<HomeChange> {
        val current = try {
            JSONObject(home.apiSnapshot)
        } catch (_: Exception) {
            return emptyList()
        }
        if (current.length() == 0) return emptyList()

        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previousText = prefs.getString(SNAPSHOT_KEY, null)
        // Save only a successfully parsed response. The first response is a baseline.
        prefs.edit().putString(SNAPSHOT_KEY, current.toString()).apply()
        if (previousText.isNullOrBlank()) return emptyList()
        val previous = try { JSONObject(previousText) } catch (_: Exception) { return emptyList() }

        val result = mutableListOf<HomeChange>()
        diffEntities(previous, current, "devices", "Устройство", HomeChangeKind.DEVICE, result,
            ignoredFields = setOf("capabilities", "properties"))
        diffEntities(previous, current, "rooms", "Комната", HomeChangeKind.DEVICE, result)
        diffEntities(previous, current, "households", "Дом", HomeChangeKind.DEVICE, result)
        diffEntities(previous, current, "groups", "Группа", HomeChangeKind.GROUP_SCENARIO, result,
            ignoredFields = setOf("capabilities"))
        diffEntities(previous, current, "scenarios", "Сценарий", HomeChangeKind.GROUP_SCENARIO, result)

        val oldDevices = indexById(previous.optJSONArray("devices"))
        val newDevices = indexById(current.optJSONArray("devices"))
        (oldDevices.keys intersect newDevices.keys).forEach { id ->
            val old = oldDevices[id] ?: return@forEach
            val fresh = newDevices[id] ?: return@forEach
            diffFeatures(old.optJSONArray("capabilities"), fresh.optJSONArray("capabilities"),
                old.optString("name", fresh.optString("name", "Устройство")),
                "умение", HomeChangeKind.CAPABILITY, result, deviceId = id)
            diffFeatures(old.optJSONArray("properties"), fresh.optJSONArray("properties"),
                old.optString("name", fresh.optString("name", "Устройство")),
                "показатель", HomeChangeKind.SENSOR, result, deviceId = id)
        }

        // Groups can expose aggregate states as well as membership and metadata.
        val oldGroups = indexById(previous.optJSONArray("groups"))
        val newGroups = indexById(current.optJSONArray("groups"))
        (oldGroups.keys intersect newGroups.keys).forEach { id ->
            val old = oldGroups[id] ?: return@forEach
            val fresh = newGroups[id] ?: return@forEach
            diffFeatures(old.optJSONArray("capabilities"), fresh.optJSONArray("capabilities"),
                fresh.optString("name", "Группа"), "умение группы", HomeChangeKind.CAPABILITY, result)
        }

        val unique = result.distinctBy { "${it.kind}|${it.title}|${it.detail}|${it.deviceId.orEmpty()}" }
        HomeHistoryStore.append(context, unique)
        return unique
    }

    private fun diffEntities(
        oldRoot: JSONObject,
        newRoot: JSONObject,
        collectionName: String,
        label: String,
        kind: HomeChangeKind,
        output: MutableList<HomeChange>,
        ignoredFields: Set<String> = emptySet()
    ) {
        val oldItems = indexById(oldRoot.optJSONArray(collectionName))
        val newItems = indexById(newRoot.optJSONArray(collectionName))
        (newItems.keys - oldItems.keys).forEach { id ->
            val item = newItems[id] ?: return@forEach
            output += HomeChange(kind, "Добавлен объект: $label", item.optString("name", label), deviceId = if (collectionName == "devices") id else null)
        }
        (oldItems.keys - newItems.keys).forEach { id ->
            val item = oldItems[id] ?: return@forEach
            output += HomeChange(kind, "Удалён объект: $label", item.optString("name", label), deviceId = if (collectionName == "devices") id else null)
        }
        (oldItems.keys intersect newItems.keys).forEach { id ->
            val old = oldItems[id] ?: return@forEach
            val fresh = newItems[id] ?: return@forEach
            val oldComparable = withoutFields(old, ignoredFields + setOf("last_updated", "request_id"))
            val newComparable = withoutFields(fresh, ignoredFields + setOf("last_updated", "request_id"))
            if (normalizedJson(oldComparable) != normalizedJson(newComparable)) {
                val oldName = old.optString("name", label)
                val newName = fresh.optString("name", label)
                val oldState = old.optString("state")
                val newState = fresh.optString("state")
                val detail = when {
                    oldName != newName -> "$oldName → $newName"
                    collectionName == "devices" && oldState.isNotBlank() && newState.isNotBlank() && oldState != newState -> "$newName: $oldState → $newState"
                    else -> newName
                }
                val title = when (collectionName) {
                    "devices" -> "Изменились данные устройства"
                    "rooms" -> "Изменилась комната или её состав"
                    "households" -> "Изменились данные дома"
                    "groups" -> "Изменились данные группы"
                    "scenarios" -> "Изменились данные сценария"
                    else -> "Изменился объект"
                }
                output += HomeChange(kind, title, detail, deviceId = if (collectionName == "devices") id else null)
            }
        }
    }

    private fun diffFeatures(
        oldArray: JSONArray?,
        newArray: JSONArray?,
        deviceName: String,
        featureLabel: String,
        kind: HomeChangeKind,
        output: MutableList<HomeChange>,
        deviceId: String? = null
    ) {
        val oldFeatures = indexFeatures(oldArray)
        val newFeatures = indexFeatures(newArray)
        (newFeatures.keys - oldFeatures.keys).forEach { key ->
            output += HomeChange(kind, "Обновилась конфигурация", "$deviceName: добавлено $featureLabel ${key.substringAfter('|')}", deviceId = deviceId)
        }
        (oldFeatures.keys - newFeatures.keys).forEach { key ->
            output += HomeChange(kind, "Обновилась конфигурация", "$deviceName: удалено $featureLabel ${key.substringAfter('|')}", deviceId = deviceId)
        }
        (oldFeatures.keys intersect newFeatures.keys).forEach { key ->
            val old = oldFeatures[key] ?: return@forEach
            val fresh = newFeatures[key] ?: return@forEach
            if (normalizedJson(withoutFields(old, setOf("state", "last_updated"))) !=
                normalizedJson(withoutFields(fresh, setOf("state", "last_updated")))) {
                output += HomeChange(HomeChangeKind.DEVICE, "Обновилась конфигурация", "$deviceName: изменены параметры $featureLabel ${key.substringAfter('|')}", deviceId = deviceId)
            }
            val oldState = old.optJSONObject("state")
            val newState = fresh.optJSONObject("state")
            if (normalizedJsonNullable(oldState) != normalizedJsonNullable(newState)) {
                val instance = newState?.optString("instance", key.substringAfter('|'))
                    ?: oldState?.optString("instance", key.substringAfter('|'))
                    ?: key.substringAfter('|')
                val description = if (newState == null) "$instance: значение больше недоступно"
                    else describeValue(instance, newState.opt("value"), kind)
                output += HomeChange(
                    kind,
                    if (kind == HomeChangeKind.SENSOR) "Изменение датчика" else "Изменение состояния",
                    "$deviceName: $description",
                    deviceId = deviceId
                )
            }
        }
    }

    private fun describeValue(instance: String, value: Any?, kind: HomeChangeKind): String {
        val raw = when (value) {
            null, JSONObject.NULL -> "нет данных"
            is Boolean -> if (value) "да" else "нет"
            else -> value.toString()
        }
        if (kind == HomeChangeKind.CAPABILITY) {
            return when (instance) {
                "on" -> if (value == true) "включено" else "выключено"
                "brightness" -> "яркость $raw%"
                "temperature_k" -> "цветовая температура $raw К"
                "temperature" -> "температура $raw"
                "color" -> "цвет изменён: $raw"
                "program", "thermostat", "thermostat_mode" -> "режим: $raw"
                "fan_speed" -> "скорость вентилятора: $raw"
                "volume" -> "громкость: $raw"
                "channel" -> "канал: $raw"
                "input_source" -> "источник сигнала: $raw"
                else -> "$instance: $raw"
            }
        }
        val propertyName = when (instance) {
            "temperature" -> "температура"
            "humidity" -> "влажность"
            "pressure" -> "давление"
            "battery_level" -> "заряд батареи"
            "voltage" -> "напряжение"
            "current" -> "ток"
            "power" -> "мощность"
            "illumination" -> "освещённость"
            "co2_level" -> "CO₂"
            "pm1_density" -> "PM1"
            "pm2.5_density" -> "PM2.5"
            "pm10_density" -> "PM10"
            "open" -> "дверь/окно"
            "motion" -> "движение"
            "vibration" -> "вибрация"
            "water_leak" -> "протечка"
            "smoke" -> "дым"
            "gas" -> "газ"
            else -> instance
        }
        val valueLabel = when (raw.lowercase()) {
            "motion", "detected", "true" -> if (instance == "motion") "обнаружено" else raw
            "no_motion", "not_detected", "false" -> if (instance == "motion") "не обнаружено" else raw
            "open" -> "открыто"
            "closed" -> "закрыто"
            else -> raw
        }
        val unit = when (instance) {
            "temperature" -> "°C"
            "humidity", "battery_level" -> "%"
            "illumination" -> " лк"
            "co2_level" -> " ppm"
            else -> ""
        }
        return "$propertyName: $valueLabel$unit"
    }

    private fun indexById(array: JSONArray?): Map<String, JSONObject> {
        val result = linkedMapOf<String, JSONObject>()
        if (array == null) return result
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id")
            if (id.isNotBlank()) result[id] = item
        }
        return result
    }

    private fun indexFeatures(array: JSONArray?): Map<String, JSONObject> {
        val result = linkedMapOf<String, JSONObject>()
        if (array == null) return result
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val state = item.optJSONObject("state")
            val parameters = item.optJSONObject("parameters")
            val instance = state?.optString("instance")?.takeIf { it.isNotBlank() }
                ?: parameters?.optString("instance").orEmpty()
            val key = "${item.optString("type")}|$instance"
            result[key] = item
        }
        return result
    }

    private fun withoutFields(source: JSONObject, fields: Set<String>): JSONObject {
        val result = JSONObject(source.toString())
        fields.forEach { result.remove(it) }
        return result
    }

    private fun normalizedJsonNullable(value: JSONObject?): String =
        value?.let(::normalizedJson) ?: "<null>"

    /** Sort object keys and primitive arrays so server key ordering doesn't create false alerts. */
    private fun normalizedJson(value: Any?): String = when (value) {
        is JSONObject -> {
            val keys = value.keys().asSequence().toList().sorted()
            val normalized = JSONObject()
            keys.forEach { key -> normalized.put(key, normalizedValue(value.opt(key))) }
            normalized.toString()
        }
        is JSONArray -> {
            val items = (0 until value.length()).map { value.opt(it) }
            val normalizedItems = if (items.all { it == null || it === JSONObject.NULL || it !is JSONObject && it !is JSONArray }) {
                items.sortedBy { it?.toString().orEmpty() }
            } else items
            val normalized = JSONArray()
            normalizedItems.forEach { normalized.put(normalizedValue(it)) }
            normalized.toString()
        }
        else -> value?.toString().orEmpty()
    }

    private fun normalizedValue(value: Any?): Any? = when (value) {
        is JSONObject -> JSONObject(normalizedJson(value))
        is JSONArray -> JSONArray(normalizedJson(value))
        else -> value
    }
}

object HomeNotificationCenter {
    private const val CHANNEL_ID = "home_state_changes"
    private const val NOTIFICATION_ID = 4107

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID,
                "Изменения умного дома",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Изменения состояний устройств, датчиков, групп и сценариев" })
        }
    }

    fun showChanges(context: Context, changes: List<HomeChange>) {
        if (changes.isEmpty()) return
        val options = HomeNotificationSettings.load(context)
        if (!options.enabled) return
        val visible = changes.filter { change ->
            when (change.kind) {
                HomeChangeKind.DEVICE -> options.deviceChanges
                HomeChangeKind.CAPABILITY -> options.capabilityChanges
                HomeChangeKind.SENSOR -> options.sensorChanges
                HomeChangeKind.GROUP_SCENARIO -> options.groupScenarioChanges
            }
        }
        if (visible.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return

        createChannel(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(
            context, NOTIFICATION_ID, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val lines = visible.take(6).map { "${it.title}: ${it.detail}" }
        val overflow = visible.size - lines.size
        val text = (lines + if (overflow > 0) listOf("И ещё $overflow изменений") else emptyList()).joinToString("\n")
        val notification = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_home)
            .setContentTitle("Изменения в умном доме")
            .setContentText(visible.first().detail)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setNumber(visible.size)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }
    fun showAutomationNotification(context: Context, title: String, message: String) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "scenario_notifications"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(channelId) == null) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Уведомления сценариев", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Сообщения, отправляемые локальными сценариями умного дома"
            })
        }
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(context, 4199, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(context, channelId) else Notification.Builder(context)
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification
            .setSmallIcon(R.drawable.ic_home)
            .setContentTitle(title.ifBlank { "Умный дом" })
            .setContentText(message.ifBlank { "Сценарий выполнен" })
            .setStyle(Notification.BigTextStyle().bigText(message.ifBlank { "Сценарий выполнен" }))
            .setContentIntent(pendingIntent).setAutoCancel(true).build())
    }

}
