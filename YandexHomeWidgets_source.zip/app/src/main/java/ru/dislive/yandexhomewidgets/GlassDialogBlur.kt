package ru.dislive.yandexhomewidgets

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogWindowProvider

@Composable
fun ApplyGlassDialogBackdropBlur() {
    val view = LocalView.current
    val density = LocalDensity.current
    val window = (view.parent as? DialogWindowProvider)?.window
    val radius = with(density) { 24.dp.roundToPx() }
    DisposableEffect(window, radius) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && window != null) {
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            window.setBackgroundBlurRadius(radius)
            val params = window.attributes
            params.dimAmount = 0.22f
            window.attributes = params
        } else if (window != null) {
            window.setBackgroundDrawable(ColorDrawable(0x66070A12))
        }
        onDispose {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && window != null) {
                window.setBackgroundBlurRadius(0)
                window.clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            }
        }
    }
}
