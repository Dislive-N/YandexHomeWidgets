package ru.dislive.yandexhomewidgets

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.dislive.yandexhomewidgets.data.AutomationAction
import ru.dislive.yandexhomewidgets.data.AutomationActionType
import ru.dislive.yandexhomewidgets.data.AutomationCondition
import ru.dislive.yandexhomewidgets.data.AutomationConditionType
import ru.dislive.yandexhomewidgets.data.GlobalVariable
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.LocationWeatherService
import android.location.Location
import ru.dislive.yandexhomewidgets.data.LocalAutomation
import ru.dislive.yandexhomewidgets.data.SmartAdvisor
import ru.dislive.yandexhomewidgets.data.SmartSuggestion
import java.util.UUID
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material3.Divider

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ScenarioCenterScreen(
    devices: List<HomeDevice>,
    cloudScenarios: List<HomeScenario>,
    automations: List<LocalAutomation>,
    variables: List<GlobalVariable>,
    isBusy: Boolean,
    onSaveAutomation: (LocalAutomation) -> Unit,
    onDeleteAutomation: (String) -> Unit,
    onToggleAutomation: (String, Boolean) -> Unit,
    onRunAutomation: (String) -> Unit,
    onSaveVariable: (GlobalVariable) -> Unit,
    onDeleteVariable: (String) -> Unit,
    onRunCloudScenario: (HomeScenario) -> Unit,
    onRequestCurrentLocation: ((Location) -> Unit) -> Unit,
    onOpenBackgroundLocationSettings: () -> Unit,
    cardSize: String = "normal"
) {
    val context = LocalContext.current
    val suggestions = remember(devices) { SmartAdvisor.suggestions(context, devices) }
    val automationIdeas = remember(devices) { buildSmartAutomationIdeas(devices) }
    var editorOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<LocalAutomation?>(null) }
    var variablesOpen by remember { mutableStateOf(false) }
    var ideasOpen by remember { mutableStateOf(false) }
    var infoAutomation by remember { mutableStateOf<LocalAutomation?>(null) }
    var selectedAutomationCategory by remember { mutableStateOf("Все") }
    var selectedCloudCategory by remember { mutableStateOf("Все") }
    val visibleAutomations = remember(automations, selectedAutomationCategory) {
        if (selectedAutomationCategory == "Все") automations else automations.filter { automationCategory(it.iconKey, it.name) == selectedAutomationCategory }
    }
    val visibleCloudScenarios = remember(cloudScenarios, selectedCloudCategory) {
        if (selectedCloudCategory == "Все") cloudScenarios else cloudScenarios.filter { automationCategory(scenarioIconKind(it.name), it.name) == selectedCloudCategory }
    }
    val cardPadding = when (cardSize) { "small" -> 9.dp; "large" -> 18.dp; else -> 13.dp }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Сценарии и автоматизации", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Создавай собственные правила: устройство, датчик, время или глобальная переменная запускают нужные действия. Эти правила хранятся на телефоне.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f)
                )
                Text("В фоне правила проверяются системной задачей примерно раз в 15 минут. После закрытия окна приложения проверка продолжает работать, но Android может её задерживать. После принудительной остановки приложения в настройках Android фоновые задачи блокируются до следующего запуска.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { editing = null; editorOpen = true }, modifier = Modifier.weight(1f)) { Text("＋ Создать") }
                    OutlinedButton(onClick = { variablesOpen = true }, modifier = Modifier.weight(1f)) { Text("{} Переменные") }
                }
                OutlinedButton(onClick = { ideasOpen = true }, enabled = automationIdeas.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                    Text("✦ ИИ · предложить сценарии для моих устройств")
                }
                Text("Умный подбор учитывает подключённые устройства и их возможности локально на телефоне. Это не облачная генеративная ИИ-модель: данные устройств никуда не отправляются, а предложенные правила добавляются выключенными.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }


        if (automations.any { rule -> rule.conditions.any { it.type == AutomationConditionType.LOCATION_ZONE || (it.type == AutomationConditionType.WEATHER && it.useCurrentLocation) } }) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f))) {
                Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Работа местоположения в фоне", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (LocationWeatherService.hasBackgroundLocationPermission(context)) "Доступ к местоположению в фоне выдан. Геозоны и погода по текущей точке могут проверяться фоновой задачей; Android всё равно может задерживать запуск."
                        else "Для геозон и погоды по текущему местоположению открой настройки приложения → Разрешения → Местоположение → Разрешить всегда. Android может задерживать фоновые проверки.",
                        fontSize = 10.sp
                    )
                    if (!LocationWeatherService.hasBackgroundLocationPermission(context)) {
                        OutlinedButton(onClick = onOpenBackgroundLocationSettings, modifier = Modifier.fillMaxWidth()) { Text("Настроить доступ к местоположению") }
                    }
                }
            }
        }

        if (suggestions.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Умный помощник", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Локальный алгоритм сравнивает новые измерения с обычным уровнем датчика и ищет необычные отклонения.", fontSize = 11.sp)
                    suggestions.forEach { suggestion -> SuggestionRow(suggestion) }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))) {
                Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Умный помощник", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("Алгоритм накопит историю измерений и покажет подсказки, когда заметит необычные изменения. Для анализа нужно несколько сохранённых измерений.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Мои автоматизации", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(automations.size.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Все", "Освещение", "Климат", "Безопасность", "Другое").forEach { category ->
                FilterChip(selected = selectedAutomationCategory == category, onClick = { selectedAutomationCategory = category }, label = { Text(category, fontSize = 10.sp) })
            }
        }
        if (automations.isEmpty()) {
            EmptyScenarioCard("Пока нет автоматизаций. Создай правило и добавь хотя бы одно условие и действие.")
        } else if (visibleAutomations.isEmpty()) {
            EmptyScenarioCard("В этой категории пока нет сценариев.")
        }
        visibleAutomations.forEach { automation ->
            Card(modifier = Modifier.animateContentSize(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().padding(cardPadding), verticalArrangement = Arrangement.spacedBy(if (cardSize == "small") 5.dp else 7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        IconTile(automation.iconKey, Modifier.size(48.dp), iconSize = 28.dp, active = automation.enabled)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(automation.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("${automation.conditions.size} усл. · ${automation.actions.size} действ. · ${if (automation.matchAllConditions) "все условия" else "любое условие"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                        }
                        TextButton(onClick = { infoAutomation = automation }, modifier = Modifier.size(34.dp), contentPadding = PaddingValues(0.dp)) { Text("i", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
                        Switch(checked = automation.enabled, onCheckedChange = { onToggleAutomation(automation.id, it) })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Button(onClick = { onRunAutomation(automation.id) }, enabled = !isBusy, modifier = Modifier.weight(1f)) { Text("▶ Запустить", fontSize = 11.sp) }
                        OutlinedButton(onClick = { editing = automation; editorOpen = true }, modifier = Modifier.weight(1f)) { Text("Изменить", fontSize = 11.sp) }
                        TextButton(onClick = { onDeleteAutomation(automation.id) }) { Text("Удалить", fontSize = 11.sp) }
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Сценарии Яндекса", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(visibleCloudScenarios.size.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
        }
        Text("Это сценарии, уже созданные в приложении «Дом с Алисой». Их можно запускать отсюда.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Все", "Освещение", "Климат", "Безопасность", "Другое").forEach { category ->
                FilterChip(selected = selectedCloudCategory == category, onClick = { selectedCloudCategory = category }, label = { Text(category, fontSize = 10.sp) })
            }
        }
        if (cloudScenarios.isEmpty()) EmptyScenarioCard("Сценарии Яндекса не найдены.")
        else if (visibleCloudScenarios.isEmpty()) EmptyScenarioCard("В этой категории пока нет сценариев Яндекса.")
        visibleCloudScenarios.forEach { scenario ->
            Card(modifier = Modifier.animateContentSize(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillMaxWidth().padding(cardPadding), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconTile(scenarioIconKind(scenario.name), Modifier.size(if (cardSize == "small") 40.dp else 46.dp), iconSize = if (cardSize == "small") 23.dp else 27.dp, active = scenario.isActive)
                    Column(Modifier.weight(1f)) {
                        Text(scenario.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Сценарий Яндекса", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    }
                    Button(onClick = { onRunCloudScenario(scenario) }, enabled = !isBusy) { Text("▶") }
                }
            }
        }
    }

    infoAutomation?.let { detail ->
        Dialog(onDismissRequest = { infoAutomation = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.78f), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ApplyGlassDialogBackdropBlur()
                    Text(detail.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("УСЛОВИЯ", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    Text(detail.conditions.joinToString(if (detail.matchAllConditions) " И " else " ИЛИ ") { conditionDescription(it, devices) }, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.14f))
                    Text("ДЕЙСТВИЯ", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.secondary)
                    Text(detail.actions.joinToString(separator = "\n") { "• " + actionDescription(it, devices, variables, cloudScenarios) }, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    Button(onClick = { infoAutomation = null }, modifier = Modifier.fillMaxWidth()) { Text("Закрыть") }
                }
            }
        }
    }
    if (editorOpen) {
        LocalAutomationEditor(
            initial = editing,
            devices = devices,
            cloudScenarios = cloudScenarios,
            variables = variables,
            onRequestCurrentLocation = onRequestCurrentLocation,
            onDismiss = { editorOpen = false; editing = null },
            onSave = { onSaveAutomation(it); editorOpen = false; editing = null }
        )
    }
    if (ideasOpen) {
        Dialog(onDismissRequest = { ideasOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(Modifier.fillMaxWidth(0.94f).fillMaxSize(0.78f), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxSize()) {
                    ApplyGlassDialogBackdropBlur()
                    Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF5B43A6), Color(0xFF277E9B)))).padding(17.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Идеи для твоих устройств", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        Text("Предлагаемые сценарии", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        if (automationIdeas.isEmpty()) Text("Пока не хватает совместимых устройств для готовых сценариев.", fontSize = 12.sp)
                        automationIdeas.forEach { idea ->
                            val alreadyAdded = automations.any { current -> current.name.equals(idea.name, ignoreCase = true) }
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
                                Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text(idea.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(automationIdeaDescription(idea, devices), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                    Button(onClick = { onSaveAutomation(idea.copy(enabled = false)); ideasOpen = false }, enabled = !alreadyAdded, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (alreadyAdded) "Уже добавлен" else "Добавить отключённым")
                                    }
                                }
                            }
                        }
                    }
                    TextButton(onClick = { ideasOpen = false }, modifier = Modifier.align(Alignment.End).padding(10.dp)) { Text("Закрыть") }
                }
            }
        }
    }

    if (variablesOpen) {
        GlobalVariablesDialog(
            variables = variables,
            onDismiss = { variablesOpen = false },
            onSave = onSaveVariable,
            onDelete = onDeleteVariable
        )
    }
}

@Composable
private fun SuggestionRow(suggestion: SmartSuggestion) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SmartGlyph("sparkles", Modifier.size(17.dp), MaterialTheme.colorScheme.primary)
            Text(suggestion.title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
        Text(suggestion.detail, fontSize = 11.sp)
    }
}

@Composable
private fun EmptyScenarioCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
        Text(message, Modifier.fillMaxWidth().padding(14.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LocalAutomationEditor(
    initial: LocalAutomation?,
    devices: List<HomeDevice>,
    cloudScenarios: List<HomeScenario>,
    variables: List<GlobalVariable>,
    onRequestCurrentLocation: ((Location) -> Unit) -> Unit,
    onDismiss: () -> Unit,
    onSave: (LocalAutomation) -> Unit
) {
    val context = LocalContext.current
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    var matchAll by remember(initial?.id) { mutableStateOf(initial?.matchAllConditions ?: true) }
    var conditions by remember(initial?.id) { mutableStateOf(initial?.conditions.orEmpty()) }
    var actions by remember(initial?.id) { mutableStateOf(initial?.actions.orEmpty()) }
    var cooldown by remember(initial?.id) { mutableStateOf((initial?.cooldownMinutes ?: 2).toString()) }
    var iconKey by remember(initial?.id) { mutableStateOf(initial?.iconKey ?: scenarioIconKind(initial?.name.orEmpty())) }

    var conditionDialog by remember { mutableStateOf(false) }
    var actionDialog by remember { mutableStateOf(false) }
    var conditionType by remember { mutableStateOf(AutomationConditionType.DEVICE_POWER) }
    var conditionDevice by remember { mutableStateOf(devices.firstOrNull()?.id.orEmpty()) }
    var conditionProperty by remember { mutableStateOf(devices.firstOrNull()?.properties?.firstOrNull()?.instance ?: "temperature") }
    var conditionOperator by remember { mutableStateOf(">") }
    var conditionValue by remember { mutableStateOf("true") }
    var conditionVariable by remember { mutableStateOf(variables.firstOrNull()?.name.orEmpty()) }
    var timeStart by remember { mutableStateOf("22:00") }
    var timeEnd by remember { mutableStateOf("07:00") }
    var weatherLat by remember { mutableStateOf("") }
    var weatherLon by remember { mutableStateOf("") }
    var weatherMetric by remember { mutableStateOf("temperature_2m") }
    var weatherUseCurrentLocation by remember(initial?.id) { mutableStateOf(initial?.conditions?.firstOrNull { it.type == AutomationConditionType.WEATHER }?.useCurrentLocation ?: true) }
    var weatherLocationStatus by remember(initial?.id) { mutableStateOf("Местоположение будет определяться автоматически") }
    var zoneLat by remember { mutableStateOf("") }
    var zoneLon by remember { mutableStateOf("") }
    var zoneRadius by remember { mutableStateOf("250") }
    var zoneInside by remember { mutableStateOf(true) }
    var zoneMapOpen by remember { mutableStateOf(false) }

    fun defaultDeviceActionType(device: HomeDevice?): String = when {
        device?.canToggle == true -> AutomationActionType.DEVICE_POWER
        device?.canDim == true -> AutomationActionType.BRIGHTNESS
        device?.colorCapability?.let { (it.colorModel ?: it.instance) in setOf("hsv", "rgb") } == true -> AutomationActionType.COLOR_HSV
        device?.modeCapabilities?.isNotEmpty() == true -> AutomationActionType.MODE
        else -> AutomationActionType.DEVICE_POWER
    }
    val firstActionDevice = devices.firstOrNull { it.canToggle || it.canDim || it.colorCapability?.let { cap -> (cap.colorModel ?: cap.instance) in setOf("hsv", "rgb") } == true || it.modeCapabilities.isNotEmpty() }
    var actionDevice by remember { mutableStateOf(firstActionDevice?.id.orEmpty()) }
    var actionType by remember { mutableStateOf(defaultDeviceActionType(firstActionDevice)) }
    var actionEnabled by remember { mutableStateOf(true) }
    var actionBrightness by remember { mutableStateOf("50") }
    var actionVariable by remember { mutableStateOf(variables.firstOrNull()?.name.orEmpty()) }
    var actionVariableValue by remember { mutableStateOf("true") }
    var actionScenario by remember { mutableStateOf(cloudScenarios.firstOrNull()?.id.orEmpty()) }
    var actionColorHue by remember { mutableStateOf(210) }
    var actionModeInstance by remember { mutableStateOf("") }
    var actionModeValue by remember { mutableStateOf("") }
    var actionDelaySeconds by remember { mutableStateOf("5") }
    var actionNotificationTitle by remember { mutableStateOf("Умный дом") }
    var actionNotificationMessage by remember { mutableStateOf("Сценарий выполнен") }

    val deviceOptions = devices.map { it.id to "${it.name} · ${it.room}" }
    val powerDeviceOptions = devices.filter { it.canToggle }.map { it.id to "${it.name} · ${it.room}" }
    val dimmableDeviceOptions = devices.filter { it.canDim }.map { it.id to "${it.name} · ${it.room}" }
    val colorDeviceOptions = devices.filter { device ->
        val capability = device.colorCapability
        capability != null && (capability.colorModel ?: capability.instance) in setOf("hsv", "rgb")
    }.map { it.id to "${it.name} · ${it.room}" }
    val modeDeviceOptions = devices.filter { it.modeCapabilities.isNotEmpty() }.map { it.id to "${it.name} · ${it.room}" }
    val controlDeviceOptions = devices.filter { it.canToggle || it.canDim || it.colorCapability?.let { cap -> (cap.colorModel ?: cap.instance) in setOf("hsv", "rgb") } == true || it.modeCapabilities.isNotEmpty() }
        .map { it.id to "${it.name} · ${it.room}" }
    val selectedActionDevice = devices.firstOrNull { it.id == actionDevice }
    val availableActionTypes = buildList {
        if (selectedActionDevice?.canToggle == true) add(AutomationActionType.DEVICE_POWER to "Питание")
        if (selectedActionDevice?.canDim == true) add(AutomationActionType.BRIGHTNESS to "Яркость")
        val colorCapability = selectedActionDevice?.colorCapability
        if (colorCapability != null && (colorCapability.colorModel ?: colorCapability.instance) in setOf("hsv", "rgb")) {
            add(AutomationActionType.COLOR_HSV to "Цвет")
        }
        if (selectedActionDevice?.modeCapabilities?.isNotEmpty() == true) add(AutomationActionType.MODE to "Режим")
    }
    val selectedModeCapabilities = selectedActionDevice?.modeCapabilities.orEmpty()
    val selectedModeOptions = selectedModeCapabilities.firstOrNull { it.instance == actionModeInstance }?.modeOptions.orEmpty().map { it to it }
    val sensorDeviceOptions = devices.filter { device -> device.properties.any { it.value is Number } }
        .map { it.id to "${it.name} · ${it.room}" }
    val propertyOptions = devices.firstOrNull { it.id == conditionDevice }?.properties
        ?.filter { it.value is Number && it.instance.isNotBlank() }
        ?.map { it.instance }.orEmpty().distinct().map { it to propertyLabel(it) }
    val variableOptions = variables.map { it.name to it.name }

    val latestActions = rememberUpdatedState(actions)
    val reorderThreshold = with(LocalDensity.current) { 46.dp.toPx() }

    fun appendCondition() {
        val valid = when (conditionType) {
            AutomationConditionType.DEVICE_POWER -> conditionDevice.isNotBlank()
            AutomationConditionType.SENSOR_VALUE -> conditionDevice.isNotBlank() && conditionValue.toDoubleOrNull() != null
            AutomationConditionType.GLOBAL_VARIABLE -> conditionVariable.isNotBlank() && conditionValue.isNotBlank()
            AutomationConditionType.TIME_WINDOW -> timeStart.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d")) && timeEnd.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))
            AutomationConditionType.TIME_AT -> timeStart.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))
            AutomationConditionType.WEATHER -> conditionValue.toDoubleOrNull() != null && (weatherUseCurrentLocation || (weatherLat.toDoubleOrNull()?.let { it in -90.0..90.0 } == true && weatherLon.toDoubleOrNull()?.let { it in -180.0..180.0 } == true))
            AutomationConditionType.LOCATION_ZONE -> zoneLat.toDoubleOrNull()?.let { it in -90.0..90.0 } == true && zoneLon.toDoubleOrNull()?.let { it in -180.0..180.0 } == true && (zoneRadius.toIntOrNull() ?: 0) in 50..5000
            else -> false
        }
        if (!valid) return
        val condition = when (conditionType) {
            AutomationConditionType.DEVICE_POWER -> AutomationCondition(type = conditionType, deviceId = conditionDevice, value = conditionValue)
            AutomationConditionType.SENSOR_VALUE -> AutomationCondition(type = conditionType, deviceId = conditionDevice, property = conditionProperty, operator = conditionOperator, value = conditionValue)
            AutomationConditionType.GLOBAL_VARIABLE -> AutomationCondition(type = conditionType, variableName = conditionVariable.trim(), operator = conditionOperator, value = conditionValue)
            AutomationConditionType.TIME_WINDOW -> AutomationCondition(type = conditionType, startTime = timeStart, endTime = timeEnd)
            AutomationConditionType.TIME_AT -> AutomationCondition(type = conditionType, startTime = timeStart)
            AutomationConditionType.WEATHER -> AutomationCondition(
                type = conditionType,
                property = weatherMetric,
                operator = conditionOperator,
                value = conditionValue,
                latitude = weatherLat.toDoubleOrNull() ?: 0.0,
                longitude = weatherLon.toDoubleOrNull() ?: 0.0,
                useCurrentLocation = weatherUseCurrentLocation
            )
            AutomationConditionType.LOCATION_ZONE -> AutomationCondition(type = conditionType, latitude = zoneLat.toDouble(), longitude = zoneLon.toDouble(), radiusMeters = zoneRadius.toInt().coerceIn(50, 5000), insideZone = zoneInside)
            else -> return
        }
        conditions = conditions + condition
        conditionDialog = false
    }

    fun appendAction() {
        val valid = when (actionType) {
            AutomationActionType.DEVICE_POWER -> actionDevice.isNotBlank()
            AutomationActionType.BRIGHTNESS -> actionDevice.isNotBlank() && actionBrightness.toIntOrNull() != null
            AutomationActionType.COLOR_HSV -> actionDevice.isNotBlank() && colorDeviceOptions.any { it.first == actionDevice }
            AutomationActionType.MODE -> actionDevice.isNotBlank() && actionModeInstance.isNotBlank() && actionModeValue.isNotBlank()
            AutomationActionType.DELAY -> (actionDelaySeconds.toIntOrNull() ?: 0) in 1..300
            AutomationActionType.SET_VARIABLE -> actionVariable.isNotBlank()
            AutomationActionType.RUN_YANDEX_SCENARIO -> actionScenario.isNotBlank()
            AutomationActionType.NOTIFICATION -> actionNotificationTitle.isNotBlank() && actionNotificationMessage.isNotBlank()
            else -> false
        }
        if (!valid) return
        val action = when (actionType) {
            AutomationActionType.DEVICE_POWER -> AutomationAction(type = actionType, deviceId = actionDevice, enabled = actionEnabled)
            AutomationActionType.BRIGHTNESS -> AutomationAction(type = actionType, deviceId = actionDevice, brightness = actionBrightness.toIntOrNull()?.coerceIn(0, 100) ?: 50)
            AutomationActionType.COLOR_HSV -> AutomationAction(type = actionType, deviceId = actionDevice, colorHue = actionColorHue.coerceIn(0, 360))
            AutomationActionType.MODE -> AutomationAction(type = actionType, deviceId = actionDevice, modeInstance = actionModeInstance, modeValue = actionModeValue)
            AutomationActionType.DELAY -> AutomationAction(type = actionType, delaySeconds = actionDelaySeconds.toInt().coerceIn(1, 300))
            AutomationActionType.SET_VARIABLE -> AutomationAction(type = actionType, variableName = actionVariable.trim(), variableValue = actionVariableValue)
            AutomationActionType.RUN_YANDEX_SCENARIO -> AutomationAction(type = actionType, scenarioId = actionScenario)
            AutomationActionType.NOTIFICATION -> AutomationAction(type = actionType, notificationTitle = actionNotificationTitle.trim(), notificationMessage = actionNotificationMessage.trim())
            else -> return
        }
        actions = actions + action
        actionDialog = false
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth(0.96f).fillMaxSize(0.90f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.fillMaxSize()) {
                ApplyGlassDialogBackdropBlur()
                Column(
                    Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF4E2A9D), Color(0xFF8A50D6), Color(0xFF3E6DC7)))).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(if (initial == null) "Новый сценарий" else "Настройка сценария", color = Color.White.copy(alpha = 0.82f), fontSize = 11.sp)
                    Text("Собери свою автоматизацию", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it.take(48) }, label = { Text("Название сценария") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Значок сценария", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("sun", "moon", "movie", "shield", "home", "light", "vacuum", "speaker", "temperature", "lock", "sparkles").forEach { kind ->
                            FilterChip(selected = iconKey == kind, onClick = { iconKey = kind }, label = {
                                SmartGlyph(kind, Modifier.size(18.dp), if (iconKey == kind) Color(0xFF8B5CF6) else MaterialTheme.colorScheme.primary)
                            })
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("ЕСЛИ", Modifier.weight(1f), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FilterChip(selected = matchAll, onClick = { matchAll = true }, label = { Text("Все") })
                                    FilterChip(selected = !matchAll, onClick = { matchAll = false }, label = { Text("Любое") })
                                }
                            }
                            if (conditions.isEmpty()) Text("Условия ещё не добавлены", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            conditions.forEach { condition ->
                                RemovableLine(conditionDescription(condition, devices), onRemove = { conditions = conditions.filterNot { it.id == condition.id } })
                            }
                            Button(onClick = { conditionDialog = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                Text("＋ Добавить условие")
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("ТОГДА", color = Color(0xFF29A88F), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            if (actions.isEmpty()) Text("Действия ещё не добавлены", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                items(actions, key = { it.id }) { action ->
                                    var dragDistance by remember(action.id) { mutableFloatStateOf(0f) }
                                    var isDragging by remember(action.id) { mutableStateOf(false) }
                                    val dragScale by animateFloatAsState(if (isDragging) 1.035f else 1f, label = "action-drag-scale")
                                    Card(
                                        modifier = Modifier.fillMaxWidth().animateItemPlacement().animateContentSize().graphicsLayer {
                                            scaleX = dragScale
                                            scaleY = dragScale
                                            shadowElevation = if (isDragging) 14.dp.toPx() else 1.dp.toPx()
                                        }.pointerInput(action.id) {
                                            detectDragGesturesAfterLongPress(
                                                onDragStart = { dragDistance = 0f; isDragging = true },
                                                onDragEnd = { dragDistance = 0f; isDragging = false },
                                                onDragCancel = { dragDistance = 0f; isDragging = false }
                                            ) { change, amount ->
                                                change.consume()
                                                dragDistance += amount.y
                                                if (kotlin.math.abs(dragDistance) >= reorderThreshold) {
                                                    val current = latestActions.value
                                                    val from = current.indexOfFirst { it.id == action.id }
                                                    val to = (from + if (dragDistance > 0f) 1 else -1).coerceIn(0, current.lastIndex)
                                                    if (from >= 0 && to != from) {
                                                        actions = current.toMutableList().apply { add(to, removeAt(from)) }
                                                    }
                                                    dragDistance = 0f
                                                }
                                            }
                                        },
                                        shape = RoundedCornerShape(15.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                    ) {
                                        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 4.dp, top = 9.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text("⠿", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp)
                                            Text(actionDescription(action, devices, variables, cloudScenarios), Modifier.weight(1f), fontSize = 11.sp)
                                            TextButton(onClick = { actions = actions.filterNot { it.id == action.id } }) { Text("Убрать", fontSize = 10.sp) }
                                        }
                                    }
                                }
                            }
                            Text("Зажми действие и перетащи вверх или вниз, чтобы изменить порядок.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            Button(onClick = { actionDialog = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                Text("＋ Добавить действие")
                            }
                        }
                    }
                    OutlinedTextField(value = cooldown, onValueChange = { cooldown = it.filter(Char::isDigit).take(4) }, label = { Text("Пауза между запусками, минут") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Отмена") }
                    Button(
                        enabled = name.isNotBlank() && conditions.isNotEmpty() && actions.isNotEmpty(),
                        onClick = {
                            onSave(LocalAutomation(
                                id = initial?.id ?: UUID.randomUUID().toString(),
                                name = name.trim(),
                                enabled = initial?.enabled ?: true,
                                matchAllConditions = matchAll,
                                conditions = conditions,
                                actions = actions,
                                cooldownMinutes = cooldown.toIntOrNull()?.coerceIn(0, 1440) ?: 2,
                                iconKey = iconKey
                            ))
                        }, modifier = Modifier.weight(1.2f), shape = RoundedCornerShape(14.dp)
                    ) { Text("Сохранить сценарий") }
                }
            }
        }
    }

    if (conditionDialog) {
        Dialog(onDismissRequest = { conditionDialog = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(Modifier.fillMaxWidth(0.94f).fillMaxSize(0.82f), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxSize()) {
                    ApplyGlassDialogBackdropBlur()
                    Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF5B52C9), Color(0xFF368FAE)))).padding(17.dp)) {
                        Text("Новое условие", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("Укажи, когда сценарий должен запускаться", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        ChoiceDropdown("Тип условия", conditionType, listOf(
                            AutomationConditionType.DEVICE_POWER to "Состояние устройства",
                            AutomationConditionType.SENSOR_VALUE to "Показание датчика",
                            AutomationConditionType.GLOBAL_VARIABLE to "Глобальная переменная",
                            AutomationConditionType.TIME_WINDOW to "Временной интервал",
                            AutomationConditionType.TIME_AT to "В определённое время",
                            AutomationConditionType.WEATHER to "Погода в выбранной зоне",
                            AutomationConditionType.LOCATION_ZONE to "Местоположение в зоне"
                        )) { conditionType = it }
                        when (conditionType) {
                            AutomationConditionType.DEVICE_POWER -> {
                                ChoiceDropdown("Устройство", conditionDevice, powerDeviceOptions) { conditionDevice = it }
                                ChoiceDropdown("Состояние", conditionValue, listOf("true" to "Включено", "false" to "Выключено")) { conditionValue = it }
                            }
                            AutomationConditionType.SENSOR_VALUE -> {
                                ChoiceDropdown("Устройство с датчиком", conditionDevice, sensorDeviceOptions) { conditionDevice = it }
                                ChoiceDropdown("Показатель", conditionProperty, propertyOptions) { conditionProperty = it }
                                ChoiceDropdown("Сравнение", conditionOperator, operators) { conditionOperator = it }
                                OutlinedTextField(value = conditionValue, onValueChange = { conditionValue = it.take(16) }, label = { Text("Пороговое значение") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationConditionType.GLOBAL_VARIABLE -> {
                                if (variableOptions.isNotEmpty()) ChoiceDropdown("Переменная", conditionVariable, variableOptions) { conditionVariable = it }
                                else Text("Сначала создай глобальную переменную.", fontSize = 11.sp)
                                OutlinedTextField(value = conditionVariable, onValueChange = { conditionVariable = it.take(40) }, label = { Text("Имя переменной") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                ChoiceDropdown("Сравнение", conditionOperator, operators) { conditionOperator = it }
                                OutlinedTextField(value = conditionValue, onValueChange = { conditionValue = it.take(48) }, label = { Text("С чем сравнивать") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationConditionType.TIME_WINDOW -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = timeStart, onValueChange = { timeStart = it.take(5) }, label = { Text("С (ЧЧ:ММ)") }, singleLine = true, modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = timeEnd, onValueChange = { timeEnd = it.take(5) }, label = { Text("До (ЧЧ:ММ)") }, singleLine = true, modifier = Modifier.weight(1f))
                                }
                                Text("Интервал может проходить через полночь, например 22:00–07:00.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                            AutomationConditionType.TIME_AT -> {
                                OutlinedTextField(value = timeStart, onValueChange = { timeStart = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, label = { Text("Каждый день в (ЧЧ:ММ)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Text("При открытом приложении проверка выполняется примерно раз в минуту. В фоне Android может задержать запуск.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                            AutomationConditionType.LOCATION_ZONE -> {
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(if (zoneLat.toDoubleOrNull() != null && zoneLon.toDoubleOrNull() != null) "Координаты выбраны" else "Место ещё не выбрано", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        Text("${zoneLat.ifBlank { "—" }}, ${zoneLon.ifBlank { "—" }} · радиус ${zoneRadius} м", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                        Button(onClick = { zoneMapOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Открыть карту и настроить зону") }
                                        OutlinedButton(onClick = { onRequestCurrentLocation { location -> zoneLat = "%.6f".format(java.util.Locale.US, location.latitude); zoneLon = "%.6f".format(java.util.Locale.US, location.longitude); zoneMapOpen = true } }, modifier = Modifier.fillMaxWidth()) { Text("◎ Центрировать на моём местоположении") }
                                    }
                                }
                                ChoiceDropdown("Когда сработать", if (zoneInside) "inside" else "outside", listOf("inside" to "Когда телефон находится внутри зоны", "outside" to "Когда телефон находится вне зоны")) { zoneInside = it == "inside" }
                                Text("Условие проверяет, находится ли телефон внутри выбранного радиуса. Проверка выполняется при обновлении приложения; в фоне Android может задерживать получение местоположения.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                            AutomationConditionType.WEATHER -> {
                                ChoiceDropdown("Показатель погоды", weatherMetric, listOf(
                                    "temperature_2m" to "Температура, °C",
                                    "relative_humidity_2m" to "Влажность, %",
                                    "precipitation" to "Осадки, мм",
                                    "wind_speed_10m" to "Ветер, м/с"
                                )) { weatherMetric = it }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Текущее местоположение", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        Text("Определять точку по телефону автоматически", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                    }
                                    Switch(checked = weatherUseCurrentLocation, onCheckedChange = { weatherUseCurrentLocation = it })
                                }
                                if (weatherUseCurrentLocation) {
                                    Text(weatherLocationStatus, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                    OutlinedButton(
                                        onClick = {
                                            onRequestCurrentLocation { location ->
                                                weatherLocationStatus = "Местоположение определено · ${"%.4f".format(java.util.Locale.US, location.latitude)}, ${"%.4f".format(java.util.Locale.US, location.longitude)}"
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Проверить доступ к местоположению") }
                                    Text("При проверке условия погода будет запрашиваться для текущей позиции телефона. Для фоновой работы нужно разрешение «Разрешить всегда».", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                } else {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = weatherLat, onValueChange = { weatherLat = it.take(12) }, label = { Text("Широта") }, singleLine = true, modifier = Modifier.weight(1f))
                                        OutlinedTextField(value = weatherLon, onValueChange = { weatherLon = it.take(12) }, label = { Text("Долгота") }, singleLine = true, modifier = Modifier.weight(1f))
                                    }
                                }
                                ChoiceDropdown("Сравнение", conditionOperator, operators) { conditionOperator = it }
                                OutlinedTextField(value = conditionValue, onValueChange = { conditionValue = it.take(12) }, label = { Text("Пороговое значение") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Text("Используется источник погоды, выбранный в настройках приложения.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { conditionDialog = false }, modifier = Modifier.weight(1f)) { Text("Отмена") }
                        Button(onClick = ::appendCondition, modifier = Modifier.weight(1f)) { Text("Добавить") }
                    }
                }
            }
        }
    }

    if (zoneMapOpen) {
        ZoneMapPickerDialog(
            initialLatitude = zoneLat.toDoubleOrNull()
                ?: context.getSharedPreferences("app_config", android.content.Context.MODE_PRIVATE).getString("weather_lat", null)?.toDoubleOrNull()
                ?: 60.1699,
            initialLongitude = zoneLon.toDoubleOrNull()
                ?: context.getSharedPreferences("app_config", android.content.Context.MODE_PRIVATE).getString("weather_lon", null)?.toDoubleOrNull()
                ?: 24.9384,
            initialRadiusMeters = zoneRadius.toIntOrNull() ?: 250,
            onDismiss = { zoneMapOpen = false },
            onSave = { latitude, longitude, radius ->
                zoneLat = "%.6f".format(java.util.Locale.US, latitude)
                zoneLon = "%.6f".format(java.util.Locale.US, longitude)
                zoneRadius = radius.toString()
                zoneMapOpen = false
            }
        )
    }

    if (actionDialog) {
        Dialog(onDismissRequest = { actionDialog = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(Modifier.fillMaxWidth(0.94f).fillMaxSize(0.82f), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxSize()) {
                    ApplyGlassDialogBackdropBlur()
                    Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF168F98), Color(0xFF4A72D5)))).padding(17.dp)) {
                        Text("Новое действие", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("Что должно произойти после выполнения условия", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Устройства и их действия", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        if (controlDeviceOptions.isEmpty()) {
                            Text("Нет устройств с доступными изменениями.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                        } else {
                            devices.forEach { device ->
                                val options = buildList<Pair<String, String>> {
                                    if (device.canToggle) add(AutomationActionType.DEVICE_POWER to "Питание")
                                    if (device.canDim) add(AutomationActionType.BRIGHTNESS to "Яркость")
                                    val cap = device.colorCapability
                                    if (cap != null && (cap.colorModel ?: cap.instance) in setOf("hsv", "rgb")) add(AutomationActionType.COLOR_HSV to "Цвет")
                                    if (device.modeCapabilities.isNotEmpty()) add(AutomationActionType.MODE to "Режим")
                                }
                                if (options.isNotEmpty()) {
                                    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.36f), RoundedCornerShape(14.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            IconTile(deviceIconKind(device.type, device.name), Modifier.size(30.dp), iconSize = 18.dp)
                                            Column(Modifier.weight(1f)) {
                                                Text(device.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                                Text(device.room.ifBlank { "Без комнаты" }, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                            }
                                        }
                                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            options.forEach { (type, label) ->
                                                FilterChip(selected = actionDevice == device.id && actionType == type, onClick = { actionDevice = device.id; actionType = type; actionModeInstance = ""; actionModeValue = "" }, label = { Text(label, fontSize = 10.sp) })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.14f))
                        Text("Общие действия", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(AutomationActionType.NOTIFICATION to "Уведомление", AutomationActionType.DELAY to "Задержка", AutomationActionType.SET_VARIABLE to "Переменная", AutomationActionType.RUN_YANDEX_SCENARIO to "Сценарий Яндекса").forEach { (type, label) ->
                                FilterChip(selected = actionDevice.isBlank() && actionType == type, onClick = { actionDevice = ""; actionType = type }, label = { Text(label, fontSize = 10.sp) })
                            }
                        }
                        when (actionType) {
                            AutomationActionType.DEVICE_POWER -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    FilterChip(selected = actionEnabled, onClick = { actionEnabled = true }, label = { Text("Включить") })
                                    FilterChip(selected = !actionEnabled, onClick = { actionEnabled = false }, label = { Text("Выключить") })
                                }
                            }
                            AutomationActionType.BRIGHTNESS -> {
                                OutlinedTextField(value = actionBrightness, onValueChange = { actionBrightness = it.filter(Char::isDigit).take(3) }, label = { Text("Яркость, %") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationActionType.COLOR_HSV -> {
                                Text("Оттенок", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                    listOf(0, 25, 50, 90, 130, 180, 210, 260, 310).forEach { hue ->
                                        Box(Modifier.size(30.dp).background(Color.hsv(hue.toFloat(), 0.95f, 1f), RoundedCornerShape(50)).clickable { actionColorHue = hue })
                                    }
                                }
                                Text("Выбран оттенок: ${actionColorHue}°", fontSize = 10.sp)
                            }
                            AutomationActionType.MODE -> {
                                ChoiceDropdown("Параметр режима", actionModeInstance, selectedModeCapabilities.map { it.instance to it.instance }) { actionModeInstance = it; actionModeValue = "" }
                                ChoiceDropdown("Значение", actionModeValue, selectedModeOptions) { actionModeValue = it }
                            }
                            AutomationActionType.NOTIFICATION -> {
                                OutlinedTextField(value = actionNotificationTitle, onValueChange = { actionNotificationTitle = it.take(64) }, label = { Text("Заголовок уведомления") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = actionNotificationMessage, onValueChange = { actionNotificationMessage = it.take(240) }, label = { Text("Текст уведомления") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4)
                                Text("При запуске сценария Android покажет системное уведомление. Разрешение уведомлений должно быть включено.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                            AutomationActionType.DELAY -> {
                                OutlinedTextField(value = actionDelaySeconds, onValueChange = { actionDelaySeconds = it.filter(Char::isDigit).take(3) }, label = { Text("Задержка, секунд (1–300)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Text("Следующее действие начнётся после указанной паузы.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                            AutomationActionType.SET_VARIABLE -> {
                                if (variableOptions.isNotEmpty()) ChoiceDropdown("Переменная", actionVariable, variableOptions) { actionVariable = it }
                                OutlinedTextField(value = actionVariable, onValueChange = { actionVariable = it.take(40) }, label = { Text("Имя переменной") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = actionVariableValue, onValueChange = { actionVariableValue = it.take(48) }, label = { Text("Новое значение") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationActionType.RUN_YANDEX_SCENARIO -> ChoiceDropdown("Сценарий Яндекса", actionScenario, cloudScenarios.map { it.id to it.name }) { actionScenario = it }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { actionDialog = false }, modifier = Modifier.weight(1f)) { Text("Отмена") }
                        Button(onClick = ::appendAction, enabled = when (actionType) {
                            AutomationActionType.DEVICE_POWER -> actionDevice.isNotBlank() && availableActionTypes.any { it.first == actionType }
                            AutomationActionType.BRIGHTNESS -> actionDevice.isNotBlank() && availableActionTypes.any { it.first == actionType } && actionBrightness.toIntOrNull() != null
                            AutomationActionType.COLOR_HSV -> actionDevice.isNotBlank() && availableActionTypes.any { it.first == actionType }
                            AutomationActionType.MODE -> actionDevice.isNotBlank() && availableActionTypes.any { it.first == actionType } && actionModeInstance.isNotBlank() && actionModeValue.isNotBlank()
                            AutomationActionType.NOTIFICATION -> actionNotificationTitle.isNotBlank() && actionNotificationMessage.isNotBlank()
                            AutomationActionType.DELAY -> (actionDelaySeconds.toIntOrNull() ?: 0) in 1..300
                            AutomationActionType.SET_VARIABLE -> actionVariable.isNotBlank()
                            AutomationActionType.RUN_YANDEX_SCENARIO -> actionScenario.isNotBlank()
                            else -> false
                        }, modifier = Modifier.weight(1f)) { Text("Добавить") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlobalVariablesDialog(
    variables: List<GlobalVariable>,
    onDismiss: () -> Unit,
    onSave: (GlobalVariable) -> Unit,
    onDelete: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var editingName by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Глобальные переменные") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Переменные общие для всех локальных автоматизаций и сохраняются на телефоне.", fontSize = 11.sp)
                if (variables.isEmpty()) Text("Пока нет переменных.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                variables.forEach { variable ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(variable.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(variable.value, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                        }
                        TextButton(onClick = { editingName = variable.name; name = variable.name; value = variable.value }) { Text("Изменить") }
                        TextButton(onClick = { onDelete(variable.name); if (editingName == variable.name) { editingName = null; name = ""; value = "" } }) { Text("×") }
                    }
                }
                Spacer(Modifier.size(1.dp))
                Text(if (editingName == null) "Новая переменная" else "Изменить переменную", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text("Имя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = value, onValueChange = { value = it.take(80) }, label = { Text("Значение: число, текст или true/false") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                val newName = name.trim()
                onSave(GlobalVariable(newName, value))
                if (editingName != null && !editingName.equals(newName, ignoreCase = true)) onDelete(editingName!!)
                name = ""; value = ""; editingName = null
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Готово") } }
    )
}

@Composable
private fun ChoiceDropdown(
    label: String,
    selected: String,
    options: List<Pair<String, String>>,
    onSelect: (String) -> Unit
) {
    var expanded by remember(label) { mutableStateOf(false) }
    val selectedLabel = options.firstOrNull { it.first == selected }?.second ?: selected.ifBlank { "Не выбрано" }
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = options.isNotEmpty()) {
                Text(selectedLabel, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                Text("⌄")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(text = { Text(option.second) }, onClick = { onSelect(option.first); expanded = false })
                }
            }
        }
    }
}

@Composable
private fun RemovableLine(text: String, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("• $text", Modifier.weight(1f), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
        TextButton(onClick = onRemove) { Text("Убрать", fontSize = 10.sp) }
    }
}

private val operators = listOf(">" to "Больше >", ">=" to "Не меньше ≥", "<" to "Меньше <", "<=" to "Не больше ≤", "==" to "Равно =", "!=" to "Не равно ≠")

private fun conditionDescription(condition: AutomationCondition, devices: List<HomeDevice>): String {
    val deviceName = devices.firstOrNull { it.id == condition.deviceId }?.name ?: "Устройство"
    return when (condition.type) {
        AutomationConditionType.DEVICE_POWER -> "$deviceName ${if (condition.value == "true") "включено" else "выключено"}"
        AutomationConditionType.SENSOR_VALUE -> "$deviceName: ${propertyLabel(condition.property)} ${condition.operator} ${condition.value}"
        AutomationConditionType.GLOBAL_VARIABLE -> "${condition.variableName} ${condition.operator} ${condition.value}"
        AutomationConditionType.TIME_WINDOW -> "Время между ${condition.startTime} и ${condition.endTime}"
        AutomationConditionType.TIME_AT -> "Каждый день в ${condition.startTime}"
        AutomationConditionType.WEATHER -> "Погода в зоне (${condition.latitude}, ${condition.longitude}): ${propertyLabel(condition.property)} ${condition.operator} ${condition.value}"
        AutomationConditionType.LOCATION_ZONE -> if (condition.insideZone) "Телефон внутри зоны · радиус ${condition.radiusMeters} м" else "Телефон вне зоны · радиус ${condition.radiusMeters} м"
        else -> "Условие"
    }
}

private fun actionDescription(action: AutomationAction, devices: List<HomeDevice>, variables: List<GlobalVariable>, cloudScenarios: List<HomeScenario>): String {
    val deviceName = devices.firstOrNull { it.id == action.deviceId }?.name ?: "Устройство"
    return when (action.type) {
        AutomationActionType.DEVICE_POWER -> "$deviceName: ${if (action.enabled) "включить" else "выключить"}"
        AutomationActionType.BRIGHTNESS -> "$deviceName: яркость ${action.brightness}%"
        AutomationActionType.COLOR_HSV -> "$deviceName: изменить цвет · оттенок ${action.colorHue}°"
        AutomationActionType.MODE -> "$deviceName: режим ${action.modeInstance} → ${action.modeValue}"
        AutomationActionType.DELAY -> "Пауза ${action.delaySeconds} сек. перед следующим действием"
        AutomationActionType.SET_VARIABLE -> "${action.variableName} = ${action.variableValue}"
        AutomationActionType.RUN_YANDEX_SCENARIO -> "Запустить: ${cloudScenarios.firstOrNull { it.id == action.scenarioId }?.name ?: "сценарий Яндекса"}"
        AutomationActionType.NOTIFICATION -> "Уведомление: ${action.notificationTitle} · ${action.notificationMessage}"
        else -> "Действие"
    }
}

private fun propertyLabel(instance: String): String = when (instance) {
    "temperature" -> "температура"
    "humidity" -> "влажность"
    "co2_level" -> "CO₂"
    "pressure" -> "давление"
    "illumination" -> "освещённость"
    "battery_level" -> "заряд"
    "power" -> "мощность"
    "motion" -> "движение"
    else -> instance.replace('_', ' ')
}


private fun automationCategory(iconKey: String, name: String): String {
    val key = (iconKey + " " + name).lowercase()
    return when {
        listOf("light", "lamp", "sun", "освещ", "свет").any(key::contains) -> "Освещение"
        listOf("temperature", "climate", "термо", "климат", "тепл").any(key::contains) -> "Климат"
        listOf("lock", "shield", "security", "camera", "безопас", "охран").any(key::contains) -> "Безопасность"
        else -> "Другое"
    }
}


private fun buildSmartAutomationIdeas(devices: List<HomeDevice>): List<LocalAutomation> {
    val lights = devices.filter { device ->
        device.canToggle && (
            device.colorCapability != null ||
            listOf("light", "lamp", "свет", "ламп", "люстр").any { key -> (device.name + " " + device.type).contains(key, ignoreCase = true) }
        )
    }
    val ideas = mutableListOf<LocalAutomation>()
    if (lights.isNotEmpty()) {
        ideas += LocalAutomation(
            name = "Выключать свет перед сном",
            enabled = false,
            matchAllConditions = true,
            conditions = listOf(AutomationCondition(type = AutomationConditionType.TIME_AT, startTime = "23:30")),
            actions = lights.map { AutomationAction(type = AutomationActionType.DEVICE_POWER, deviceId = it.id, enabled = false) },
            cooldownMinutes = 5,
            iconKey = "moon"
        )
    }
    val colorLights = lights.filter { device ->
        val capability = device.colorCapability
        capability != null && (capability.colorModel ?: capability.instance) in setOf("hsv", "rgb")
    }
    if (colorLights.isNotEmpty()) {
        ideas += LocalAutomation(
            name = "Мягкий вечерний свет",
            enabled = false,
            conditions = listOf(AutomationCondition(type = AutomationConditionType.TIME_AT, startTime = "20:30")),
            actions = colorLights.map { AutomationAction(type = AutomationActionType.COLOR_HSV, deviceId = it.id, colorHue = 35) },
            cooldownMinutes = 5,
            iconKey = "sun"
        )
    }
    val illuminanceSensor = devices.firstOrNull { device -> device.properties.any { it.instance == "illumination" && it.value is Number } }
    val targetLight = lights.firstOrNull()
    if (illuminanceSensor != null && targetLight != null) {
        ideas += LocalAutomation(
            name = "Включать свет, когда темно",
            enabled = false,
            conditions = listOf(AutomationCondition(type = AutomationConditionType.SENSOR_VALUE, deviceId = illuminanceSensor.id, property = "illumination", operator = "<", value = "35")),
            actions = listOf(AutomationAction(type = AutomationActionType.DEVICE_POWER, deviceId = targetLight.id, enabled = true)),
            cooldownMinutes = 10,
            iconKey = "light"
        )
    }
    return ideas
}

private fun automationIdeaDescription(automation: LocalAutomation, devices: List<HomeDevice>): String {
    val deviceNames = automation.actions.mapNotNull { action -> devices.firstOrNull { it.id == action.deviceId }?.name }.distinct()
    val condition = automation.conditions.firstOrNull()
    val whenText = when (condition?.type) {
        AutomationConditionType.TIME_AT -> "Каждый день в ${condition.startTime}"
        AutomationConditionType.SENSOR_VALUE -> "Когда освещённость на датчике ниже ${condition.value} лк"
        else -> "По условию"
    }
    return "$whenText · устройства: ${deviceNames.joinToString().ifBlank { "не выбраны" }}. Сценарий будет добавлен выключенным — проверь время и действия перед включением."
}
