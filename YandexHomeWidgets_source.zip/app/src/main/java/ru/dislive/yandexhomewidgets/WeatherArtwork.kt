package ru.dislive.yandexhomewidgets

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun YandexWeatherArtwork(weatherCode: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val s = minOf(w, h)
        val sunny = weatherCode == 0 || weatherCode == 1 || weatherCode == 2
        val cloudy = weatherCode != 0
        val rainy = weatherCode in 51..67 || weatherCode in 80..82
        val snowy = weatherCode in 71..77 || weatherCode in 85..86
        val storm = weatherCode in 95..99

        if (sunny) {
            val center = Offset(w * 0.68f, h * 0.31f)
            val radius = s * 0.205f
            for (i in 0 until 8) {
                val angle = (i * PI / 4.0).toFloat()
                val inner = Offset(center.x + cos(angle) * radius * 1.42f, center.y + sin(angle) * radius * 1.42f)
                val outer = Offset(center.x + cos(angle) * radius * 1.88f, center.y + sin(angle) * radius * 1.88f)
                drawLine(Color(0xFFFFD879), inner, outer, strokeWidth = s * 0.035f)
            }
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFFFFF0A6), Color(0xFFFFB94F)),
                    center = center,
                    radius = radius * 1.3f
                ),
                radius = radius,
                center = center
            )
        }

        if (cloudy) {
            val cloud = Path().apply {
                moveTo(w * 0.19f, h * 0.65f)
                cubicTo(w * 0.08f, h * 0.65f, w * 0.07f, h * 0.49f, w * 0.17f, h * 0.43f)
                cubicTo(w * 0.19f, h * 0.32f, w * 0.32f, h * 0.28f, w * 0.42f, h * 0.35f)
                cubicTo(w * 0.49f, h * 0.19f, w * 0.72f, h * 0.22f, w * 0.77f, h * 0.43f)
                cubicTo(w * 0.94f, h * 0.42f, w * 0.97f, h * 0.63f, w * 0.79f, h * 0.67f)
                close()
            }
            drawPath(
                path = cloud,
                brush = Brush.linearGradient(
                    listOf(Color(0xFFFFFFFF), Color(0xFFDCEBFF), Color(0xFFAFC8E8)),
                    start = Offset(w * 0.35f, h * 0.28f),
                    end = Offset(w * 0.68f, h * 0.72f)
                )
            )
            drawPath(path = cloud, color = Color.White.copy(alpha = 0.38f), style = Stroke(width = s * 0.012f))
        }

        if (rainy) {
            val rainColor = Color(0xFF83D5FF)
            listOf(0.31f, 0.51f, 0.71f).forEachIndexed { index, x ->
                val top = h * (0.73f + (index % 2) * 0.035f)
                val drop = Path().apply {
                    moveTo(w * x, top)
                    cubicTo(w * (x - 0.025f), top + s * 0.07f, w * (x - 0.025f), top + s * 0.10f, w * x, top + s * 0.11f)
                    cubicTo(w * (x + 0.025f), top + s * 0.10f, w * (x + 0.025f), top + s * 0.07f, w * x, top)
                    close()
                }
                drawPath(drop, rainColor.copy(alpha = 0.94f))
            }
        }

        if (snowy) {
            val snowColor = Color(0xFFE9F5FF)
            listOf(0.29f, 0.50f, 0.72f).forEach { x ->
                val center = Offset(w * x, h * 0.82f)
                val r = s * 0.052f
                for (i in 0 until 3) {
                    val a = (i * PI / 3.0).toFloat()
                    val delta = Offset(cos(a) * r, sin(a) * r)
                    drawLine(snowColor, Offset(center.x - delta.x, center.y - delta.y), Offset(center.x + delta.x, center.y + delta.y), strokeWidth = s * 0.018f)
                }
            }
        }

        if (storm) {
            val lightning = Path().apply {
                moveTo(w * 0.52f, h * 0.68f)
                lineTo(w * 0.39f, h * 0.88f)
                lineTo(w * 0.52f, h * 0.86f)
                lineTo(w * 0.46f, h * 1.02f)
                lineTo(w * 0.68f, h * 0.77f)
                lineTo(w * 0.55f, h * 0.78f)
                close()
            }
            drawPath(lightning, Color(0xFFFFD76A))
        }

        if (weatherCode == 45 || weatherCode == 48) {
            listOf(0.73f, 0.83f, 0.93f).forEach { y ->
                drawLine(Color.White.copy(alpha = 0.86f), Offset(w * 0.20f, h * y), Offset(w * 0.78f, h * y), strokeWidth = s * 0.025f)
            }
        }
    }
}
