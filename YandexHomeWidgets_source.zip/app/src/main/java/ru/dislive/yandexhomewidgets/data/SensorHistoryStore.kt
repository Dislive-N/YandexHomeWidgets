package ru.dislive.yandexhomewidgets.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local sensor timeline. Samples are stored on this device; Yandex does not provide this chart history. */
data class SensorSample(val timestamp: Long, val value: Double)

object SensorHistoryStore {
    private const val PREFS = "sensor_history_v1"
    private const val KEY_DATA = "samples"
    private const val MAX_PER_SENSOR = 2_000
    private const val RETENTION_MS = 7L * 24L * 60L * 60L * 1_000L
    private const val MIN_SAMPLE_INTERVAL_MS = 5L * 60L * 1_000L

    @Synchronized
    fun record(context: Context, devices: List<HomeDevice>) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = runCatching { JSONObject(prefs.getString(KEY_DATA, "{}") ?: "{}") }.getOrDefault(JSONObject())
        val now = System.currentTimeMillis()
        var changed = false

        devices.forEach { device ->
            device.properties.forEach propertyLoop@{ property ->
                val value = (property.value as? Number)?.toDouble() ?: return@propertyLoop
                if (!value.isFinite()) return@propertyLoop
                val key = "${device.id}::${property.instance}"
                val old = root.optJSONArray(key) ?: JSONArray()
                val last = if (old.length() > 0) old.optJSONObject(old.length() - 1) else null
                val lastTime = last?.optLong("t") ?: 0L
                val lastValue = last?.optDouble("v")
                // Avoid noisy duplicate samples during frequent refreshes, but keep a time series
                // even when a sensor reading remains constant.
                if (lastTime == 0L || now - lastTime >= MIN_SAMPLE_INTERVAL_MS || lastValue == null || kotlin.math.abs(lastValue - value) >= 0.01) {
                    val updated = JSONArray()
                    for (i in 0 until old.length()) {
                        val sample = old.optJSONObject(i) ?: continue
                        if (sample.optLong("t") >= now - RETENTION_MS) updated.put(sample)
                    }
                    updated.put(JSONObject().put("t", now).put("v", value))
                    val trimmed = JSONArray()
                    val start = (updated.length() - MAX_PER_SENSOR).coerceAtLeast(0)
                    for (i in start until updated.length()) trimmed.put(updated.optJSONObject(i))
                    root.put(key, trimmed)
                    changed = true
                }
            }
        }
        if (changed) prefs.edit().putString(KEY_DATA, root.toString()).apply()
    }

    fun load(context: Context, deviceId: String, instance: String, hours: Int = 24): List<SensorSample> {
        val raw = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DATA, "{}") ?: "{}"
        val array = runCatching { JSONObject(raw).optJSONArray("$deviceId::$instance") }.getOrNull() ?: return emptyList()
        val cutoff = System.currentTimeMillis() - hours.coerceIn(1, 168) * 60L * 60L * 1_000L
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val timestamp = item.optLong("t")
                if (timestamp >= cutoff) add(SensorSample(timestamp, item.optDouble("v")))
            }
        }
    }

    fun clear(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_DATA).apply()
    }
}
