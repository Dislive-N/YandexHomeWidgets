package ru.dislive.yandexhomewidgets.data

import android.content.Context
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

 data class SmartSuggestion(val title: String, val detail: String)

/** Local robust anomaly detector based on median and median absolute deviation (MAD). */
object SmartAdvisor {
    fun suggestions(context: Context, devices: List<HomeDevice>): List<SmartSuggestion> {
        val result = mutableListOf<SmartSuggestion>()
        devices.forEach { device ->
            device.properties.forEach propertyLoop@{ property ->
                val current = (property.value as? Number)?.toDouble() ?: return@propertyLoop
                if (!current.isFinite()) return@propertyLoop
                val samples = SensorHistoryStore.load(context, device.id, property.instance, hours = 168)
                    .map { it.value }.filter { it.isFinite() }
                val baselineSamples = samples.dropLast(1).takeLast(14)
                if (baselineSamples.size < 5) return@propertyLoop
                val median = median(baselineSamples)
                val deviations = baselineSamples.map { abs(it - median) }
                val mad = median(deviations)
                val threshold = max(0.5, max(abs(median) * 0.12, 3.0 * 1.4826 * mad))
                val delta = current - median
                if (abs(delta) > threshold) {
                    val direction = if (delta > 0) "выше" else "ниже"
                    result += SmartSuggestion(
                        "Необычное изменение: ${propertyLabel(property.instance)}",
                        "${device.name}: текущее значение ${format(current)} — на ${format(abs(delta))} $direction обычного уровня ${format(median)}. Проверь датчик и условия в комнате."
                    )
                }
            }
        }
        return result.distinctBy { it.title + it.detail }.take(3)
    }

    private fun median(values: List<Double>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun format(value: Double): String = String.format(java.util.Locale.getDefault(), "%.1f", value)

    private fun propertyLabel(instance: String): String = when (instance) {
        "temperature" -> "температуры"
        "humidity" -> "влажности"
        "co2_level" -> "CO₂"
        "pressure" -> "давления"
        "illumination" -> "освещённости"
        "power" -> "мощности"
        "battery_level" -> "заряда датчика"
        else -> instance.replace('_', ' ')
    }
}
