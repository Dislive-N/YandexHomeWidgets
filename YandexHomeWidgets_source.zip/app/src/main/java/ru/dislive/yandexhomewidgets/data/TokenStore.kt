package ru.dislive.yandexhomewidgets.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

class TokenStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("secure_tokens", Context.MODE_PRIVATE)

    fun saveTokens(tokens: YandexOAuth.TokenResponse) {
        prefs.edit().putString(KEY_ACCESS, encrypt(tokens.accessToken))
            .putLong(KEY_EXPIRY, System.currentTimeMillis() + tokens.expiresIn.coerceAtLeast(60L) * 1000L).apply()
    }

    fun getValidAccessToken(): String? {
        val current = readSecret(KEY_ACCESS) ?: return null
        val expiresAt = prefs.getLong(KEY_EXPIRY, 0L)
        return current.takeIf { expiresAt == 0L || expiresAt > System.currentTimeMillis() + 60_000L }
    }

    fun savePending(verifier: String, state: String) {
        prefs.edit().putString(KEY_PENDING_VERIFIER, encrypt(verifier))
            .putString(KEY_PENDING_STATE, encrypt(state)).apply()
    }
    fun pendingVerifier(): String? = readSecret(KEY_PENDING_VERIFIER)
    fun pendingState(): String? = readSecret(KEY_PENDING_STATE)
    fun clearPending() { prefs.edit().remove(KEY_PENDING_VERIFIER).remove(KEY_PENDING_STATE).apply() }

    fun deviceId(): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val created = java.util.UUID.randomUUID().toString()
        prefs.edit().putString(KEY_DEVICE_ID, created).apply()
        return created
    }
    fun deviceName(): String = (android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL).take(100)
    fun clear() { prefs.edit().clear().apply() }

    private fun readSecret(key: String): String? {
        val encrypted = prefs.getString(key, null) ?: return null
        return try { decrypt(encrypted) } catch (_: Exception) {
            prefs.edit().remove(key).apply()
            null
        }
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val iv = cipher.iv
        val packed = ByteBuffer.allocate(1 + iv.size + encrypted.size).put(iv.size.toByte()).put(iv).put(encrypted).array()
        return Base64.encodeToString(packed, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val packed = Base64.decode(value, Base64.NO_WRAP)
        val buffer = ByteBuffer.wrap(packed)
        val ivSize = buffer.get().toInt() and 0xff
        require(ivSize in 12..16 && buffer.remaining() > ivSize)
        val iv = ByteArray(ivSize)
        buffer.get(iv)
        val encrypted = ByteArray(buffer.remaining())
        buffer.get(encrypted)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), javax.crypto.spec.GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private companion object {
        const val KEY_ALIAS = "yandex_home_widget_token_key"
        const val KEY_ACCESS = "access_token"
        const val KEY_EXPIRY = "expires_at"
        const val KEY_DEVICE_ID = "device_id"
        const val KEY_PENDING_VERIFIER = "pending_verifier"
        const val KEY_PENDING_STATE = "pending_state"
    }
}
