package ru.dislive.yandexhomewidgets.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Keeps a complete last-known-good home snapshot so the dashboard can appear before the next API sync. */
object HomeSnapshotStore {
    private const val PREFS = "home_snapshot"
    private const val KEY = "snapshot_json"

    fun save(context: Context, home: HomeData) {
        val root = JSONObject()
        val devices = JSONArray()
        home.devices.forEach { device ->
            val caps = JSONArray()
            device.capabilities.forEach { cap ->
                val item = JSONObject()
                    .put("type", cap.type).put("instance", cap.instance)
                    .put("min", cap.min).put("max", cap.max)
                    .put("reportable", cap.reportable).put("retrievable", cap.retrievable)
                    .put("lastUpdated", cap.lastUpdated)
                    .put("colorModel", cap.colorModel ?: JSONObject.NULL)
                    .put("temperatureMin", cap.temperatureMin)
                    .put("temperatureMax", cap.temperatureMax)
                    .put("temperatureSupported", cap.temperatureSupported)
                    .put("colorScenes", JSONArray(cap.colorScenes))
                    .put("modeOptions", JSONArray(cap.modeOptions))
                if (cap.value == null) item.put("value", JSONObject.NULL) else item.put("value", cap.value)
                caps.put(item)
            }
            val props = JSONArray()
            device.properties.forEach { prop ->
                val item = JSONObject().put("type", prop.type).put("instance", prop.instance)
                    .put("reportable", prop.reportable).put("retrievable", prop.retrievable)
                    .put("lastUpdated", prop.lastUpdated)
                if (prop.value == null) item.put("value", JSONObject.NULL) else item.put("value", prop.value)
                props.put(item)
            }
            val item = JSONObject().put("id", device.id).put("name", device.name)
                .put("room", device.room).put("type", device.type)
                .put("brightnessMin", device.brightnessMin).put("brightnessMax", device.brightnessMax)
                .put("isOnline", device.isOnline)
                .put("capabilities", caps).put("properties", props)
            if (device.onOff == null) item.put("onOff", JSONObject.NULL) else item.put("onOff", device.onOff)
            if (device.brightness == null) item.put("brightness", JSONObject.NULL) else item.put("brightness", device.brightness)
            devices.put(item)
        }
        val scenarios = JSONArray()
        home.scenarios.forEach { scenarios.put(JSONObject().put("id", it.id).put("name", it.name).put("isActive", it.isActive)) }
        val groups = JSONArray()
        home.groups.forEach { groups.put(JSONObject().put("id", it.id).put("name", it.name).put("deviceIds", JSONArray(it.deviceIds))) }
        root.put("devices", devices).put("scenarios", scenarios).put("groups", groups)
            .put("rooms", JSONArray(home.rooms)).put("savedAt", System.currentTimeMillis())
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, root.toString()).apply()
    }

    fun load(context: Context): HomeData? = runCatching {
        val raw = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return null
        val root = JSONObject(raw)
        val devices = buildList {
            val array = root.optJSONArray("devices") ?: JSONArray()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val capabilities = buildList {
                    val caps = item.optJSONArray("capabilities") ?: JSONArray()
                    for (j in 0 until caps.length()) {
                        val c = caps.optJSONObject(j) ?: continue
                        val scenes = c.optJSONArray("colorScenes") ?: JSONArray()
                        val modes = c.optJSONArray("modeOptions") ?: JSONArray()
                        add(HomeCapability(
                            type = c.optString("type"), instance = c.optString("instance"),
                            value = c.opt("value").takeUnless { it == null || it === JSONObject.NULL },
                            min = c.optInt("min", 0), max = c.optInt("max", 100),
                            reportable = c.optBoolean("reportable"), retrievable = c.optBoolean("retrievable", true),
                            lastUpdated = c.optDouble("lastUpdated"),
                            colorModel = c.optString("colorModel").takeIf { it == "rgb" || it == "hsv" },
                            temperatureMin = c.optInt("temperatureMin", 2000),
                            temperatureMax = c.optInt("temperatureMax", 9000),
                            temperatureSupported = c.optBoolean("temperatureSupported"),
                            colorScenes = (0 until scenes.length()).mapNotNull { scenes.optString(it).takeIf(String::isNotBlank) },
                            modeOptions = (0 until modes.length()).mapNotNull { modes.optString(it).takeIf(String::isNotBlank) }
                        ))
                    }
                }
                val properties = buildList {
                    val props = item.optJSONArray("properties") ?: JSONArray()
                    for (j in 0 until props.length()) {
                        val p = props.optJSONObject(j) ?: continue
                        add(HomeProperty(
                            type = p.optString("type"), instance = p.optString("instance"),
                            value = p.opt("value").takeUnless { it == null || it === JSONObject.NULL },
                            reportable = p.optBoolean("reportable"), retrievable = p.optBoolean("retrievable", true),
                            lastUpdated = p.optDouble("lastUpdated")
                        ))
                    }
                }
                val id = item.optString("id")
                if (id.isBlank()) continue
                add(HomeDevice(
                    id = id, name = item.optString("name", "Устройство"), room = item.optString("room"),
                    type = item.optString("type"), capabilities = capabilities, properties = properties,
                    onOff = if (item.isNull("onOff")) null else item.optBoolean("onOff"),
                    brightness = if (item.isNull("brightness")) null else item.optInt("brightness"),
                    brightnessMin = item.optInt("brightnessMin", 0), brightnessMax = item.optInt("brightnessMax", 100),
                    isOnline = item.optBoolean("isOnline", true)
                ))
            }
        }
        val scenarios = buildList {
            val array = root.optJSONArray("scenarios") ?: JSONArray()
            for (i in 0 until array.length()) array.optJSONObject(i)?.let { add(HomeScenario(it.optString("id"), it.optString("name"), it.optBoolean("isActive"))) }
        }
        val groups = buildList {
            val array = root.optJSONArray("groups") ?: JSONArray()
            for (i in 0 until array.length()) array.optJSONObject(i)?.let { item ->
                val ids = item.optJSONArray("deviceIds") ?: JSONArray()
                add(HomeGroup(item.optString("id"), item.optString("name"), (0 until ids.length()).map { ids.optString(it) }))
            }
        }
        val roomsArray = root.optJSONArray("rooms") ?: JSONArray()
        val rooms = (0 until roomsArray.length()).map { roomsArray.optString(it) }
        HomeData(devices, scenarios, groups, rooms)
    }.getOrNull()
}
