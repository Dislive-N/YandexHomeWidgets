package ru.dislive.yandexhomewidgets

import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.foundation.layout.BoxWithConstraints
import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.location.Location
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import ru.dislive.yandexhomewidgets.data.AppUpdateChecker
import ru.dislive.yandexhomewidgets.data.AppUpdateInfo
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.HomeSnapshotStore
import ru.dislive.yandexhomewidgets.data.HomeChange
import ru.dislive.yandexhomewidgets.data.HomeChangeDetector
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.CurrentWeather
import ru.dislive.yandexhomewidgets.data.LocationWeatherService
import ru.dislive.yandexhomewidgets.data.DeviceGroup
import ru.dislive.yandexhomewidgets.data.DeviceGroupStore
import ru.dislive.yandexhomewidgets.data.HomeGroup
import ru.dislive.yandexhomewidgets.data.HomeHistoryStore
import ru.dislive.yandexhomewidgets.data.SensorHistoryStore
import ru.dislive.yandexhomewidgets.data.HomeNotificationCenter
import ru.dislive.yandexhomewidgets.data.HomeNotificationOptions
import ru.dislive.yandexhomewidgets.data.HomeNotificationSettings
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.LocalAutomation
import ru.dislive.yandexhomewidgets.data.GlobalVariable
import ru.dislive.yandexhomewidgets.data.LocalAutomationStore
import ru.dislive.yandexhomewidgets.data.LocalAutomationEngine
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi
import ru.dislive.yandexhomewidgets.data.YandexOAuth
import ru.dislive.yandexhomewidgets.widget.HomeWidget
import ru.dislive.yandexhomewidgets.widget.NotificationsWidget
import ru.dislive.yandexhomewidgets.widget.ScenarioWidget
import ru.dislive.yandexhomewidgets.widget.WorkScheduler
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class AppPage { HOME, DEVICES, SCENARIOS, AUTOMATIONS, HISTORY, ANALYTICS, SETTINGS, DEVICE, GROUPS, GROUP_DETAILS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkScheduler.schedule(this)
        HomeNotificationCenter.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4107)
        }
        setContent { YandexHomeApp() }
    }

}

@Composable
private fun YandexHomeApp() {
    val context = LocalContext.current
    val config = remember { context.getSharedPreferences("app_config", Context.MODE_PRIVATE) }
    val tokenStore = remember { TokenStore(context.applicationContext) }
    val cachedHome = remember { HomeSnapshotStore.load(context.applicationContext) }
    val scope = rememberCoroutineScope()

    var clientId by remember { mutableStateOf(config.getString("client_id", "").orEmpty()) }
    var redirectInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(clientId.isNotBlank()) }
    var isBusy by remember { mutableStateOf(false) }
    var isSyncing by remember { mutableStateOf(clientId.isNotBlank()) }
    var refreshRequested by remember { mutableStateOf(false) }
    var pendingDeviceIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var status by remember { mutableStateOf("Сначала подключи Яндекс OAuth") }
    var error by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf(cachedHome?.devices.orEmpty().map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }) }
    var scenarios by remember { mutableStateOf(cachedHome?.scenarios.orEmpty()) }
    var localAutomations by remember { mutableStateOf(LocalAutomationStore.loadAutomations(context)) }
    var globalVariables by remember { mutableStateOf(LocalAutomationStore.loadVariables(context)) }
    var groups by remember { mutableStateOf(cachedHome?.groups.orEmpty()) }
    var customGroups by remember { mutableStateOf(DeviceGroupStore.load(context)) }
    var selectedDeviceId by remember { mutableStateOf<String?>(null) }
    var selectedGroupId by remember { mutableStateOf<String?>(null) }
    var roomNames by remember { mutableStateOf(cachedHome?.rooms.orEmpty()) }
    var notificationOptions by remember { mutableStateOf(HomeNotificationSettings.load(context)) }
    var history by remember { mutableStateOf(HomeHistoryStore.load(context)) }
    var page by remember { mutableStateOf(AppPage.HOME) }
    var settingsReturnPage by remember { mutableStateOf(AppPage.HOME) }
    var deviceReturnPage by remember { mutableStateOf(AppPage.HOME) }
    var groupReturnPage by remember { mutableStateOf(AppPage.HOME) }
    val pageStateHolder = rememberSaveableStateHolder()
    var isDarkTheme by remember { mutableStateOf(config.getBoolean("dark_theme", true)) }
    var glassOpacity by remember { mutableFloatStateOf(config.getFloat("glass_opacity", 0.82f).coerceIn(0.55f, 0.96f)) }
    var deviceCardSize by remember { mutableStateOf(config.getString("device_card_size", "normal") ?: "normal") }
    var deviceCardWidthDp by remember { mutableStateOf(config.getInt("device_card_width_dp", 100).coerceIn(92, 260)) }
    var deviceCardHeightDp by remember { mutableStateOf(config.getInt("device_card_height_dp", 136).coerceIn(112, 280)) }
    var deviceColumns by remember { mutableStateOf(config.getInt("device_columns", 0).coerceIn(0, 3)) }
    var weatherCardSize by remember { mutableStateOf(config.getString("weather_card_size", "normal") ?: "normal") }
    var weatherSource by remember { mutableStateOf(config.getString("weather_source", "open_meteo") ?: "open_meteo") }
    var yandexWeatherApiKey by remember { mutableStateOf(config.getString("yandex_weather_api_key", "").orEmpty()) }
    var scenarioCardSize by remember { mutableStateOf(config.getString("scenario_card_size", "normal") ?: "normal") }
    var autoRefreshSeconds by remember { mutableStateOf(config.getInt("auto_refresh_seconds", 60).coerceIn(0, 300)) }
    var isCheckingUpdate by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<AppUpdateInfo?>(null) }
    var updateMessage by remember { mutableStateOf("Нажми «Проверить обновления», чтобы проверить новую версию.") }
    var currentWeather by remember { mutableStateOf<CurrentWeather?>(null) }
    var weatherLoading by remember { mutableStateOf(false) }
    var weatherError by remember { mutableStateOf("") }
    var pendingLocationAction by remember { mutableStateOf<((Location) -> Unit)?>(null) }

    fun navigateBack() {
        when (page) {
            AppPage.GROUP_DETAILS -> { page = groupReturnPage; selectedGroupId = null }
            AppPage.DEVICE -> { page = deviceReturnPage; selectedDeviceId = null }
            AppPage.SETTINGS -> page = settingsReturnPage
            else -> { page = AppPage.HOME; selectedDeviceId = null; selectedGroupId = null }
        }
    }
    BackHandler(enabled = page != AppPage.HOME) { navigateBack() }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result.values.any { it }
        val callback = pendingLocationAction
        pendingLocationAction = null
        if (granted && callback != null) {
            scope.launch {
                val location = runCatching { LocationWeatherService.currentLocation(context) }.getOrNull()
                if (location != null) callback(location) else {
                    weatherLoading = false
                    weatherError = "Не удалось определить местоположение. Проверь, включена ли геолокация."
                }
            }
        } else if (!granted) {
            weatherLoading = false
            weatherError = "Разрешение на местоположение не выдано. Его можно включить в настройках Android."
        }
    }

    fun requestCurrentLocation(onLocation: (Location) -> Unit) {
        if (LocationWeatherService.hasLocationPermission(context)) {
            scope.launch {
                val location = runCatching { LocationWeatherService.currentLocation(context) }.getOrNull()
                if (location != null) onLocation(location) else {
                    weatherLoading = false
                    weatherError = "Не удалось определить местоположение. Включи геолокацию Android."
                }
            }
        } else {
            pendingLocationAction = onLocation
            locationPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
        }
    }

    fun refreshLocationWeather() {
        weatherLoading = true
        weatherError = ""
        requestCurrentLocation { location ->
            config.edit().putString("weather_lat", location.latitude.toString()).putString("weather_lon", location.longitude.toString()).apply()
            scope.launch {
                val placeName = LocationWeatherService.resolvePlaceName(context, location.latitude, location.longitude)
                currentWeather = LocationWeatherService.currentWeather(location.latitude, location.longitude, placeName, weatherSource, yandexWeatherApiKey)
                weatherLoading = false
                if (currentWeather == null) weatherError = if (weatherSource == "yandex" && yandexWeatherApiKey.isBlank()) "Для Яндекс Погоды добавь API-ключ в настройках." else "Сервис погоды временно недоступен. Проверь ключ или попробуй позже."
            }
        }
    }

    LaunchedEffect(Unit) {
        if (LocationWeatherService.hasLocationPermission(context)) {
            refreshLocationWeather()
        }
    }

    suspend fun reloadHome(showLoading: Boolean = true) {
        if (isSyncing) {
            if (!showLoading) refreshRequested = true
            return
        }
        isSyncing = true
        if (showLoading) isBusy = true
        error = ""
        try {
            val token = tokenStore.getValidAccessToken()
            if (token.isNullOrBlank()) {
                // Keep the last-known dashboard visible; authentication can be repaired from Settings.
                isConnected = devices.isNotEmpty() || cachedHome != null
                status = if (isConnected) "Нет активной сессии · показаны сохранённые данные" else "Яндекс не подключён"
                return
            }
            val api = YandexHomeApi(token)
            val home = api.getHome()
            val changes = HomeChangeDetector.collect(context, home)
            HomeNotificationCenter.showChanges(context, changes)
            SensorHistoryStore.record(context, home.devices)
            LocalAutomationEngine.evaluate(context, api, home)
            localAutomations = LocalAutomationStore.loadAutomations(context)
            globalVariables = LocalAutomationStore.loadVariables(context)
            devices = home.devices.map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }
            scenarios = home.scenarios
            groups = home.groups
            roomNames = home.rooms
            HomeCache.saveHome(context, home)
            HomeSnapshotStore.save(context, home)
            history = HomeHistoryStore.load(context)
            isConnected = true
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            status = "Обновлено $time · ${devices.size} устройств · автообновление ${if (autoRefreshSeconds == 0) "выкл" else if (autoRefreshSeconds < 60) "${autoRefreshSeconds} с" else "${autoRefreshSeconds / 60} мин"}"
            HomeWidget().updateAll(context)
            ScenarioWidget().updateAll(context)
            NotificationsWidget().updateAll(context)
        } catch (e: Exception) {
            error = e.message ?: "Не удалось загрузить умный дом"
            status = "Нет связи · показаны последние данные"
            if (devices.isNotEmpty()) isConnected = true
        } finally {
            isSyncing = false
            if (showLoading) isBusy = false
            if (refreshRequested) {
                refreshRequested = false
                scope.launch { delay(350); reloadHome(showLoading = false) }
            }
        }
    }

    fun performDeviceAction(action: suspend (YandexHomeApi) -> Unit) {
        scope.launch {
            isBusy = true
            error = ""
            try {
                val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                action(YandexHomeApi(token))
                reloadHome(showLoading = false)
            } catch (e: Exception) {
                error = e.message ?: "Не удалось выполнить команду"
            } finally {
                isBusy = false
            }
        }
    }

    fun performOnOff(deviceIds: List<String>, value: Boolean) {
        val ids = deviceIds.distinct().filter { id -> devices.any { it.id == id && it.canToggle && it.isOnline } }
        if (ids.isEmpty() || ids.any { it in pendingDeviceIds }) return
        // Optimistic UI: the tile responds instantly while the network request runs.
        devices = devices.map { if (it.id in ids) it.copy(onOff = value) else it }
        pendingDeviceIds = pendingDeviceIds + ids
        scope.launch {
            var succeeded = false
            try {
                val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                YandexHomeApi(token).setOnOffBulk(ids, value)
                succeeded = true
            } catch (e: Exception) {
                error = e.message ?: "Не удалось изменить состояние группы"
                reloadHome(showLoading = false)
            } finally {
                pendingDeviceIds = pendingDeviceIds - ids.toSet()
            }
            if (succeeded) {
                delay(500)
                reloadHome(showLoading = false)
            }
        }
    }

    fun checkUpdates() {
        scope.launch {
            isCheckingUpdate = true
            updateMessage = "Проверяю GitHub Releases…"
            updateInfo = null
            try {
                val found = AppUpdateChecker.check(context, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)
                updateInfo = found
                updateMessage = if (found == null) "Установлена последняя доступная версия (${BuildConfig.VERSION_NAME})." else "Доступна версия ${found.version} · ${found.apkVariant} (сборка ${found.buildCode})."
            } catch (e: Exception) {
                updateMessage = e.message ?: "Не удалось проверить обновления. Проверь подключение к интернету."
            } finally {
                isCheckingUpdate = false
            }
        }
    }

    LaunchedEffect(Unit) { checkUpdates() }

    LaunchedEffect(Unit) {
        // With saved API settings the dashboard and its loading indicator are visible
        // on the very first frame. Start the request without replacing that screen.
        if (clientId.isNotBlank()) {
            isSyncing = false
            reloadHome(showLoading = false)
        }
    }

    // Visible-screen polling only. A minute is frequent enough for status awareness
    // without repeatedly refreshing every device while the user is elsewhere.
    LaunchedEffect(isConnected, page, autoRefreshSeconds) {
        if (isConnected && autoRefreshSeconds > 0 && page in setOf(AppPage.HOME, AppPage.DEVICES, AppPage.SCENARIOS, AppPage.AUTOMATIONS, AppPage.DEVICE, AppPage.GROUP_DETAILS, AppPage.ANALYTICS)) {
            while (true) {
                delay(autoRefreshSeconds * 1_000L)
                if (!isBusy && !isSyncing) reloadHome(showLoading = false)
            }
        }
    }

    val colors = if (isDarkTheme) darkColorScheme(
        primary = Color(0xFFA98BFF),
        onPrimary = Color.White,
        primaryContainer = Color(0xFF43336A),
        onPrimaryContainer = Color(0xFFE9DEFF),
        secondary = Color(0xFF61D6B8),
        onSecondary = Color(0xFF073B31),
        secondaryContainer = Color(0xFF194A43),
        onSecondaryContainer = Color(0xFFB9F3E4),
        tertiary = Color(0xFF83BDF3),
        background = Color(0xFF101525),
        surface = Color(0xFF1D2538).copy(alpha = glassOpacity),
        surfaceVariant = Color(0xFF29334A).copy(alpha = glassOpacity * 0.98f),
        onSurface = Color(0xFFF2F4FC),
        onSurfaceVariant = Color(0xFFB4BDD0),
        onBackground = Color(0xFFF2F4FC),
        outline = Color(0xFF56617A),
        outlineVariant = Color(0xFF3A455D),
        error = Color(0xFFFF7185),
        errorContainer = Color(0xFF512B39),
        onErrorContainer = Color(0xFFFFDCE2)
    ) else lightColorScheme(
        primary = Color(0xFF7553D1),
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE9E0FF),
        onPrimaryContainer = Color(0xFF35205F),
        secondary = Color(0xFF158F82),
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFD7F2EB),
        onSecondaryContainer = Color(0xFF154E45),
        tertiary = Color(0xFF397FC0),
        background = Color(0xFFF4F3FA),
        surface = Color(0xFFFCFCFF).copy(alpha = glassOpacity),
        surfaceVariant = Color(0xFFECECF5).copy(alpha = glassOpacity),
        onSurface = Color(0xFF172039),
        onSurfaceVariant = Color(0xFF5C657A),
        onBackground = Color(0xFF172039),
        outline = Color(0xFFD0D3E1),
        outlineVariant = Color(0xFFE2E3EC),
        error = Color(0xFFBD3850),
        errorContainer = Color(0xFFFFE7EC),
        onErrorContainer = Color(0xFF7C182D)
    )

    MaterialTheme(
        colorScheme = colors,
        // Round cards, but leave the small button shape untouched (including power buttons).
        shapes = MaterialTheme.shapes.copy(
            small = RoundedCornerShape(11.dp),
            medium = RoundedCornerShape(17.dp),
            large = RoundedCornerShape(22.dp)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color.Transparent, contentColor = MaterialTheme.colorScheme.onSurface) {
            Box(Modifier.fillMaxSize()) {
                Canvas(Modifier.fillMaxSize()) {
                    val base = if (isDarkTheme) {
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF0E1424), Color(0xFF172238), Color(0xFF171C2C), Color(0xFF101525)),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height)
                        )
                    } else {
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFF6F4FC), Color(0xFFEEF3FA), Color(0xFFF8F1FB)),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height)
                        )
                    }
                    drawRect(base)
                    if (isDarkTheme) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF8C83B8).copy(alpha = 0.055f), Color.Transparent),
                                center = Offset(size.width * 0.12f, size.height * 0.10f),
                                radius = size.width * 0.72f
                            ),
                            radius = size.width * 0.72f,
                            center = Offset(size.width * 0.12f, size.height * 0.10f)
                        )
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF8A8D9B).copy(alpha = 0.035f), Color.Transparent),
                                center = Offset(size.width * 0.92f, size.height * 0.84f),
                                radius = size.width * 0.68f
                            ),
                            radius = size.width * 0.68f,
                            center = Offset(size.width * 0.92f, size.height * 0.84f)
                        )
                    }
                }
                Column(modifier = Modifier.fillMaxSize().statusBarsPadding().padding(top = 14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            when (page) {
                                AppPage.HOME -> "Главная"
                                AppPage.DEVICES -> "Устройства"
                                AppPage.SCENARIOS -> "Сценарии"
                                AppPage.AUTOMATIONS -> "Автоматизации"
                                AppPage.HISTORY -> "История изменений"
                                AppPage.ANALYTICS -> "Аналитика датчиков"
                                AppPage.SETTINGS -> "Настройки"
                                AppPage.DEVICE -> devices.firstOrNull { it.id == selectedDeviceId }?.name ?: "Устройство"
                                AppPage.GROUPS -> "Группы"
                                AppPage.GROUP_DETAILS -> customGroups.firstOrNull { it.id == selectedGroupId }?.name ?: "Группа"
                            }, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.35).sp
                        )
                        if (isSyncing) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(11.dp), strokeWidth = 1.7.dp)
                                Text(if (devices.isEmpty()) "Загрузка устройств…" else "Обновление состояния…", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                            }
                        } else {
                            Text(status, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (page in setOf(AppPage.HOME, AppPage.DEVICES)) {
                        if (isConnected) {
                            TextButton(onClick = { history = HomeHistoryStore.load(context); page = AppPage.HISTORY }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)) {
                                SmartGlyph("clock", Modifier.size(21.dp), MaterialTheme.colorScheme.primary)
                            }
                            TextButton(onClick = { if (!isBusy && !isSyncing) scope.launch { reloadHome() } }, enabled = !isBusy && !isSyncing, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)) {
                                if (isSyncing) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp)
                                else Text("↻", fontSize = 25.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        TextButton(onClick = { settingsReturnPage = page; page = AppPage.SETTINGS }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)) {
                            SmartGlyph("settings", Modifier.size(21.dp), MaterialTheme.colorScheme.primary)
                        }
                    } else if (page in setOf(AppPage.SCENARIOS, AppPage.AUTOMATIONS, AppPage.ANALYTICS, AppPage.HISTORY)) {
                        TextButton(onClick = { settingsReturnPage = page; page = AppPage.SETTINGS }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)) {
                            SmartGlyph("settings", Modifier.size(21.dp), MaterialTheme.colorScheme.primary)
                        }
                    } else {
                        TextButton(onClick = { navigateBack() }) { Text("← Назад") }
                    }
                }
                if (isSyncing) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    )
                } else {
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                }

                Box(modifier = Modifier.weight(1f)) {
                    if (!isConnected && page != AppPage.SETTINGS) {
                        ConnectionScreen(
                            clientId = clientId,
                            onClientIdChange = {
                                clientId = it
                                config.edit().putString("client_id", it.trim()).apply()
                            },
                            redirectInput = redirectInput,
                            onRedirectChange = { redirectInput = it },
                            isBusy = isBusy,
                            error = error,
                            onOpenOAuth = {
                                try {
                                    val url = YandexOAuth.authorizationUrl(clientId, tokenStore)
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    status = "Подтверди доступ на странице Яндекса, затем вернись сюда"
                                } catch (e: Exception) { error = e.message ?: "Не удалось открыть авторизацию" }
                            },
                            onConnect = {
                                scope.launch {
                                    isBusy = true
                                    error = ""
                                    try {
                                        val response = YandexOAuth.exchangeRedirect(redirectInput, clientId, tokenStore)
                                        tokenStore.saveTokens(response)
                                        redirectInput = ""
                                        status = "Токен получен. Загружаю устройства…"
                                        reloadHome()
                                    } catch (e: Exception) {
                                        error = e.message ?: "Не удалось завершить подключение"
                                        isBusy = false
                                    }
                                }
                            }
                        )
                    } else {
                        pageStateHolder.SaveableStateProvider(page.name) {
when (page) {
                            AppPage.HOME -> HomeScreen(
                                devices = devices,
                                customGroups = customGroups,
                                rooms = roomNames,
                                isBusy = isBusy,
                                isLoading = isSyncing,
                                pendingDeviceIds = pendingDeviceIds,
                                cardSize = deviceCardSize,
                                cardWidthDp = deviceCardWidthDp,
                                cardHeightDp = deviceCardHeightDp,
                                deviceColumns = deviceColumns,
                                weatherCardSize = weatherCardSize,
                                weather = currentWeather,
                                weatherLoading = weatherLoading,
                                weatherError = weatherError,
                                onRefreshWeather = ::refreshLocationWeather,
                                onFavoriteChange = { device, favorite ->
                                    HomeCache.setFavorite(context, device.id, favorite)
                                    devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                    scope.launch { HomeWidget().updateAll(context) }
                                },
                                onAnalytics = { page = AppPage.ANALYTICS },
                                onOpenGroups = { page = AppPage.GROUPS },
                                onOpenDevices = { page = AppPage.DEVICES },
                                onOpenScenarios = { page = AppPage.SCENARIOS },
                                onOpenAutomations = { page = AppPage.AUTOMATIONS },
                                onOpenGroup = { groupReturnPage = page; selectedGroupId = it.id; page = AppPage.GROUP_DETAILS },
                                onOpenDevice = { deviceReturnPage = page; selectedDeviceId = it.id; page = AppPage.DEVICE },
                                onToggle = { device, value -> if (!isBusy) performOnOff(listOf(device.id), value) },
                                onToggleGroup = { members, value -> if (!isBusy) performOnOff(members.map { it.id }, value) }
                            )
                            AppPage.DEVICES -> DevicesScreen(
                                devices = devices,
                                pendingDeviceIds = pendingDeviceIds,
                                isBusy = isBusy,
                                cardSize = deviceCardSize,
                                cardWidthDp = deviceCardWidthDp,
                                cardHeightDp = deviceCardHeightDp,
                                deviceColumns = deviceColumns,
                                onOpenDevice = { deviceReturnPage = page; selectedDeviceId = it.id; page = AppPage.DEVICE },
                                onFavoriteChange = { device, favorite ->
                                    HomeCache.setFavorite(context, device.id, favorite)
                                    devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                    scope.launch { HomeWidget().updateAll(context) }
                                },
                                onToggle = { device, value -> if (!isBusy) performOnOff(listOf(device.id), value) }
                            )
                            AppPage.DEVICE -> {
                                val device = devices.firstOrNull { it.id == selectedDeviceId }
                                if (device == null) EmptyCard("Устройство больше не найдено. Обнови список устройств.")
                                else DeviceDetailsScreen(
                                    device = device,
                                    isBusy = isBusy,
                                    onFavorite = { favorite ->
                                        HomeCache.setFavorite(context, device.id, favorite)
                                        devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                        scope.launch { HomeWidget().updateAll(context) }
                                    },
                                    onToggle = { value -> if (!isBusy) performOnOff(listOf(device.id), value) },
                                    onBrightness = { value -> if (!isBusy) performDeviceAction { it.setBrightness(device.id, value) } },
                                    onHue = { hue -> if (!isBusy) performDeviceAction {
                                        val cap = device.colorCapability
                                        if (cap?.colorModel == "hsv") it.setColorHsv(device.id, hue)
                                        else it.setColorRgb(device.id, android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 1f, 1f)) and 0x00FFFFFF)
                                    } },
                                    onTemperature = { value -> if (!isBusy) performDeviceAction { it.setColorTemperature(device.id, value) } },
                                    onColorScene = { value -> if (!isBusy) performDeviceAction { it.setColorScene(device.id, value) } },
                                    onMode = { instance, value -> if (!isBusy) performDeviceAction { it.setMode(device.id, instance, value) } }
                                )
                            }
                            AppPage.ANALYTICS -> SensorAnalyticsScreen(devices = devices)
                            AppPage.GROUPS -> GroupsScreen(
                                groups = customGroups,
                                devices = devices,
                                onOpenGroup = { groupReturnPage = page; selectedGroupId = it.id; page = AppPage.GROUP_DETAILS },
                                onSave = { group ->
                                    val claimed = group.deviceIds.toSet()
                                    customGroups = (
                                        customGroups.filterNot { it.id == group.id }
                                            .map { old -> old.copy(deviceIds = old.deviceIds.filterNot { it in claimed }) }
                                            .filter { it.deviceIds.isNotEmpty() } + group
                                    ).sortedBy { it.name.lowercase() }
                                    DeviceGroupStore.save(context, customGroups)
                                },
                                onDelete = { group ->
                                    customGroups = customGroups.filterNot { it.id == group.id }
                                    DeviceGroupStore.save(context, customGroups)
                                }
                            )
                            AppPage.GROUP_DETAILS -> {
                                val group = customGroups.firstOrNull { it.id == selectedGroupId }
                                if (group == null) EmptyCard("Группа не найдена. Вернись к списку групп.")
                                else GroupDetailsScreen(
                                    group = group,
                                    devices = devices.filter { it.id in group.deviceIds },
                                    isBusy = isBusy,
                                    onToggle = { members, enabled -> if (!isBusy) performOnOff(members.map { it.id }, enabled) },
                                    onColor = { members, model, hue ->
                                        if (!isBusy) performDeviceAction { api ->
                                            val ids = members.map { it.id }
                                            if (model == "rgb") {
                                                val rgb = android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 1f, 1f)) and 0x00FFFFFF
                                                api.setColorRgbBulk(ids, rgb)
                                            } else api.setColorHsvBulk(ids, hue)
                                        }
                                    },
                                    onMode = { members, instance, value -> if (!isBusy) performDeviceAction { it.setModeBulk(members.map { d -> d.id }, instance, value) } },
                                    onOpenDevice = { deviceReturnPage = page; selectedDeviceId = it.id; page = AppPage.DEVICE }
                                )
                            }
                            AppPage.SCENARIOS -> ScenariosScreen(
                                scenarios = scenarios,
                                isBusy = isBusy,
                                onRun = { scenario -> if (!isBusy) performDeviceAction { it.runScenario(scenario.id)
                                    HomeNotificationCenter.showScenarioRun(context, scenario.name) } }
                            )
                            AppPage.AUTOMATIONS -> ScenarioCenterScreen(
                                devices = devices,
                                cloudScenarios = scenarios,
                                automations = localAutomations,
                                variables = globalVariables,
                                isBusy = isBusy,
                                onSaveAutomation = { automation ->
                                    LocalAutomationStore.saveAutomation(context, automation)
                                    localAutomations = LocalAutomationStore.loadAutomations(context)
                                    scope.launch { ScenarioWidget().updateAll(context) }
                                },
                                onDeleteAutomation = { id ->
                                    LocalAutomationStore.deleteAutomation(context, id)
                                    localAutomations = LocalAutomationStore.loadAutomations(context)
                                    scope.launch { ScenarioWidget().updateAll(context) }
                                },
                                onToggleAutomation = { id, enabled ->
                                    LocalAutomationStore.setAutomationEnabled(context, id, enabled)
                                    localAutomations = LocalAutomationStore.loadAutomations(context)
                                    scope.launch { ScenarioWidget().updateAll(context) }
                                },
                                onRunAutomation = { id ->
                                    scope.launch {
                                        isBusy = true
                                        error = ""
                                        try {
                                            val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                                            val api = YandexHomeApi(token)
                                            val home = api.getHome()
                                            LocalAutomationEngine.runManually(context, api, home, id)
                                            globalVariables = LocalAutomationStore.loadVariables(context)
                                            reloadHome(showLoading = false)
                                        } catch (e: Exception) {
                                            error = e.message ?: "Не удалось запустить автоматизацию"
                                        } finally {
                                            isBusy = false
                                        }
                                    }
                                },
                                onSaveVariable = { variable ->
                                    LocalAutomationStore.saveVariable(context, variable)
                                    globalVariables = LocalAutomationStore.loadVariables(context)
                                },
                                onDeleteVariable = { name ->
                                    LocalAutomationStore.deleteVariable(context, name)
                                    globalVariables = LocalAutomationStore.loadVariables(context)
                                },
                                onRunCloudScenario = { scenario -> if (!isBusy) performDeviceAction { it.runScenario(scenario.id)
                                    HomeNotificationCenter.showScenarioRun(context, scenario.name) } },
                                onRequestCurrentLocation = { onFound -> requestCurrentLocation(onFound) },
                                onOpenBackgroundLocationSettings = {
                                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                                },
                                cardSize = scenarioCardSize
                            )
                            AppPage.HISTORY -> HistoryScreen(
                                history = history,
                                onClear = { HomeHistoryStore.clear(context); history = emptyList(); scope.launch { NotificationsWidget().updateAll(context) } }
                            )
                            AppPage.SETTINGS -> SettingsScreen(
                                isDarkTheme = isDarkTheme,
                                onThemeChange = {
                                    isDarkTheme = it
                                    config.edit().putBoolean("dark_theme", it).apply()
                                },
                                glassOpacity = glassOpacity,
                                onGlassOpacityChange = {
                                    glassOpacity = it.coerceIn(0.55f, 0.96f)
                                    config.edit().putFloat("glass_opacity", glassOpacity).apply()
                                },
                                deviceCardSize = deviceCardSize,
                                onDeviceCardSizeChange = {
                                    deviceCardSize = it
                                    config.edit().putString("device_card_size", it).apply()
                                },
                                deviceCardWidthDp = deviceCardWidthDp,
                                deviceCardHeightDp = deviceCardHeightDp,
                                onDeviceCardSizeSave = { width, height ->
                                    deviceCardWidthDp = width.coerceIn(92, 260)
                                    deviceCardHeightDp = height.coerceIn(112, 280)
                                    config.edit().putInt("device_card_width_dp", deviceCardWidthDp).putInt("device_card_height_dp", deviceCardHeightDp).apply()
                                },
                                deviceColumns = deviceColumns,
                                onDeviceColumnsChange = { deviceColumns = it.coerceIn(0, 3); config.edit().putInt("device_columns", deviceColumns).apply() },
                                weatherCardSize = weatherCardSize,
                                onWeatherCardSizeChange = { weatherCardSize = it; config.edit().putString("weather_card_size", weatherCardSize).apply() },
                                weatherSource = weatherSource,
                                yandexWeatherApiKey = yandexWeatherApiKey,
                                onWeatherSettingsSave = { source, key ->
                                    weatherSource = source
                                    yandexWeatherApiKey = key
                                    config.edit().putString("weather_source", source).putString("yandex_weather_api_key", key.trim()).apply()
                                    refreshLocationWeather()
                                },
                                scenarioCardSize = scenarioCardSize,
                                onScenarioCardSizeChange = {
                                    scenarioCardSize = it
                                    config.edit().putString("scenario_card_size", it).apply()
                                },
                                autoRefreshSeconds = autoRefreshSeconds,
                                onAutoRefreshChange = {
                                    autoRefreshSeconds = it
                                    config.edit().putInt("auto_refresh_seconds", it).apply()
                                },
                                options = notificationOptions,
                                onNotificationChange = {
                                    notificationOptions = it
                                    HomeNotificationSettings.save(context, it)
                                },
                                updateMessage = updateMessage,
                                updateInfo = updateInfo,
                                isCheckingUpdate = isCheckingUpdate,
                                onCheckUpdates = ::checkUpdates,
                                onDisconnect = {
                                    tokenStore.clear()
                                    HomeCache.clear(context)
                                    context.getSharedPreferences("home_snapshot", Context.MODE_PRIVATE).edit().clear().apply()
                                    devices = emptyList()
                                    scenarios = emptyList()
                                    groups = emptyList()
                                    roomNames = emptyList()
                                    isConnected = false
                                    page = AppPage.HOME
                                    status = "Яндекс отключён"
                                    error = ""
                                    scope.launch { HomeWidget().updateAll(context) }
                                },
                                onNotificationPermission = {
                                    if (Build.VERSION.SDK_INT >= 33) {
                                        context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                                    }
                                }
                            )
                        }
}
                    }
                }

                if (error.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(error, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                    }
                }
                if (isConnected && page in setOf(AppPage.HOME, AppPage.DEVICES, AppPage.SCENARIOS, AppPage.AUTOMATIONS, AppPage.HISTORY, AppPage.DEVICE, AppPage.GROUPS, AppPage.GROUP_DETAILS, AppPage.ANALYTICS)) {
                    val navBackground = if (isDarkTheme) listOf(Color(0xFF20283A), Color(0xFF171F31)) else listOf(Color(0xFFFDFDFF), Color(0xFFEDEBFA))
                    NavigationBar(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(23.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(23.dp))
                            .background(Brush.linearGradient(navBackground)),
                        containerColor = Color.Transparent,
                        tonalElevation = 0.dp
                    ) {
                        val selectedColor = MaterialTheme.colorScheme.primary
                        val idleColor = MaterialTheme.colorScheme.onSurfaceVariant
                        NavigationBarItem(
                            selected = page in setOf(AppPage.HOME, AppPage.GROUP_DETAILS, AppPage.HISTORY),
                            onClick = { page = AppPage.HOME },
                            icon = { SmartGlyph("home", Modifier.size(21.dp), if (page == AppPage.HOME) selectedColor else idleColor) },
                            label = { Text("Главная", maxLines = 1, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = selectedColor, selectedTextColor = selectedColor, unselectedIconColor = idleColor, unselectedTextColor = idleColor, indicatorColor = selectedColor.copy(alpha = 0.13f))
                        )
                        NavigationBarItem(
                            selected = page in setOf(AppPage.DEVICES, AppPage.DEVICE, AppPage.GROUPS),
                            onClick = { page = AppPage.DEVICES },
                            icon = { SmartGlyph("grid", Modifier.size(21.dp), if (page in setOf(AppPage.DEVICES, AppPage.DEVICE, AppPage.GROUPS)) selectedColor else idleColor) },
                            label = { Text("Устройства", maxLines = 1, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = selectedColor, selectedTextColor = selectedColor, unselectedIconColor = idleColor, unselectedTextColor = idleColor, indicatorColor = selectedColor.copy(alpha = 0.13f))
                        )
                        NavigationBarItem(
                            selected = page == AppPage.SCENARIOS,
                            onClick = { page = AppPage.SCENARIOS },
                            icon = { SmartGlyph("sparkles", Modifier.size(21.dp), if (page == AppPage.SCENARIOS) selectedColor else idleColor) },
                            label = { Text("Сценарии", maxLines = 1, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = selectedColor, selectedTextColor = selectedColor, unselectedIconColor = idleColor, unselectedTextColor = idleColor, indicatorColor = selectedColor.copy(alpha = 0.13f))
                        )
                        NavigationBarItem(
                            selected = page == AppPage.AUTOMATIONS,
                            onClick = { page = AppPage.AUTOMATIONS },
                            icon = { SmartGlyph("sparkles", Modifier.size(21.dp), if (page == AppPage.AUTOMATIONS) selectedColor else idleColor) },
                            label = { Text("Автоматизации", maxLines = 1, fontSize = 8.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = selectedColor, selectedTextColor = selectedColor, unselectedIconColor = idleColor, unselectedTextColor = idleColor, indicatorColor = selectedColor.copy(alpha = 0.13f))
                        )
                        NavigationBarItem(
                            selected = page == AppPage.ANALYTICS,
                            onClick = { page = AppPage.ANALYTICS },
                            icon = { SmartGlyph("chart", Modifier.size(21.dp), if (page == AppPage.ANALYTICS) selectedColor else idleColor) },
                            label = { Text("Аналитика", maxLines = 1, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = selectedColor, selectedTextColor = selectedColor, unselectedIconColor = idleColor, unselectedTextColor = idleColor, indicatorColor = selectedColor.copy(alpha = 0.13f))
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
private fun ProfileScreen(
    isConnected: Boolean,
    deviceCount: Int,
    roomCount: Int,
    onOpenSettings: () -> Unit,
    onOpenGroups: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenAnalytics: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 15.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                Box(Modifier.size(58.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    SmartGlyph("user", Modifier.size(30.dp), MaterialTheme.colorScheme.primary)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Мой профиль", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Личный центр управления домом", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (isConnected) "Яндекс подключён" else "Яндекс не подключён", fontSize = 10.sp, color = if (isConnected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error)
                }
                SmartGlyph("settings", Modifier.size(23.dp), MaterialTheme.colorScheme.primary)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            AnalyticsMetric("Устройства", deviceCount.toString(), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            AnalyticsMetric("Комнаты", roomCount.toString(), MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
        }
        Text("УПРАВЛЕНИЕ", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 5.dp))
        ProfileActionRow("Мой дом и комнаты", "Группы, помещения и устройства", "house", onOpenGroups)
        ProfileActionRow("История изменений", "Все последние события дома", "clock", onOpenHistory)
        ProfileActionRow("Датчики и аналитика", "Графики, показатели и предупреждения", "chart", onOpenAnalytics)
        ProfileActionRow("Настройки приложения", "Тема, карточки, погода и обновления", "settings", onOpenSettings)
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Виджеты и автоматизации", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Настраивай виджеты на рабочем столе и автоматические действия во вкладке «Автоматизации».", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ProfileActionRow(title: String, description: String, glyph: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(17.dp))
            .clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            SmartGlyph(glyph, Modifier.size(21.dp), MaterialTheme.colorScheme.primary)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Text("›", fontSize = 23.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ConnectionScreen(
    clientId: String,
    onClientIdChange: (String) -> Unit,
    redirectInput: String,
    onRedirectChange: (String) -> Unit,
    isBusy: Boolean,
    error: String,
    onOpenOAuth: () -> Unit,
    onConnect: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Подключение к Яндексу", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Создай приложение в Яндекс OAuth типа «Для доступа к API или отладки». Выдай разрешения iot:view и iot:control. В Redirect URI укажи https://oauth.yandex.ru/verification_code.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f), fontSize = 13.sp
                )
                TextButton(onClick = { openUrl(context, "https://oauth.yandex.ru/client/new/") }) { Text("Открыть Яндекс OAuth") }
                OutlinedTextField(value = clientId, onValueChange = onClientIdChange, modifier = Modifier.fillMaxWidth(), label = { Text("Client ID") }, singleLine = true)
                Button(onClick = onOpenOAuth, enabled = clientId.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) { Text("Открыть страницу подтверждения") }
                Divider()
                Text("После подтверждения скопируй полный адрес из адресной строки браузера и вставь ниже. Пароль и Client Secret сюда вводить не нужно.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                OutlinedTextField(value = redirectInput, onValueChange = onRedirectChange, modifier = Modifier.fillMaxWidth(), label = { Text("Полный адрес после подтверждения") }, minLines = 2)
                Button(onClick = onConnect, enabled = clientId.isNotBlank() && redirectInput.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) {
                    if (isBusy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Подключить")
                }
                Text("OAuth PKCE. Токены хранятся зашифрованными через Android Keystore.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun DashboardStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.secondaryContainer)))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun DashboardMetric(kind: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        SmartGlyph(kind, Modifier.size(16.dp), MaterialTheme.colorScheme.primary)
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}


@Composable
private fun HomeStatusChip(
    icon: String,
    title: String,
    detail: String,
    tint: Color
) {
    Row(
        modifier = Modifier
            .widthIn(min = 116.dp)
            .height(60.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.62f), RoundedCornerShape(18.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, color = tint, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable
private fun HomeQuickButton(
    title: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier.height(42.dp),
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = if (enabled) 0.42f else 0.15f)),
        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 5.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tint, disabledContentColor = tint.copy(alpha = 0.42f))
    ) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HistoryQuickButton(isLoading: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF225C88), contentColor = Color.White)
    ) {
        Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
            SmartGlyph("clock", Modifier.size(22.dp), Color.White)
            if (isLoading) CircularProgressIndicator(Modifier.size(28.dp), color = Color.White.copy(alpha = 0.9f), strokeWidth = 1.5.dp)
        }
    }
}

@Composable
private fun DevicesScreen(
    devices: List<HomeDevice>,
    pendingDeviceIds: Set<String>,
    isBusy: Boolean,
    cardSize: String,
    cardWidthDp: Int,
    cardHeightDp: Int,
    deviceColumns: Int,
    onOpenDevice: (HomeDevice) -> Unit,
    onFavoriteChange: (HomeDevice, Boolean) -> Unit,
    onToggle: (HomeDevice, Boolean) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Все") }
    val counts = remember(devices) {
        mapOf(
            "Все" to devices.size,
            "Проблемы" to devices.count(::deviceNeedsAttention),
            "Свет" to devices.count { dashboardDeviceCategory(it) == "Освещение" },
            "Розетки" to devices.count { dashboardDeviceCategory(it) == "Розетки" },
            "Датчики" to devices.count { dashboardDeviceCategory(it) == "Датчики" },
            "Медиа" to devices.count { dashboardDeviceCategory(it) == "Медиа" },
            "Избранное" to devices.count { it.isFavorite }
        )
    }
    val filtered = remember(devices, query, category) {
        val base = when (category) {
            "Проблемы" -> devices.filter(::deviceNeedsAttention)
            "Свет" -> devices.filter { dashboardDeviceCategory(it) == "Освещение" }
            "Розетки", "Датчики", "Медиа" -> devices.filter { dashboardDeviceCategory(it) == category }
            "Избранное" -> devices.filter { it.isFavorite }
            else -> devices
        }
        if (query.isBlank()) base else base.filter {
            it.name.contains(query, true) || it.room.contains(query, true) || it.type.contains(query, true)
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
    val availableWidth = (maxWidth - 28.dp).coerceAtLeast(116.dp)
    val minimumCardWidth = maxOf(92, cardWidthDp).dp
    val fittingColumns = ((availableWidth + 10.dp) / (minimumCardWidth + 10.dp)).toInt().coerceIn(1, 3)
    val effectiveColumns = if (deviceColumns == 0) fittingColumns else deviceColumns.coerceIn(1, 3).coerceAtMost(fittingColumns)
    LazyVerticalGrid(
        columns = GridCells.Fixed(effectiveColumns),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }, key = "devices_intro") {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("ВСЕ ПОДКЛЮЧЕНИЯ", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                        Text("Устройства", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${devices.size} всего", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it.take(64) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск по названию или комнате") },
                    shape = RoundedCornerShape(17.dp)
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Все", "Проблемы", "Свет", "Розетки", "Датчики", "Медиа", "Избранное").forEach { item ->
                        FilterChip(
                            selected = category == item,
                            onClick = { category = item },
                            label = { Text("$item · ${counts[item] ?: 0}", fontSize = 10.sp, maxLines = 1) }
                        )
                    }
                }
            }
        }
        if (filtered.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }, key = "devices_empty") {
                EmptyCard(if (query.isNotBlank()) "По запросу ничего не найдено." else "В этой категории пока нет устройств.")
            }
        } else {
            gridItems(filtered, key = { it.id }) { device ->
                CompactDeviceTile(
                    device = device,
                    enabled = !isBusy && device.isOnline,
                    pending = device.id in pendingDeviceIds,
                    cardSize = cardSize,
                    cardWidthDp = cardWidthDp,
                    cardHeightDp = cardHeightDp,
                    onFavorite = { onFavoriteChange(device, it) },
                    onOpen = { onOpenDevice(device) },
                    onToggle = { onToggle(device, it) }
                )
            }
        }
    }
    }
}

@Composable
private fun HomeScreen(
    devices: List<HomeDevice>,
    customGroups: List<DeviceGroup>,
    rooms: List<String>,
    isBusy: Boolean,
    isLoading: Boolean,
    pendingDeviceIds: Set<String>,
    cardSize: String,
    cardWidthDp: Int,
    cardHeightDp: Int,
    deviceColumns: Int,
    weatherCardSize: String,
    weather: CurrentWeather?,
    weatherLoading: Boolean,
    weatherError: String,
    onRefreshWeather: () -> Unit,
    onFavoriteChange: (HomeDevice, Boolean) -> Unit,
    onAnalytics: () -> Unit,
    onOpenGroups: () -> Unit,
    onOpenDevices: () -> Unit,
    onOpenScenarios: () -> Unit,
    onOpenAutomations: () -> Unit,
    onOpenGroup: (DeviceGroup) -> Unit,
    onOpenDevice: (HomeDevice) -> Unit,
    onToggle: (HomeDevice, Boolean) -> Unit,
    onToggleGroup: (List<HomeDevice>, Boolean) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("Все") }
    var deviceSearch by remember { mutableStateOf("") }
    val visibleDevices = remember(devices, selectedCategory, deviceSearch) {
        val byCategory = when (selectedCategory) {
            "Все" -> devices
            "Проблемы" -> devices.filter(::deviceNeedsAttention)
            "Не в сети" -> devices.filterNot { it.isOnline }
            "Избранное" -> devices.filter { it.isFavorite }
            "Свет", "Освещение" -> devices.filter { dashboardDeviceCategory(it) == "Освещение" }
            "Медиа" -> devices.filter { dashboardDeviceCategory(it) == "Медиа" }
            else -> devices.filter { dashboardDeviceCategory(it) == selectedCategory }
        }
        val query = deviceSearch.trim()
        if (query.isBlank()) byCategory else byCategory.filter { device ->
            device.name.contains(query, ignoreCase = true) || device.room.contains(query, ignoreCase = true) || device.type.contains(query, ignoreCase = true)
        }
    }
    val groupedIds = remember(customGroups) { customGroups.flatMap { it.deviceIds }.toSet() }
    val ungrouped = remember(visibleDevices, groupedIds) { visibleDevices.filterNot { it.id in groupedIds } }
    val ungroupedByRoom = remember(ungrouped) { ungrouped.groupBy { it.room.ifBlank { "Без комнаты" } } }
    val allRooms = remember(rooms, ungroupedByRoom) {
        (rooms.filter { ungroupedByRoom.containsKey(it) } + ungroupedByRoom.keys).distinct()
    }
    val onlineCount = devices.count { it.isOnline }
    val offlineCount = devices.size - onlineCount
    val favoriteDevices = remember(devices) { devices.filter { it.isFavorite } }
    val lightDevices = remember(devices) { devices.filter { dashboardDeviceCategory(it) == "Освещение" } }
    val socketDevices = remember(devices) { devices.filter { dashboardDeviceCategory(it) == "Розетки" } }
    val activeLights = lightDevices.count { it.isOnline && it.onOff == true }
    val activeSockets = socketDevices.count { it.isOnline && it.onOff == true }
    val averageTemperature = devices.flatMap { device -> device.properties.filter { it.instance == "temperature" }.mapNotNull { (it.value as? Number)?.toDouble() } }.takeIf { it.isNotEmpty() }?.average()
    val averageHumidity = devices.flatMap { device -> device.properties.filter { it.instance == "humidity" }.mapNotNull { (it.value as? Number)?.toDouble() } }.takeIf { it.isNotEmpty() }?.average()
    val averageCo2 = devices.flatMap { device -> device.properties.filter { it.instance == "co2_level" }.mapNotNull { (it.value as? Number)?.toDouble() } }.takeIf { it.isNotEmpty() }?.average()
    val homeRoomCards = remember(rooms, devices) { (rooms + devices.map { it.room }.filter { it.isNotBlank() }).distinct() }
    val weatherHorizontalPadding = when (weatherCardSize) { "small" -> 12.dp; "large" -> 20.dp; else -> 16.dp }
    val weatherVerticalPadding = when (weatherCardSize) { "small" -> 10.dp; "large" -> 18.dp; else -> 14.dp }
    val weatherArtworkSize = when (weatherCardSize) { "small" -> 42.dp; "large" -> 62.dp; else -> 50.dp }
    val weatherTemperatureSize = when (weatherCardSize) { "small" -> 24.sp; "large" -> 31.sp; else -> 27.sp }
    val darkUi = MaterialTheme.colorScheme.background.red < 0.5f
    val weatherInk = if (darkUi) Color.White else MaterialTheme.colorScheme.onSurface
    val weatherMuted = if (darkUi) Color.White.copy(alpha = 0.76f) else MaterialTheme.colorScheme.onSurfaceVariant
    val weatherPanel = if (darkUi) listOf(Color(0xFF243653), Color(0xFF294859), Color(0xFF252E43)) else listOf(Color(0xFFE4E8FA), Color(0xFFE3F0F4), Color(0xFFF0E8F8))

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val availableWidth = (maxWidth - 28.dp).coerceAtLeast(116.dp)
        val minimumCardWidth = maxOf(92, cardWidthDp).dp
        val fittingColumns = ((availableWidth + 10.dp) / (minimumCardWidth + 10.dp)).toInt().coerceIn(1, 3)
        val effectiveColumns = if (deviceColumns == 0) fittingColumns else deviceColumns.coerceIn(1, 3).coerceAtMost(fittingColumns)
        LazyVerticalGrid(
        columns = GridCells.Fixed(effectiveColumns),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }, key = "dashboard_hero") {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val heroShape = RoundedCornerShape(25.dp)
                val heroColors = if (darkUi) listOf(Color(0xFF152846), Color(0xFF243B5A), Color(0xFF342B50)) else listOf(Color(0xFFE7E4F9), Color(0xFFE5F0F7), Color(0xFFF5EAF5))
                val heroInk = if (darkUi) Color.White else MaterialTheme.colorScheme.onSurface
                val heroMuted = if (darkUi) Color.White.copy(alpha = 0.76f) else MaterialTheme.colorScheme.onSurfaceVariant
                Row(
                    Modifier.fillMaxWidth().height(158.dp).clip(heroShape)
                        .background(Brush.linearGradient(heroColors, start = Offset.Zero, end = Offset(900f, 600f)))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f), heroShape)
                        .padding(horizontal = 17.dp, vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(0.72f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("ВАШ УМНЫЙ ДОМ", color = heroMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                        Text(
                            when {
                                devices.isEmpty() -> "Подключи свой дом"
                                offlineCount > 0 -> "Есть проблемы со связью"
                                else -> "Ваш умный дом в порядке"
                            },
                            color = heroInk, fontSize = 20.sp, lineHeight = 23.sp, fontWeight = FontWeight.ExtraBold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(if (offlineCount > 0) MaterialTheme.colorScheme.error else Color(0xFF52C79E)))
                            Text(
                                when { devices.isEmpty() -> "Ожидает подключения"; offlineCount > 0 -> "$offlineCount устройств не в сети"; else -> "Все устройства работают" },
                                color = heroMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text("$onlineCount из ${devices.size} устройств онлайн", color = heroMuted, fontSize = 9.sp)
                    }
                    Box(Modifier.weight(0.28f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(94.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = if (darkUi) 0.15f else 0.11f)))
                        SmartGlyph("home", Modifier.size(68.dp), if (darkUi) Color(0xFFD7C7FF) else MaterialTheme.colorScheme.primary)
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HomeStatusChip("°", "Температура", averageTemperature?.let { "${it.toInt()}°" } ?: "Нет данных", Color(0xFF54A6F0))
                    HomeStatusChip("◌", "Влажность", averageHumidity?.let { "${it.toInt()}%" } ?: "Нет данных", Color(0xFF45BFCB))
                    HomeStatusChip("✦", "Воздух", averageCo2?.let { if (it < 800) "Отлично" else if (it <= 1000) "Норма" else "Проветрить" } ?: "Нет данных", if (averageCo2 != null && averageCo2 > 1000) Color(0xFFFF8A66) else Color(0xFF48C49D))
                    HomeStatusChip("☼", "Свет", "$activeLights из ${lightDevices.size} вкл.", Color(0xFFAA83FF))
                    HomeStatusChip("●", "Розетки", "$activeSockets из ${socketDevices.size} вкл.", Color(0xFF8E72EF))
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }, key = "location_weather") {
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(
                            colors = weatherPanel,
                            start = Offset.Zero,
                            end = Offset(900f, 500f)
                        )
                    )
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                    .padding(horizontal = weatherHorizontalPadding, vertical = weatherVerticalPadding)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                Text("ПОГОДА РЯДОМ", color = weatherMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                                Text(
                                    weather?.placeName ?: "Текущая погода",
                                    color = weatherInk,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            TextButton(
                                onClick = onRefreshWeather,
                                enabled = !weatherLoading,
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                if (weatherLoading) CircularProgressIndicator(Modifier.size(16.dp), color = weatherInk, strokeWidth = 1.8.dp)
                                else Text("↻", color = weatherInk, fontSize = 20.sp)
                            }
                        }
                        if (weather != null) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                Text(
                                    "${"%.0f".format(Locale.getDefault(), weather.temperatureC)}°",
                                    color = weatherInk,
                                    fontSize = weatherTemperatureSize,
                                    fontWeight = FontWeight.Light,
                                    lineHeight = weatherTemperatureSize
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(weather.description, color = weatherInk, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("Сейчас", color = weatherMuted, fontSize = 10.sp)
                                }
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(top = 5.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("ВЕТЕР", color = weatherMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                                    Text("${"%.1f".format(Locale.getDefault(), weather.windMetersPerSecond)} м/с", color = weatherInk, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("ВЛАЖНОСТЬ", color = weatherMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                                    Text("${weather.humidityPercent}%", color = weatherInk, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("ОСАДКИ", color = weatherMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                                    Text("${"%.1f".format(Locale.getDefault(), weather.precipitationMm)} мм", color = weatherInk, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Text(if (weatherLoading) "Определяем погоду…" else "Показывать погоду по местоположению", color = weatherInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(
                                if (weatherError.isNotBlank()) weatherError else "Разреши доступ к местоположению, чтобы увидеть погоду рядом с домом.",
                                color = if (weatherError.isNotBlank()) MaterialTheme.colorScheme.error else weatherMuted,
                                fontSize = 10.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!weatherLoading) {
                                TextButton(onClick = onRefreshWeather, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 1.dp)) {
                                    Text("Включить погоду", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.size(4.dp))
                    YandexWeatherArtwork(weather?.weatherCode ?: -1, Modifier.size(weatherArtworkSize))
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }, key = "home_actions") {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HomeQuickButton("Устройства", MaterialTheme.colorScheme.primary, onOpenDevices, Modifier.widthIn(min = 112.dp))
                HomeQuickButton("Группы", MaterialTheme.colorScheme.secondary, onOpenGroups, Modifier.widthIn(min = 112.dp))
                HomeQuickButton("Сценарии", MaterialTheme.colorScheme.tertiary, onOpenScenarios, Modifier.widthIn(min = 112.dp))
                HomeQuickButton("Автоматизации", MaterialTheme.colorScheme.primary, onOpenAutomations, Modifier.widthIn(min = 130.dp))
                HomeQuickButton("Датчики", MaterialTheme.colorScheme.secondary, onAnalytics, Modifier.widthIn(min = 112.dp))
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }, key = "room_previews") {
            if (homeRoomCards.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Комнаты", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${homeRoomCards.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        homeRoomCards.forEachIndexed { index, room ->
                            val roomDevices = devices.filter { it.room == room }
                            val active = roomDevices.count { it.isOnline && it.onOff == true }
                            val shades = if (darkUi) {
                                listOf(listOf(Color(0xFF2B3654), Color(0xFF202B40)), listOf(Color(0xFF3C3156), Color(0xFF282B43)), listOf(Color(0xFF27454A), Color(0xFF202F3E)))
                            } else {
                                listOf(listOf(Color(0xFFE9E5FA), Color(0xFFE3EDF6)), listOf(Color(0xFFF0E7F7), Color(0xFFE9EAF8)), listOf(Color(0xFFE0F1EE), Color(0xFFE8EDF8)))
                            }
                            val roomShape = RoundedCornerShape(18.dp)
                            Column(
                                Modifier.width(132.dp).height(88.dp).clip(roomShape)
                                    .background(Brush.linearGradient(shades[index % shades.size]))
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), roomShape)
                                    .clickable { selectedCategory = "Все"; deviceSearch = room }
                                    .padding(11.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                SmartGlyph("home", Modifier.size(22.dp), if (darkUi) Color(0xFFD5C5FF) else MaterialTheme.colorScheme.primary)
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(room, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${roomDevices.size} устройств · $active вкл.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }, key = "device_search") {
            OutlinedTextField(
                value = deviceSearch,
                onValueChange = { deviceSearch = it.take(64) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Найти устройство или комнату") },
                shape = RoundedCornerShape(17.dp)
            )
        }
        item(span = { GridItemSpan(maxLineSpan) }, key = "device_categories") {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Все", "Проблемы", "Свет", "Медиа", "Избранное", "Розетки", "Климат", "Безопасность", "Датчики").forEach { category ->
                    val count = when (category) {
                        "Все" -> devices.size
                        "Не в сети" -> offlineCount
                        "Избранное" -> favoriteDevices.size
                        "Проблемы" -> devices.count(::deviceNeedsAttention)
                        "Свет" -> lightDevices.size
                        else -> devices.count { dashboardDeviceCategory(it) == category }
                    }
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(if (category == "Проблемы") "$category $count" else category, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
        if (visibleDevices.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }, key = "empty_devices") {
                if (isLoading) {
                    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("Загружаем дом", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Главная уже открыта. Устройства появятся здесь после ответа API.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                            }
                        }
                    }
                } else {
                    EmptyCard("Устройства не найдены. Проверь, что они добавлены в Дом с Алисой.")
                }
            }
        } else {
            item(span = { GridItemSpan(maxLineSpan) }, key = "devices_section_header") {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Устройства", fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${visibleDevices.size}", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f), fontSize = 11.sp)
                }
            }
            customGroups.forEach { group ->
                val members = visibleDevices.filter { it.id in group.deviceIds }
                if (members.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "group_${group.id}") {
                        GroupGridHeader(
                            title = group.name,
                            members = members,
                            pending = pendingDeviceIds,
                            onToggleGroup = onToggleGroup,
                            onOpenGroup = { onOpenGroup(group) }
                        )
                    }
                    gridItems(members, key = { "device_${it.id}" }) { device ->
                        CompactDeviceTile(
                            device = device,
                            enabled = !isBusy && device.id !in pendingDeviceIds,
                            pending = device.id in pendingDeviceIds,
                            cardSize = cardSize,
                            cardWidthDp = cardWidthDp,
                            cardHeightDp = cardHeightDp,
                            onFavorite = { onFavoriteChange(device, it) },
                            onOpen = { onOpenDevice(device) },
                            onToggle = { onToggle(device, it) }
                        )
                    }
                }
            }
            allRooms.forEach { roomName ->
                val roomDevices = ungroupedByRoom[roomName].orEmpty()
                if (roomDevices.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "room_$roomName") {
                        val switchableRoomDevices = roomDevices.filter { it.canToggle && it.isOnline }
                        val roomIsOn = switchableRoomDevices.isNotEmpty() && switchableRoomDevices.all { it.onOff == true }
                        val roomHasPending = switchableRoomDevices.any { it.id in pendingDeviceIds }
                        Row(Modifier.fillMaxWidth().padding(top = 9.dp, bottom = 1.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(roomName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Text(roomDevices.size.toString() + " устройств", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                            }
                            if (switchableRoomDevices.isNotEmpty()) {
                                TextButton(
                                    onClick = { onToggleGroup(switchableRoomDevices, !roomIsOn) },
                                    enabled = !isBusy && !roomHasPending,
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text(if (roomIsOn) "Выключить всё" else "Включить всё", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    gridItems(roomDevices, key = { "device_${it.id}" }) { device ->
                        CompactDeviceTile(
                            device = device,
                            enabled = !isBusy && device.id !in pendingDeviceIds,
                            pending = device.id in pendingDeviceIds,
                            cardSize = cardSize,
                            cardWidthDp = cardWidthDp,
                            cardHeightDp = cardHeightDp,
                            onFavorite = { onFavoriteChange(device, it) },
                            onOpen = { onOpenDevice(device) },
                            onToggle = { onToggle(device, it) }
                        )
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun GroupGridHeader(
    title: String,
    members: List<HomeDevice>,
    pending: Set<String>,
    onToggleGroup: (List<HomeDevice>, Boolean) -> Unit,
    onOpenGroup: () -> Unit
) {
    val switchable = members.filter { it.canToggle && it.isOnline }
    val allOn = switchable.isNotEmpty() && switchable.all { it.onOff == true }
    val hasPending = switchable.any { it.id in pending }
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 7.dp).clickable(onClick = onOpenGroup)
            .background(Brush.horizontalGradient(listOf(Color(0xFF7658BA).copy(alpha = 0.16f), Color(0xFF555A6C).copy(alpha = 0.10f))), RoundedCornerShape(18.dp))
            .padding(start = 13.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("${members.size} устройств · ${switchable.count { it.onOff == true }} включено", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
        }
        OutlinedButton(
            onClick = { onToggleGroup(switchable, !allOn) },
            enabled = switchable.isNotEmpty() && !hasPending,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 5.dp)
        ) {
            Text(if (hasPending) "…" else if (allOn) "Выключить все" else "Включить все", fontSize = 10.sp)
        }
    }
}

@Composable
private fun CompactDeviceTile(
    device: HomeDevice,
    enabled: Boolean,
    pending: Boolean,
    cardSize: String,
    cardWidthDp: Int,
    cardHeightDp: Int,
    onFavorite: (Boolean) -> Unit,
    onOpen: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    val on = device.onOff == true
    val offline = !device.isOnline
    val iconSize = when (cardSize) { "large" -> 52.dp; "small" -> 38.dp; else -> 44.dp }
    val darkUi = MaterialTheme.colorScheme.background.red < 0.5f
    val tileShape = RoundedCornerShape(19.dp)
    val background = when {
        offline -> if (darkUi) listOf(Color(0xFF382A36), Color(0xFF292B38)) else listOf(Color(0xFFFFE9ED), Color(0xFFF8F1F5))
        on -> if (darkUi) listOf(Color(0xFF393253), Color(0xFF282D42)) else listOf(Color(0xFFEDE6FF), Color(0xFFF4F1FC))
        else -> if (darkUi) listOf(Color(0xFF30394B), Color(0xFF262E40)) else listOf(Color(0xFFE9EDF5), Color(0xFFF7F8FC))
    }
    val border = when {
offline -> if (darkUi) Color(0xFFFF6879).copy(alpha = 0.28f) else Color(0xFFE8AAB5)
        on -> if (darkUi) Color(0xFF9B7BFA).copy(alpha = 0.28f) else Color(0xFFD3C4F6)
        else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f)
    }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthScale = (maxWidth.value / cardWidthDp.coerceAtLeast(92).toFloat()).coerceAtLeast(1f)
        val responsiveHeight = (cardHeightDp * widthScale).toInt().coerceIn(112, 280)
        Column(
            Modifier.fillMaxWidth()
                .height(responsiveHeight.dp)
                .clip(tileShape)
                .background(Brush.linearGradient(background, start = Offset.Zero, end = Offset(360f, 520f)))
                .border(1.dp, border, tileShape)
                .clickable(onClick = onOpen)
                .padding(horizontal = 9.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Box(Modifier.weight(1f).height(62.dp), contentAlignment = Alignment.Center) {
                    SmartGlyph(deviceIconKind(device.type, device.name), Modifier.size(iconSize),
                        when { offline -> if (darkUi) Color(0xFF8C909B) else Color(0xFF89909F); on -> if (darkUi) Color(0xFFD7C9FF) else Color(0xFF7653C6); else -> MaterialTheme.colorScheme.onSurfaceVariant })
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(25.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        .clickable { onFavorite(!device.isFavorite) }, contentAlignment = Alignment.Center) {
                        Text(if (device.isFavorite) "★" else "☆",
                            color = if (device.isFavorite) Color(0xFFFFB938) else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp)
                    }
                    if (device.canToggle) {
                        Box(Modifier.size(34.dp).clip(CircleShape)
                            .background(Brush.linearGradient(when {
                                offline -> if (darkUi) listOf(Color(0xFF70404A), Color(0xFF49333F)) else listOf(Color(0xFFE6A4AF), Color(0xFFD98091))
                                on -> listOf(Color(0xFFA47AF7), Color(0xFF7451D1))
                                else -> if (darkUi) listOf(Color(0xFF56667F), Color(0xFF39485B)) else listOf(Color(0xFF9DAAC0), Color(0xFF75849D))
                            }))
                            .clickable(enabled = enabled && !offline) { onToggle(!on) },
                            contentAlignment = Alignment.Center) {
                            if (pending) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 1.7.dp, color = Color.White)
                            else SmartGlyph(if (on) "off" else "power", Modifier.size(21.dp).padding(1.dp), Color.White)
                        }
                    }
                }
            }
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(device.name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold,
                    fontSize = if (cardSize == "large") 12.sp else 10.sp, maxLines = 2, lineHeight = 12.sp, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(
                        when { offline -> Color(0xFFFF6477); on -> Color(0xFF57D4A5); else -> Color(0xFF9CA4B2) }))
                    Text(when {
                        offline -> "Не в сети"
                        pending -> "Обновление…"
                        on -> "Включено"
                        device.onOff == false -> "Выключено"
                        else -> device.room.ifBlank { "В сети" }
                    }, color = if (offline) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun DeviceDetailsScreen(
    device: HomeDevice,
    isBusy: Boolean,
    onFavorite: (Boolean) -> Unit,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 15.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item(key = "device_hero") {
            val offline = !device.isOnline
            val active = device.onOff == true
            val darkUi = MaterialTheme.colorScheme.background.red < 0.5f
            val heroInk = MaterialTheme.colorScheme.onSurface
            val heroMuted = MaterialTheme.colorScheme.onSurfaceVariant
            val shape = RoundedCornerShape(26.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape)
                    .background(Brush.linearGradient(when {
                        offline -> if (darkUi) listOf(Color(0xFF3A2938), Color(0xFF282A38)) else listOf(Color(0xFFFFE8ED), Color(0xFFF7EDF1))
                        active -> if (darkUi) listOf(Color(0xFF42345E), Color(0xFF29313F), Color(0xFF252D37)) else listOf(Color(0xFFE9E0FF), Color(0xFFEAF0FB), Color(0xFFF7F1FC))
                        else -> if (darkUi) listOf(Color(0xFF343B49), Color(0xFF282D38)) else listOf(Color(0xFFE8ECF4), Color(0xFFF8F9FC))
                    }, start = Offset.Zero, end = Offset(900f, 800f)))
                    .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), shape).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(device.room.ifBlank { "МОЙ ДОМ" }.uppercase(), color = heroMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(ApiTextRu.translate(device.type), color = heroMuted, fontSize = 10.sp)
                    }
                    TextButton(onClick = { onFavorite(!device.isFavorite) }, contentPadding = PaddingValues(4.dp)) {
                        Text(if (device.isFavorite) "★" else "☆", color = if (device.isFavorite) Color(0xFFFFB938) else heroMuted, fontSize = 22.sp)
                    }
                }
                Box(Modifier.size(118.dp), contentAlignment = Alignment.Center) {
                    if (active && !offline) Box(Modifier.size(108.dp).clip(CircleShape).background(Color(0xFF9D79F3).copy(alpha = 0.12f)))
                    SmartGlyph(deviceIconKind(device.type, device.name), Modifier.size(82.dp),
                        when { offline -> Color(0xFF8F929D); active -> if (darkUi) Color(0xFFE0D4FF) else Color(0xFF7653C6); else -> heroMuted })
                }
                Text(device.name, color = heroInk, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (offline) Color(0xFFFF6578) else if (active) Color(0xFF5BD5A8) else Color(0xFF9CA4B2)))
                    Text(when { offline -> "Не в сети"; active -> "Включено"; device.onOff == false -> "Выключено"; else -> "Подключено" },
                        color = if (offline) MaterialTheme.colorScheme.error else heroMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                if (device.canToggle) {
                    Button(onClick = { onToggle(!active) }, enabled = !isBusy && device.isOnline,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSecondaryContainer, disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant, disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                    ) { Text(if (active) "Выключить" else "Включить", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item(key = "device_controls") {
            DeviceCard(device = device, isBusy = isBusy, onToggle = onToggle, onBrightness = onBrightness,
                onHue = onHue, onTemperature = onTemperature, onColorScene = onColorScene, onMode = onMode)
        }
        if (device.properties.isNotEmpty()) {
            item(key = "device_sensor_heading") { Text("Показатели устройства", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp)) }
            items(device.properties, key = { "property_\${device.id}_\${it.instance}" }) { property ->
                SensorVisualization(property = property, device = device, modifier = Modifier.fillMaxWidth().height(106.dp))
            }
        }
    }
}

@Composable
private fun GroupsScreen(
    groups: List<DeviceGroup>,
    devices: List<HomeDevice>,
    onOpenGroup: (DeviceGroup) -> Unit,
    onSave: (DeviceGroup) -> Unit,
    onDelete: (DeviceGroup) -> Unit
) {
    var editorOpen by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf("") }
    var draftName by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    fun edit(group: DeviceGroup?) {
        editingId = group?.id.orEmpty()
        draftName = group?.name.orEmpty()
        selectedIds = group?.deviceIds?.toSet().orEmpty()
        editorOpen = true
    }
    val darkUi = MaterialTheme.colorScheme.background.red < 0.5f
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 15.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("КОМНАТЫ И ГРУППЫ", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("Управляй вместе", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
            Text("\${groups.size}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
        }
        Text("Объединяй устройства для быстрого доступа и общего управления. Эти группы не меняют комнаты в приложении Яндекса.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f))
        Button(onClick = { edit(null) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("＋  Создать группу", fontWeight = FontWeight.SemiBold) }
        if (groups.isEmpty()) EmptyCard("Пока нет групп. Создай первую и выбери устройства для неё.")
        groups.forEach { group ->
            val members = devices.filter { it.id in group.deviceIds }
            val online = members.count { it.isOnline }
            val active = members.count { it.isOnline && it.onOff == true }
            val tileShape = RoundedCornerShape(21.dp)
            Column(
                Modifier.fillMaxWidth().clip(tileShape)
                    .background(Brush.linearGradient(if (darkUi) listOf(Color(0xFF263047), Color(0xFF202A3D)) else listOf(Color(0xFFFFFFFF), Color(0xFFECEBFA))))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.68f), tileShape)
                    .clickable { onOpenGroup(group) }.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                        SmartGlyph("grid", Modifier.size(25.dp), MaterialTheme.colorScheme.primary)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(group.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("\${members.size} устройств · $online в сети · $active включено", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("›", color = MaterialTheme.colorScheme.primary, fontSize = 27.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    members.take(5).forEach { device ->
                        Box(Modifier.size(31.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                            SmartGlyph(deviceIconKind(device.type, device.name), Modifier.size(19.dp), if (device.isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (members.size > 5) Text("+\${members.size - 5}", modifier = Modifier.align(Alignment.CenterVertically), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.66f), fontSize = 10.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { edit(group) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Изменить") }
                    TextButton(onClick = { onDelete(group) }, modifier = Modifier.weight(1f)) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
    if (editorOpen) {
        AlertDialog(
            onDismissRequest = { editorOpen = false },
            title = { Text(if (editingId.isBlank()) "Новая группа" else "Изменить группу") },
            text = {
                Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(value = draftName, onValueChange = { draftName = it.take(40) }, label = { Text("Название группы") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Устройства", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    if (devices.isEmpty()) Text("Сначала подключи устройства.", fontSize = 12.sp)
                    devices.forEach { device ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = device.id in selectedIds, onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + device.id else selectedIds - device.id })
                            SmartGlyph(deviceIconKind(device.type, device.name), Modifier.size(21.dp), if (device.isOnline) MaterialTheme.colorScheme.primary else Color.Gray)
                            Column(Modifier.weight(1f)) {
                                Text(device.name, fontSize = 12.sp)
                                Text(device.room.ifBlank { if (device.isOnline) "В сети" else "Не в сети" }, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = draftName.isNotBlank() && selectedIds.isNotEmpty(), onClick = {
                    val id = editingId.ifBlank { java.util.UUID.randomUUID().toString() }
                    onSave(DeviceGroup(id, draftName.trim(), selectedIds.toList()))
                    editorOpen = false
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { editorOpen = false }) { Text("Отмена") } }
        )
    }
}

private fun groupDeviceFamily(type: String): String {
    val value = type.lowercase().removePrefix("devices.types.")
    return when {
        value.startsWith("light") || value.contains("lamp") -> "light"
        value.startsWith("socket") || value.startsWith("switch") -> "switch"
        value.startsWith("thermostat") || value.startsWith("climate") -> "climate"
        value.startsWith("sensor") -> "sensor"
        value.startsWith("openable.curtain") || value.startsWith("openable.blind") -> "curtain"
        value.startsWith("media_device.tv") -> "tv"
        else -> value.substringBefore('.')
    }
}

@Composable
private fun GroupDetailsScreen(
    group: DeviceGroup,
    devices: List<HomeDevice>,
    isBusy: Boolean,
    onToggle: (List<HomeDevice>, Boolean) -> Unit,
    onColor: (List<HomeDevice>, String, Int) -> Unit,
    onMode: (List<HomeDevice>, String, String) -> Unit,
    onOpenDevice: (HomeDevice) -> Unit
) {
    val switchable = devices.filter { it.canToggle && it.isOnline }
    val allOn = switchable.isNotEmpty() && switchable.all { it.onOff == true }
    val onlineDevices = devices.filter { it.isOnline }
    val colorGroups = onlineDevices.filter { it.colorCapability != null }.groupBy { device ->
        val capability = device.colorCapability!!
        (capability.colorModel ?: capability.instance).takeIf { it == "hsv" || it == "rgb" } ?: ""
    }.filterKeys { it.isNotBlank() }
    val commonColorGroup = colorGroups.entries.maxByOrNull { it.value.size }?.takeIf { it.value.size > 1 }
    val isHomogeneous = devices.map { groupDeviceFamily(it.type) }.distinct().size <= 1
    val modeCapableDevices = onlineDevices.filter { it.modeCapabilities.isNotEmpty() }
    val modeInstances = modeCapableDevices.flatMap { it.modeCapabilities.map { capability -> capability.instance } }.distinct()
    val modeOptions = modeInstances.flatMap { instance ->
        val compatible = modeCapableDevices.filter { device -> device.modeCapabilities.any { it.instance == instance } }
        if (compatible.size < 2) emptyList() else {
            val commonValues = compatible.map { device -> device.modeCapabilities.first { it.instance == instance }.modeOptions.toSet() }
                .reduce { common, values -> common intersect values }
            commonValues.sorted().map { value -> Triple(instance, value, "$instance: $value") }
        }
    }
    val grouped = devices.groupBy { it.type.ifBlank { "Устройства" } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Управление группой", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${devices.size} устройств · ${switchable.count { it.onOff == true }} включено", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Button(onClick = { onToggle(switchable, !allOn) }, enabled = switchable.isNotEmpty() && !isBusy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (allOn) "Выключить все" else "Включить все")
                }
                if (isHomogeneous && commonColorGroup != null) {
                    val colorDevices = commonColorGroup.value
                    val colorModel = commonColorGroup.key
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Text("Общий цвет · ${colorDevices.size} устройств", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        listOf(0, 25, 50, 90, 130, 180, 210, 260, 310).forEach { hue ->
                            Box(Modifier.size(34.dp).background(Color.hsv(hue.toFloat(), 0.95f, 1f), CircleShape)
                                .border(2.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f), CircleShape)
                                .clickable(enabled = !isBusy) { onColor(colorDevices, colorModel, hue) })
                        }
                    }
                }
                if (isHomogeneous && modeOptions.isNotEmpty()) {
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Text("Общий режим", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    modeOptions.forEach { option ->
                        OutlinedButton(onClick = { onMode(modeCapableDevices.filter { device -> device.modeCapabilities.any { it.instance == option.first && option.second in it.modeOptions } }, option.first, option.second) }, enabled = !isBusy, modifier = Modifier.fillMaxWidth()) {
                            Text(option.second, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (!isHomogeneous) Text("Группа содержит разные типы устройств. Общие цвет и режим доступны только для одинаковых совместимых устройств.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                else if (commonColorGroup == null && onlineDevices.none { it.colorCapability != null }) Text("Устройства этой группы не поддерживают общий цвет.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
        if (devices.isEmpty()) EmptyCard("В этой группе пока нет устройств.")
        grouped.forEach { (type, members) ->
            Text(type.replace('_', ' '), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            members.forEach { device ->
                Card(modifier = Modifier.fillMaxWidth().clickable { onOpenDevice(device) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SmartGlyph(deviceIconKind(device.type, device.name), Modifier.size(30.dp), if (device.isOnline) MaterialTheme.colorScheme.primary else Color.Gray)
                        Column(Modifier.weight(1f)) {
                            Text(device.name, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(if (device.isOnline) device.room.ifBlank { "В сети" } else "НЕ В СЕТИ", color = if (device.isOnline) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f) else Color(0xFFFF5968), fontSize = 10.sp)
                        }
                        Text("Открыть →", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceCard(
    device: HomeDevice,
    isBusy: Boolean,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    var sliderValue by remember(device.id, device.brightness) { mutableFloatStateOf((device.brightness ?: device.brightnessMin).toFloat()) }
    val colorCapability = device.colorCapability
    var hue by remember(device.id) { mutableFloatStateOf(210f) }
    var temperature by remember(device.id, colorCapability?.value) {
        mutableFloatStateOf((colorCapability?.value as? Number)?.toFloat() ?: ((colorCapability?.temperatureMin ?: 2700) + (colorCapability?.temperatureMax ?: 6500)) / 2f)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Управление устройством", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                if (device.canToggle) {
                    Button(onClick = { onToggle(device.onOff != true) }, enabled = !isBusy && device.isOnline) {
                        Text(if (device.onOff == true) "Выключить" else "Включить", fontSize = 12.sp)
                    }
                }
            }
            if (!device.isOnline) {
                Text("Устройство не в сети. Управление временно недоступно.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            if (device.canDim && device.brightness != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Яркость", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Spacer(Modifier.weight(1f))
                    Text("${sliderValue.toInt()}%", fontSize = 12.sp)
                }
                val lower = device.brightnessMin.toFloat()
                val upper = device.brightnessMax.toFloat().coerceAtLeast(lower + 1f)
                GradientControlSlider(
                    value = sliderValue.coerceIn(lower, upper), valueRange = lower..upper,
                    gradient = if (MaterialTheme.colorScheme.background.red < 0.5f) listOf(Color(0xFF34224F), Color(0xFF7650B5), Color(0xFFB98BFF), Color(0xFFF5ECFF)) else listOf(Color(0xFFB7A1E9), Color(0xFF9070D8), Color(0xFF7653C6), Color(0xFF4D3990)),
                    onValueChange = { sliderValue = it },
                    onValueChangeFinished = { onBrightness(sliderValue.toInt()) }, enabled = !isBusy && device.isOnline
                )
            }
            if (colorCapability != null) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(modifier = Modifier.size(44.dp).background(Color.hsv(hue, 0.92f, 1f), CircleShape))
                    Column {
                        Text("Цвет лампы", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Предпросмотр оттенка", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    }
                }
                if (colorCapability.colorModel == "rgb" || colorCapability.colorModel == "hsv") {
                    Text("Выбери оттенок", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(0f, 25f, 55f, 115f, 175f, 210f, 270f, 325f).forEach { presetHue ->
                            Box(modifier = Modifier.size(29.dp).background(Color.hsv(presetHue, 1f, 1f), CircleShape)
                                .clickable(enabled = !isBusy && device.isOnline) { hue = presetHue; onHue(presetHue.toInt()) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Тон", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                        Spacer(Modifier.width(8.dp))
                        GradientControlSlider(
                            value = hue, valueRange = 0f..360f,
                            gradient = listOf(Color.Red, Color(0xFFFF9800), Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color(0xFF8B00FF), Color.Red),
                            onValueChange = { hue = it }, onValueChangeFinished = { onHue(hue.toInt()) },
                            modifier = Modifier.weight(1f), enabled = !isBusy && device.isOnline
                        )
                    }
                }
                if (colorCapability.temperatureSupported && colorCapability.temperatureMax > colorCapability.temperatureMin) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Температура света", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                        Spacer(Modifier.weight(1f))
                        Text("${temperature.toInt()} K", fontSize = 11.sp)
                    }
                    GradientControlSlider(
                        value = temperature.coerceIn(colorCapability.temperatureMin.toFloat(), colorCapability.temperatureMax.toFloat()),
                        valueRange = colorCapability.temperatureMin.toFloat()..colorCapability.temperatureMax.toFloat(),
                        gradient = listOf(Color(0xFFFFA84A), Color(0xFFFFE7B8), Color(0xFFD4E5FF)),
                        onValueChange = { temperature = it }, onValueChangeFinished = { onTemperature(temperature.toInt()) }, enabled = !isBusy && device.isOnline
                    )
                }
                if (colorCapability.colorScenes.isNotEmpty()) {
                    Text("Световые эффекты", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        colorCapability.colorScenes.forEach { scene ->
                            FilterChip(selected = colorCapability.instance == "scene" && colorCapability.value == scene,
                                onClick = { onColorScene(scene) }, enabled = !isBusy && device.isOnline, label = { Text(sceneLabel(scene), fontSize = 11.sp) })
                        }
                    }
                }
            }
            device.modeCapabilities.forEach { capability ->
                Text(modeInstanceLabel(capability.instance), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    capability.modeOptions.forEach { mode ->
                        FilterChip(
                            selected = capability.value == mode,
                            onClick = { onMode(capability.instance, mode) },
                            enabled = !isBusy && device.isOnline,
                            label = { Text(modeLabel(mode), fontSize = 11.sp) }
                        )
                    }
                }
            }
            if (device.properties.isNotEmpty()) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Text("Показатели датчиков", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                device.properties.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                        pair.forEach { property ->
                            SensorVisualization(
                                property = property,
                                device = device,
                                modifier = Modifier.weight(1f).height(126.dp)
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f).aspectRatio(1f))
                    }
                }
                device.properties.filter { it.value is Number }.forEach { property ->
                    SensorHistoryChart(deviceId = device.id, property = property)
                }
            }
            if (!device.canToggle && !device.canDim && colorCapability == null && device.modeCapabilities.isEmpty() && device.properties.isEmpty()) {
                Text("Устройство доступно для просмотра, но API не предоставил поддерживаемых элементов управления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
            val context = LocalContext.current
            val deviceChanges = HomeHistoryStore.load(context).filter { change ->
                change.deviceId == device.id || (change.deviceId == null && change.detail.contains(device.name, ignoreCase = true))
            }.take(5)
            if (deviceChanges.isNotEmpty()) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconTile("clock", Modifier.size(30.dp), iconSize = 18.dp, active = true)
                    Text("История устройства", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                deviceChanges.forEach { change ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.padding(top = 5.dp).size(6.dp).background(Color(0xFF49C6B1), CircleShape))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(change.detail, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            Text(SimpleDateFormat("dd.MM · HH:mm", Locale.getDefault()).format(Date(change.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                        }
                    }
                }
            } else {
                Text("История изменений появится после первого изменения состояния.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
    }
}

@Composable
private fun GradientControlSlider(
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    gradient: List<Color>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val insetPx = with(density) { 12.dp.toPx() }
    val currentChange by rememberUpdatedState(onValueChange)
    val currentFinished by rememberUpdatedState(onValueChangeFinished)
    val rangeStart = valueRange.start
    val rangeEnd = valueRange.endInclusive.coerceAtLeast(rangeStart + 0.001f)

    fun updateFromX(x: Float, width: Float) {
        val usableWidth = (width - insetPx * 2f).coerceAtLeast(1f)
        val fraction = ((x - insetPx) / usableWidth).coerceIn(0f, 1f)
        currentChange(rangeStart + (rangeEnd - rangeStart) * fraction)
    }

    val touchModifier = Modifier
        .pointerInput(enabled, valueRange) {
            if (enabled) {
                detectTapGestures(onTap = { point ->
                    updateFromX(point.x, size.width.toFloat())
                    currentFinished()
                })
            }
        }
        .pointerInput(enabled, valueRange) {
            if (enabled) {
                detectDragGestures(
                    onDragStart = { point -> updateFromX(point.x, size.width.toFloat()) },
                    onDrag = { change, _ ->
                        change.consume()
                        updateFromX(change.position.x, size.width.toFloat())
                    },
                    onDragEnd = { currentFinished() }
                )
            }
        }

    Box(
        modifier = modifier.fillMaxWidth().height(42.dp).then(touchModifier),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val left = insetPx
            val right = (size.width - insetPx).coerceAtLeast(left + 1f)
            val centerY = size.height / 2f
            val trackHeight = 7.dp.toPx()
            val radius = trackHeight / 2f
            val fraction = ((value - rangeStart) / (rangeEnd - rangeStart)).coerceIn(0f, 1f)
            val thumbX = left + (right - left) * fraction
            drawRoundRect(
                color = Color(0xFF8A7A9F).copy(alpha = if (enabled) 0.22f else 0.10f),
                topLeft = Offset(left, centerY - radius),
                size = androidx.compose.ui.geometry.Size(right - left, trackHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius)
            )
            drawRoundRect(
                brush = Brush.horizontalGradient(colors = gradient, startX = left, endX = right),
                topLeft = Offset(left, centerY - radius),
                size = androidx.compose.ui.geometry.Size(right - left, trackHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius)
            )
            drawCircle(Color.Black.copy(alpha = 0.22f), 10.dp.toPx(), Offset(thumbX, centerY + 1.dp.toPx()))
            drawCircle(Color(0xFFF8F2FF), 9.dp.toPx(), Offset(thumbX, centerY))
            drawCircle(if (enabled) Color(0xFF7546C8) else Color(0xFF8B8296), 5.5.dp.toPx(), Offset(thumbX, centerY))
        }
    }
}

@Composable
private fun SensorVisualization(
    property: ru.dislive.yandexhomewidgets.data.HomeProperty,
    device: HomeDevice? = null,
    modifier: Modifier = Modifier.fillMaxWidth().height(118.dp)
) {
    var expanded by remember(device?.id, property.instance) { mutableStateOf(false) }
    val valueText = sensorValue(property.instance, property.value)
    val isDoor = property.instance.lowercase() in setOf("open", "contact", "door_open", "opening")
    val isActive = when (val value = property.value) {
        is Boolean -> value
        is Number -> value.toInt() != 0
        is String -> value.lowercase() in setOf("open", "opened", "true", "detected", "1", "on")
        else -> false
    }
    val palette = sensorPalette(property.instance)
    val fill = sensorFillFraction(property.instance, property.value, isActive)
    val layoutStyle = kotlin.math.abs(property.instance.hashCode()) % 3
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier.then(if (device != null) Modifier.clickable { expanded = true } else Modifier)
    ) {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp))) {
            // A vertical, rounded fill gives the sensor a compact visual identity instead of a progress bar.
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(fill)
                    .background(Brush.verticalGradient(listOf(palette.first.copy(alpha = 0.24f), palette.second.copy(alpha = 0.42f))))
            )
            when (layoutStyle) {
                0 -> Row(Modifier.fillMaxSize().padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    IconTile(sensorIconKind(property.instance), Modifier.size(42.dp), iconSize = 25.dp, active = true)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(sensorLabel(property.instance), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f), maxLines = 2)
                        Text(if (isDoor) if (isActive) "Открыто" else "Закрыто" else valueText,
                            fontSize = 15.sp, fontWeight = FontWeight.Bold, color = palette.third, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                1 -> Column(Modifier.fillMaxSize().padding(11.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(sensorLabel(property.instance), Modifier.weight(1f), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f), maxLines = 2)
                        IconTile(sensorIconKind(property.instance), Modifier.size(34.dp), iconSize = 21.dp, active = true)
                    }
                    Text(if (isDoor) if (isActive) "Открыто" else "Закрыто" else valueText,
                        fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = palette.third, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                else -> Row(Modifier.fillMaxSize().padding(11.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(sensorLabel(property.instance), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f), maxLines = 2)
                        Text(if (isDoor) if (isActive) "Открыто" else "Закрыто" else valueText,
                            fontSize = 15.sp, fontWeight = FontWeight.Bold, color = palette.third, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    IconTile(sensorIconKind(property.instance), Modifier.size(40.dp), iconSize = 23.dp, active = true)
                }
            }
        }
    }
    if (expanded && device != null) SensorDetailDialog(device, property) { expanded = false }
}

private data class SensorPalette(val first: Color, val second: Color, val third: Color)

private fun sensorPalette(instance: String): SensorPalette = when (instance) {
    "temperature" -> SensorPalette(Color(0xFFFF8A65), Color(0xFFE64F86), Color(0xFFFFA078))
    "humidity" -> SensorPalette(Color(0xFF40C4FF), Color(0xFF1976D2), Color(0xFF65CFFF))
    "pressure" -> SensorPalette(Color(0xFF8E9BFF), Color(0xFF5365C8), Color(0xFF9BA9FF))
    "battery_level" -> SensorPalette(Color(0xFF6DDB9A), Color(0xFF219B72), Color(0xFF65D99B))
    "illumination" -> SensorPalette(Color(0xFFFFD166), Color(0xFFFF9F43), Color(0xFFFFC45A))
    "co2_level", "pm1_density", "pm2.5_density", "pm10_density" -> SensorPalette(Color(0xFF58D6C3), Color(0xFF278C9D), Color(0xFF68DCCB))
    "motion", "vibration" -> SensorPalette(Color(0xFFFFA45F), Color(0xFFE66A4E), Color(0xFFFFA46C))
    "water_leak", "smoke", "gas" -> SensorPalette(Color(0xFFFF788E), Color(0xFFD94168), Color(0xFFFF8CA2))
    else -> SensorPalette(Color(0xFFB58BFF), Color(0xFF7153C9), Color(0xFFC1A0FF))
}

private fun sensorFillFraction(instance: String, value: Any?, active: Boolean): Float {
    val numeric = (value as? Number)?.toFloat()
    val ratio = when (instance) {
        "temperature" -> numeric?.let { (it + 10f) / 60f }
        "humidity", "battery_level" -> numeric?.div(100f)
        "pressure" -> numeric?.let { (it - 900f) / 300f }
        "illumination" -> numeric?.div(1000f)
        "co2_level" -> numeric?.let { (it - 400f) / 1600f }
        "pm1_density", "pm2.5_density", "pm10_density" -> numeric?.div(150f)
        "voltage" -> numeric?.div(24f)
        "power" -> numeric?.div(1500f)
        else -> null
    }
    return (ratio?.coerceIn(0.08f, 0.92f) ?: if (active) 0.72f else 0.24f)
}

@Composable
private fun SensorDetailDialog(device: HomeDevice, property: ru.dislive.yandexhomewidgets.data.HomeProperty, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.68f)).clickable { onDismiss() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(0.91f)
                    .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { },
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(width = 42.dp, height = 4.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f), RoundedCornerShape(20.dp)))
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IconTile(deviceIconKind(device.type, device.name), Modifier.size(56.dp), iconSize = 34.dp, active = true)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(device.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(device.room.ifBlank { "Без комнаты" }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    }
                    TextButton(onClick = onDismiss) { Text("Готово") }
                }
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(sensorLabel(property.instance), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    SensorVisualization(property = property, modifier = Modifier.fillMaxWidth().height(150.dp))
                }
                Text("История измерений", Modifier.padding(horizontal = 18.dp), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                SensorHistoryChart(deviceId = device.id, property = property)
                Text("История собирается приложением с момента подключения датчика. Старые значения из API недоступны.",
                    Modifier.padding(horizontal = 18.dp), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
    }
}

private fun sensorIconKind(instance: String): String = when (instance) {
    "temperature" -> "temperature"
    "humidity" -> "humidity"
    "pressure" -> "air"
    "battery_level" -> "power"
    "illumination" -> "sun"
    "co2_level" -> "air"
    "open", "contact", "door_open", "opening" -> "door_closed"
    "motion" -> "motion"
    "water_leak" -> "leak"
    "smoke", "gas" -> "air"
    else -> "sparkles"
}



@Composable
private fun ScenariosScreen(scenarios: List<HomeScenario>, isBusy: Boolean, onRun: (HomeScenario) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Быстрые действия для дома", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f))
        if (scenarios.isEmpty()) EmptyCard("Сценарии не найдены.")
        scenarios.forEachIndexed { index, scenario ->
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            if (MaterialTheme.colorScheme.background.red < 0.5f) {
                                if (index % 2 == 0) listOf(Color(0xFF30334A), Color(0xFF252C3D)) else listOf(Color(0xFF263F43), Color(0xFF252D3B))
                            } else {
                                if (index % 2 == 0) listOf(Color(0xFFF0EAFE), Color(0xFFE7EEF8)) else listOf(Color(0xFFE3F4F0), Color(0xFFECEEF8))
                            }
                        ),
                        RoundedCornerShape(20.dp)
                    )
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(20.dp))
                    .padding(13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                Box(
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF8B5CF6).copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    SmartGlyph("sparkles", Modifier.size(22.dp), MaterialTheme.colorScheme.primary)
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(scenario.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(if (scenario.isActive) "Готов к запуску" else "Сценарий дома", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                }
                Button(
                    onClick = { onRun(scenario) },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 15.dp, vertical = 9.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.58f)
                    )
                ) { Text("Запустить", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun HistoryScreen(history: List<HomeChange>, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("АКТИВНОСТЬ ДОМА", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text("История изменений", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onClear, enabled = history.isNotEmpty()) { Text("Очистить") }
        }
        if (history.isEmpty()) EmptyCard("История пока пуста. Она начнёт заполняться после обнаружения изменений в доме.")
        else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(history, key = { "\${it.timestamp}-\${it.kind}-\${it.title}-\${it.detail}" }) { change ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.width(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                            Box(Modifier.width(1.dp).height(52.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)))
                        }
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(16.dp)).padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(change.title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(change.detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            Text(SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()).format(Date(change.timestamp)), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.48f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SensorAnalyticsScreen(devices: List<HomeDevice>) {
    val numericSensors = devices.flatMap { device ->
        device.properties.filter { it.value is Number }.map { property -> device to property }
    }
    val darkUi = MaterialTheme.colorScheme.background.red < 0.5f
    val alerts = buildList {
        devices.forEach { device ->
            device.properties.forEach propertyLoop@{ property ->
                if (property.instance == "water_leak" && (property.value == true || property.value == "detected")) {
                    add("${device.name}: датчик сообщает о воде")
                    return@propertyLoop
                }
                val value = (property.value as? Number)?.toDouble() ?: return@propertyLoop
                when {
                    property.instance == "battery_level" && value < 20 -> add("${device.name}: низкий заряд батареи (${value.toInt()}%)")
                    property.instance == "co2_level" && value > 1000 -> add("${device.name}: CO₂ выше 1000 ppm")
                }
            }
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "analytics_intro") {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnalyticsMetric("Датчики", numericSensors.size.toString(), Color(0xFF9C7BFA), Modifier.weight(1f))
                    AnalyticsMetric("Предупреждения", alerts.size.toString(), if (alerts.isEmpty()) Color(0xFF5CCDA6) else Color(0xFFFF6F82), Modifier.weight(1f))
                    AnalyticsMetric("Устройства", devices.size.toString(), Color(0xFF6FB6E9), Modifier.weight(1f))
                }
            Box(
                modifier = Modifier.fillMaxWidth().background(
                    Brush.linearGradient(if (darkUi) listOf(Color(0xFF182B47), Color(0xFF21475A), Color(0xFF1C2F45)) else listOf(Color(0xFFE3E8FA), Color(0xFFE0F0F1), Color(0xFFEEE6F7))),
                    RoundedCornerShape(22.dp)
                ).padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Тренды и состояние дома", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Локальные графики показаний за последние 24 часа или 7 дней", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                }
            }
            }
        }
        item(key = "analytics_alerts_title") { Text("На что обратить внимание", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        item(key = "analytics_alerts") {
            if (alerts.isEmpty()) {
                EmptyCard("По доступным показаниям сейчас нет активных предупреждений.")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    alerts.forEach { alert ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                            Text("• $alert", modifier = Modifier.fillMaxWidth().padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item(key = "analytics_sensors_title") { Text("История датчиков", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        if (numericSensors.isEmpty()) {
            item(key = "analytics_empty") { EmptyCard("Числовые датчики пока не найдены. Графики появятся после первого получения показаний.") }
        } else {
            items(numericSensors, key = { (device, property) -> "${device.id}_${property.instance}" }) { (device, property) ->
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("${device.name} · ${sensorLabel(property.instance)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    SensorVisualization(property = property, device = device, modifier = Modifier.fillMaxWidth().height(126.dp))
                    SensorHistoryChart(deviceId = device.id, property = property)
                }
            }
        }
    }
}

@Composable
private fun AnalyticsMetric(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(17.dp))
            .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.18f), MaterialTheme.colorScheme.surface)))
            .border(1.dp, accent.copy(alpha = 0.16f), RoundedCornerShape(17.dp))
            .padding(horizontal = 10.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(value, color = accent, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SensorHistoryChart(deviceId: String, property: ru.dislive.yandexhomewidgets.data.HomeProperty) {
    var hours by remember(deviceId, property.instance) { mutableStateOf(24) }
    val samples = SensorHistoryStore.load(LocalContext.current, deviceId, property.instance, hours)
    val chartColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.11f)
    val latest = samples.lastOrNull()?.value ?: (property.value as? Number)?.toDouble()
    val minValue = samples.minOfOrNull { it.value }
    val maxValue = samples.maxOfOrNull { it.value }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
        Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("История показаний", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Text(latest?.let { sensorValue(property.instance, it) } ?: "Нет данных", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                FilterChip(selected = hours == 24, onClick = { hours = 24 }, label = { Text("24 ч", fontSize = 10.sp) })
                Spacer(Modifier.width(4.dp))
                FilterChip(selected = hours == 168, onClick = { hours = 168 }, label = { Text("7 д", fontSize = 10.sp) })
            }
            if (samples.isEmpty()) {
                Text("История начнёт накапливаться после обновления показаний.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            } else {
                Canvas(modifier = Modifier.fillMaxWidth().height(104.dp)) {
                    val left = 3.dp.toPx()
                    val right = size.width - 3.dp.toPx()
                    val top = 8.dp.toPx()
                    val bottom = size.height - 8.dp.toPx()
                    val values = samples.map { it.value }
                    val low = values.minOrNull() ?: 0.0
                    val high = values.maxOrNull() ?: low + 1.0
                    val span = (high - low).takeIf { it > 0.0001 } ?: 1.0
                    for (line in 0..2) {
                        val y = top + (bottom - top) * line / 2f
                        drawLine(
                            color = gridColor,
                            start = Offset(left, y), end = Offset(right, y), strokeWidth = 1.dp.toPx()
                        )
                    }
                    val path = Path()
                    samples.forEachIndexed { index, sample ->
                        val x = if (samples.size <= 1) (left + right) / 2f else left + (right - left) * index / (samples.size - 1).toFloat()
                        val y = bottom - ((sample.value - low) / span).toFloat() * (bottom - top)
                        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, color = chartColor, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                    val last = samples.last()
                    val lastY = bottom - ((last.value - low) / span).toFloat() * (bottom - top)
                    drawCircle(color = chartColor, radius = 4.dp.toPx(), center = Offset(right, lastY))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(minValue?.let { "Мин. ${"%.1f".format(Locale.getDefault(), it)}" } ?: "", modifier = Modifier.weight(1f), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Text("${samples.size} точек · локально", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Text(maxValue?.let { "Макс. ${"%.1f".format(Locale.getDefault(), it)}" } ?: "", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                }
                val firstDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(samples.first().timestamp))
                val lastDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(samples.last().timestamp))
                Text("$firstDate — $lastDate", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    isDarkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit,
    glassOpacity: Float,
    onGlassOpacityChange: (Float) -> Unit,
    deviceCardSize: String,
    onDeviceCardSizeChange: (String) -> Unit,
    deviceCardWidthDp: Int,
    deviceCardHeightDp: Int,
    onDeviceCardSizeSave: (Int, Int) -> Unit,
    deviceColumns: Int,
    onDeviceColumnsChange: (Int) -> Unit,
    weatherCardSize: String,
    onWeatherCardSizeChange: (String) -> Unit,
    weatherSource: String,
    yandexWeatherApiKey: String,
    onWeatherSettingsSave: (String, String) -> Unit,
    scenarioCardSize: String,
    onScenarioCardSizeChange: (String) -> Unit,
    autoRefreshSeconds: Int,
    onAutoRefreshChange: (Int) -> Unit,
    options: HomeNotificationOptions,
    onNotificationChange: (HomeNotificationOptions) -> Unit,
    updateMessage: String,
    updateInfo: AppUpdateInfo?,
    isCheckingUpdate: Boolean,
    onCheckUpdates: () -> Unit,
    onDisconnect: () -> Unit,
    onNotificationPermission: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 15.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("ПЕРСОНАЛИЗАЦИЯ И СИСТЕМА", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.15.sp)
            Text("Приложение и дом", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Оформление", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                SettingSwitch("Тёмная тема", isDarkTheme, onThemeChange)
                Text(if (isDarkTheme) "Тёмный градиент с мягкими цветными бликами." else "Светлая тема приложения.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Стеклянный эффект", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${(glassOpacity * 100).toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Text("Прозрачность карточек, панелей и основных кнопок.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Slider(value = glassOpacity, onValueChange = onGlassOpacityChange, valueRange = 0.55f..0.96f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Больше стекла", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Text("Плотнее", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Устройств в строке", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Авто подбирает максимально возможное число колонок (до трёх) по ширине экрана и размеру карточек. Можно также зафиксировать 1, 2 или 3 колонки.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(0, 1, 2, 3).forEach { count -> FilterChip(selected = deviceColumns == count, onClick = { onDeviceColumnsChange(count) }, label = { Text(if (count == 0) "Авто" else count.toString()) }) }
                }
            }
        }
        var cardEditorOpen by remember { mutableStateOf(false) }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Размер карточек устройств", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Ширина ${deviceCardWidthDp} dp · высота ${deviceCardHeightDp} dp", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Button(onClick = { cardEditorOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Настроить размеры карточек") }
            }
        }
        if (cardEditorOpen) DeviceCardSizeEditorDialog(
            initialWidth = deviceCardWidthDp,
            initialHeight = deviceCardHeightDp,
            onDismiss = { cardEditorOpen = false },
            onSave = { width, height -> onDeviceCardSizeSave(width, height); cardEditorOpen = false }
        )
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Размер блока погоды", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("small" to "Компактный", "normal" to "Обычный", "large" to "Крупный").forEach { (size, label) -> FilterChip(selected = weatherCardSize == size, onClick = { onWeatherCardSizeChange(size) }, label = { Text(label, fontSize = 10.sp) }) }
                }
            }
        }
        var weatherKeyInput by remember(yandexWeatherApiKey) { mutableStateOf(yandexWeatherApiKey) }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Источник погоды", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    FilterChip(selected = weatherSource == "open_meteo", onClick = { onWeatherSettingsSave("open_meteo", weatherKeyInput) }, label = { Text("Open-Meteo") })
                    FilterChip(selected = weatherSource == "yandex", onClick = { onWeatherSettingsSave("yandex", weatherKeyInput) }, label = { Text("Яндекс Погода") })
                }
                if (weatherSource == "yandex") {
                    OutlinedTextField(value = weatherKeyInput, onValueChange = { weatherKeyInput = it }, label = { Text("API-ключ Яндекс Погоды") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Сейчас используется endpoint тестового тарифа /v2/forecast. У другого тарифа может быть другой URL и объём данных.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    Button(onClick = { onWeatherSettingsSave("yandex", weatherKeyInput) }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить ключ и обновить погоду") }
                    TextButton(onClick = { openUrl(context, "https://yandex.ru/dev/weather/doc/ru/concepts/api") }) { Text("Документация API Яндекс Погоды") }
                } else Text("Open-Meteo работает без API-ключа.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Размер карточек сценариев", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Настраивает плотность списка автоматизаций.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("small" to "Компактные", "normal" to "Обычные", "large" to "Крупные").forEach { (value, title) ->
                        FilterChip(selected = scenarioCardSize == value, onClick = { onScenarioCardSizeChange(value) }, label = { Text(title, fontSize = 10.sp) })
                    }
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Автообновление", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Частота обновления устройств, пока приложение открыто.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(0 to "Выкл.", 60 to "1 мин", 180 to "3 мин", 300 to "5 мин").forEach { (seconds, label) ->
                        FilterChip(selected = autoRefreshSeconds == seconds, onClick = { onAutoRefreshChange(seconds) }, label = { Text(label, fontSize = 10.sp) })
                    }
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Уведомления", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("События устройств и запуск сценариев выводятся в системные уведомления Android/HyperOS. Внутренний центр Xiaomi Home принимает события самой экосистемы Xiaomi.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Text("События устройств и запуск сценариев выводятся в системные уведомления Android/HyperOS. Внутренний центр Xiaomi Home принимает события самой экосистемы Xiaomi.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                SettingSwitch("Все уведомления", options.enabled) { onNotificationChange(options.copy(enabled = it)) }
                if (options.enabled) {
                    Divider()
                    SettingSwitch("Устройства, комнаты и структура дома", options.deviceChanges) { onNotificationChange(options.copy(deviceChanges = it)) }
                    SettingSwitch("Изменения состояний устройств", options.capabilityChanges) { onNotificationChange(options.copy(capabilityChanges = it)) }
                    SettingSwitch("Датчики и показатели", options.sensorChanges) { onNotificationChange(options.copy(sensorChanges = it)) }
                    SettingSwitch("Группы и сценарии", options.groupScenarioChanges) { onNotificationChange(options.copy(groupScenarioChanges = it)) }
                }
                Text("Фоновая проверка выполняется примерно раз в 15 минут. Android может задерживать её; это не мгновенные push-уведомления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                OutlinedButton(onClick = onNotificationPermission, modifier = Modifier.fillMaxWidth()) { Text("Разрешения уведомлений Android") }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Обновление приложения", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Установленная версия: ${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Text(updateMessage, fontSize = 12.sp)
                if (!updateInfo?.notes.isNullOrBlank()) Text(updateInfo?.notes.orEmpty(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                Button(onClick = onCheckUpdates, enabled = !isCheckingUpdate, modifier = Modifier.fillMaxWidth()) {
                    if (isCheckingUpdate) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Проверить обновления")
                }
                if (updateInfo != null) {
                    Button(onClick = { openUrl(context, updateInfo.apkUrl ?: updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Скачать APK ${updateInfo.version} · ${updateInfo.apkVariant}")
                    }
                    TextButton(onClick = { openUrl(context, updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Описание версии на GitHub")
                    }
                }
                Text("Подбирается APK с подписью, совместимой с установленной версией приложения. После загрузки открой файл из загрузок и подтверди установку в Android.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
            }
        }
        OutlinedButton(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) { Text("Отключить Яндекс") }
    }
}

@Composable
private fun DeviceCardSizeEditorDialog(
    initialWidth: Int,
    initialHeight: Int,
    onDismiss: () -> Unit,
    onSave: (Int, Int) -> Unit
) {
    var widthDp by remember { mutableFloatStateOf(initialWidth.coerceIn(92, 260).toFloat()) }
    var heightDp by remember { mutableFloatStateOf(initialHeight.coerceIn(112, 280).toFloat()) }
    val previewGlyphs = remember { listOf("lamp", "plug", "temperature", "fan", "camera", "speaker") }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.90f),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ApplyGlassDialogBackdropBlur()
                Text("Размер карточек", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Настраивай ширину и высоту ползунками. Предпросмотр меняется сразу — больше не нужно попадать пальцем в тонкие края.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f)
                )
                Box(
                    Modifier.weight(1f).fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.24f), RoundedCornerShape(18.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            Modifier.width(widthDp.dp.coerceAtMost(270.dp))
                                .height(heightDp.dp.coerceAtMost(300.dp))
                                .background(Color(0xD91A2031), RoundedCornerShape(21.dp))
                                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.8f), RoundedCornerShape(21.dp))
                                .padding(12.dp)
                        ) {
                            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    SmartGlyph(previewGlyphs[0], Modifier.size((widthDp * 0.34f).dp.coerceIn(36.dp, 84.dp)), Color(0xFFC4A5FF))
                                    Box(Modifier.size((heightDp * 0.25f).dp.coerceIn(40.dp, 68.dp)).background(Color(0xFF36B783), CircleShape), contentAlignment = Alignment.Center) {
                                        SmartGlyph("power", Modifier.size(24.dp), Color.White)
                                    }
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Box(Modifier.fillMaxWidth(0.74f).height(8.dp).background(Color.White.copy(alpha = 0.76f), CircleShape))
                                    Box(Modifier.fillMaxWidth(0.48f).height(5.dp).background(Color.White.copy(alpha = 0.27f), CircleShape))
                                }
                            }
                        }
                        Text("Так будет выглядеть карточка на главной", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ширина", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("${widthDp.toInt()} dp", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
                Slider(value = widthDp, onValueChange = { widthDp = it }, valueRange = 92f..260f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Высота", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("${heightDp.toInt()} dp", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
                Slider(value = heightDp, onValueChange = { heightDp = it }, valueRange = 112f..280f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(onClick = { widthDp = 100f; heightDp = 128f }, modifier = Modifier.weight(1f)) { Text("Компактные", fontSize = 10.sp) }
                    OutlinedButton(onClick = { widthDp = 136f; heightDp = 146f }, modifier = Modifier.weight(1f)) { Text("Обычные", fontSize = 10.sp) }
                    OutlinedButton(onClick = { widthDp = 168f; heightDp = 178f }, modifier = Modifier.weight(1f)) { Text("Крупные", fontSize = 10.sp) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Отмена") }
                    Button(onClick = { onSave(widthDp.toInt(), heightDp.toInt()) }, modifier = Modifier.weight(1f)) { Text("Сохранить") }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.72f), RoundedCornerShape(20.dp)), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Text(message, modifier = Modifier.fillMaxWidth().padding(16.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f))
    }
}

private fun sensorLabel(instance: String): String = when (instance) {
    "temperature" -> "Температура"
    "humidity" -> "Влажность"
    "pressure" -> "Давление"
    "battery_level" -> "Заряд батареи"
    "voltage" -> "Напряжение"
    "current" -> "Ток"
    "power" -> "Мощность"
    "illumination" -> "Освещённость"
    "co2_level" -> "Уровень CO₂"
    "pm1_density" -> "PM1"
    "pm2.5_density" -> "PM2.5"
    "pm10_density" -> "PM10"
    "open" -> "Открытие"
    "motion" -> "Движение"
    "vibration" -> "Вибрация"
    "water_leak" -> "Протечка"
    "smoke" -> "Дым"
    "gas" -> "Газ"
    else -> ApiTextRu.translate(instance)
}

private fun sensorValue(instance: String, value: Any?): String {
    val raw = when (value) {
        null -> "Нет данных"
        is Boolean -> if (value) "Да" else "Нет"
        else -> value.toString()
    }
    val unit = when (instance) {
        "temperature" -> " °C"
        "humidity", "battery_level" -> "%"
        "pressure" -> " гПа"
        "illumination" -> " лк"
        "co2_level" -> " ppm"
        "voltage" -> " В"
        "current" -> " А"
        "power" -> " Вт"
        else -> ""
    }
    return when (raw.lowercase()) {
        "open" -> "Открыто"
        "closed" -> "Закрыто"
        "detected" -> "Обнаружено"
        "not_detected" -> "Не обнаружено"
        else -> if (raw.any(Char::isLetter) && numericOrNull(raw) == null) ApiTextRu.translate(raw) else raw + unit
    }
}

private fun numericOrNull(value: String): Double? = value.replace(',', '.').toDoubleOrNull()

private fun sceneLabel(id: String): String = when (id) {
    "alarm" -> "Тревога"
    "alice" -> "Алиса"
    "candle" -> "Свеча"
    "dinner" -> "Ужин"
    "fantasy" -> "Фантазия"
    "garland" -> "Гирлянда"
    "jungle" -> "Джунгли"
    "movie" -> "Кино"
    "neon" -> "Неон"
    "night" -> "Ночь"
    "ocean" -> "Океан"
    "party" -> "Вечеринка"
    "reading" -> "Чтение"
    "rest" -> "Отдых"
    "romance" -> "Романтика"
    "siren" -> "Сирена"
    else -> ApiTextRu.translate(id)
}

private fun modeInstanceLabel(instance: String): String = when (instance) {
    "thermostat" -> "Режим термостата"
    "cleanup_mode" -> "Режим уборки"
    "fan_speed" -> "Скорость вентилятора"
    else -> "Режим: ${ApiTextRu.translate(instance)}"
}

private fun modeLabel(value: String): String = when (value) {
    "auto" -> "Авто"
    "heat" -> "Обогрев"
    "cool" -> "Охлаждение"
    "dry" -> "Осушение"
    "fan_only" -> "Вентиляция"
    "on" -> "Вкл."
    "off" -> "Выкл."
    "high" -> "Высокая"
    "medium" -> "Средняя"
    "low" -> "Низкая"
    "turbo" -> "Турбо"
    "eco" -> "Эко"
    else -> ApiTextRu.translate(value)
}

private fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}



private fun deviceNeedsAttention(device: HomeDevice): Boolean {
    if (!device.isOnline) return true
    return device.properties.any { property ->
        val numeric = (property.value as? Number)?.toDouble()
        when (property.instance.lowercase()) {
            "battery_level" -> numeric != null && numeric < 20.0
            "co2_level" -> numeric != null && numeric > 1000.0
            "water_leak", "smoke", "gas" -> when (val value = property.value) {
                is Boolean -> value
                is Number -> value.toInt() != 0
                is String -> value.lowercase() in setOf("detected", "true", "1", "on", "leak", "smoke")
                else -> false
            }
            else -> false
        }
    }
}

private fun dashboardDeviceCategory(device: HomeDevice): String {
    val key = (device.type + " " + device.name).lowercase()
    return when {
        listOf("light", "lamp", "bulb", "свет", "ламп").any(key::contains) -> "Освещение"
        listOf("socket", "plug", "outlet", "розет").any(key::contains) -> "Розетки"
        listOf("climate", "thermostat", "heater", "кондиц", "термостат", "обогрев").any(key::contains) -> "Климат"
        listOf("camera", "lock", "security", "door", "замок", "камера", "двер").any(key::contains) -> "Безопасность"
        listOf("tv", "media", "speaker", "audio", "телевиз", "колонк", "медиаплеер", "приставк").any(key::contains) -> "Медиа"
        device.properties.isNotEmpty() || listOf("sensor", "датчик", "motion", "temperature", "humidity").any(key::contains) -> "Датчики"
        else -> "Другое"
    }
}

// UI-REFINED-1.5.3

// REFERENCE-DESIGN-1.6.0

// FULL-INTERFACE-PART-A-1.7.0

// FULL-INTERFACE-PART-B-1.7.0

// THEME-NAV-1.8.0

// VISUAL-POLISH-1.8.0

// HOME-WIDGETS-NAV-AUTO-1.8.3

// HOME-WIDGETS-NAV-AUTO-1.8.3

// HOME-WIDGETS-NAV-AUTO-1.8.3
