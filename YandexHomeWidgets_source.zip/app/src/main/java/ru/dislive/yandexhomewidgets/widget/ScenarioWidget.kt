package ru.dislive.yandexhomewidgets.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.Button
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import ru.dislive.yandexhomewidgets.data.HomeSnapshotStore
import ru.dislive.yandexhomewidgets.data.LocalAutomation
import ru.dislive.yandexhomewidgets.data.LocalAutomationEngine
import ru.dislive.yandexhomewidgets.data.LocalAutomationStore
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi

private val AutomationIdKey = ActionParameters.Key<String>("automation_id")

class ScenarioWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val automations = LocalAutomationStore.loadAutomations(context).filter { it.enabled }.take(3)
        provideContent {
            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(ColorProvider(Color(0xFF171026)))
                    .padding(12.dp),
                verticalAlignment = Alignment.Vertical.Top
            ) {
                Text("Быстрые сценарии", style = TextStyle(color = ColorProvider(Color.White), fontSize = 16.sp, fontWeight = FontWeight.Bold))
                Spacer(GlanceModifier.height(6.dp))
                if (automations.isEmpty()) {
                    Text("Добавь автоматизации в приложении — они появятся здесь", style = TextStyle(color = ColorProvider(Color(0xFFD6C9EA)), fontSize = 11.sp))
                } else {
                    automations.forEach { automation ->
                        Row(
                            modifier = GlanceModifier.fillMaxWidth()
                                .background(ColorProvider(Color(0xFF30204A)))
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.Vertical.CenterVertically
                        ) {
                            Text(
                                widgetScenarioMark(automation.iconKey),
                                style = TextStyle(color = ColorProvider(Color(0xFFE5D2FF)), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            )
                            Spacer(GlanceModifier.width(8.dp))
                            Text(
                                automation.name,
                                modifier = GlanceModifier.width(120.dp),
                                maxLines = 1,
                                style = TextStyle(color = ColorProvider(Color.White), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            )
                            Button(
                                text = "▶",
                                onClick = actionRunCallback<RunLocalAutomationAction>(
                                    actionParametersOf(AutomationIdKey to automation.id)
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

class ScenarioWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ScenarioWidget()
}

class RunLocalAutomationAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val id = parameters[AutomationIdKey] ?: return
        val token = TokenStore(context).getValidAccessToken() ?: return
        try {
            val api = YandexHomeApi(token)
            val home = api.getHome()
            LocalAutomationEngine.runManually(context, api, home, id)
            HomeSnapshotStore.save(context, home)
            HomeWidget().updateAll(context)
            ScenarioWidget().updateAll(context)
        } catch (_: Exception) {
            // The next successful refresh will show the current state.
        }
    }
}

private fun widgetScenarioMark(iconKey: String): String = when (iconKey) {
    "sun" -> "☀"
    "moon" -> "☾"
    "movie" -> "▣"
    "shield" -> "⬡"
    "home" -> "⌂"
    "light" -> "✧"
    "vacuum" -> "◉"
    "speaker" -> "♫"
    "temperature" -> "♨"
    "lock" -> "▣"
    else -> "✦"
}
