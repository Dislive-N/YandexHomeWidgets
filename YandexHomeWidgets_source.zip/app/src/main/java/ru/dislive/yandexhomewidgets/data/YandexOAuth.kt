package ru.dislive.yandexhomewidgets.data

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

object YandexOAuth {
    private const val AUTH_URL = "https://oauth.yandex.ru/authorize"
    private const val TOKEN_URL = "https://oauth.yandex.ru/token"
    const val REDIRECT_URI = "https://oauth.yandex.ru/verification_code"
    data class TokenResponse(val accessToken: String, val refreshToken: String?, val expiresIn: Long)

    fun authorizationUrl(clientId: String, store: TokenStore): String {
        val random = SecureRandom()
        val verifierBytes = ByteArray(48).also(random::nextBytes)
        val verifier = android.util.Base64.encodeToString(verifierBytes,
            android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        val state = UUID.randomUUID().toString()
        val challenge = android.util.Base64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)),
            android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        store.savePending(verifier, state)
        return Uri.parse(AUTH_URL).buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", clientId.trim())
            .appendQueryParameter("redirect_uri", REDIRECT_URI)
            .appendQueryParameter("scope", "iot:view iot:control")
            .appendQueryParameter("device_id", store.deviceId())
            .appendQueryParameter("device_name", store.deviceName())
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .build().toString()
    }

    suspend fun exchangeRedirect(url: String, clientId: String, store: TokenStore): TokenResponse = withContext(Dispatchers.IO) {
        val redirect = Uri.parse(url.trim())
        val oauthError = redirect.getQueryParameter("error")
        if (!oauthError.isNullOrBlank()) throw IOException(redirect.getQueryParameter("error_description") ?: oauthError)
        val code = redirect.getQueryParameter("code") ?: throw IllegalArgumentException("Вставь полный адрес страницы возврата из браузера.")
        val state = redirect.getQueryParameter("state")
        val expected = store.pendingState()
        val verifier = store.pendingVerifier()
        if (expected.isNullOrBlank() || verifier.isNullOrBlank()) throw IllegalStateException("Сеанс авторизации не найден. Запусти подключение заново.")
        if (state != expected) throw SecurityException("Проверка state не пройдена. Запусти подключение заново.")
        val response = postForm(mapOf(
            "grant_type" to "authorization_code", "code" to code, "client_id" to clientId.trim(),
            "code_verifier" to verifier, "device_id" to store.deviceId(), "device_name" to store.deviceName()
        ))
        store.clearPending()
        response
    }

    private fun postForm(fields: Map<String, String>): TokenResponse {
        val connection = URL(TOKEN_URL).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.setRequestProperty("Accept", "application/json")
            val body = fields.entries.joinToString("&") { (key, value) -> encode(key) + "=" + encode(value) }
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(text) } catch (_: Exception) { throw IOException("Яндекс OAuth вернул неожиданный ответ ($code).") }
            if (code !in 200..299 || json.has("error")) {
                throw IOException(json.optString("error_description").ifBlank { json.optString("error") }.ifBlank { "Ошибка OAuth ($code)" })
            }
            val access = json.optString("access_token")
            if (access.isBlank()) throw IOException("В ответе Яндекса нет access_token.")
            return TokenResponse(access, json.optString("refresh_token").takeIf { it.isNotBlank() }, json.optLong("expires_in", 3600L))
        } finally { connection.disconnect() }
    }
    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
