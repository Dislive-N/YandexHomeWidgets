package ru.dislive.yandexhomewidgets.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.Geocoder
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

data class CurrentWeather(
    val temperatureC: Double,
    val humidityPercent: Int,
    val precipitationMm: Double,
    val windMetersPerSecond: Double,
    val weatherCode: Int,
    val placeName: String = "Местоположение",
    val fetchedAt: Long = System.currentTimeMillis(),
    val sourceLabel: String = "Open-Meteo",
    val descriptionOverride: String? = null
) {
    val description: String get() = descriptionOverride ?: when (weatherCode) {
        0 -> "Ясно"
        1, 2 -> "Небольшая облачность"
        3 -> "Облачно"
        45, 48 -> "Туман"
        in 51..57 -> "Морось"
        in 61..67 -> "Дождь"
        in 71..77 -> "Снег"
        in 80..82 -> "Ливень"
        in 85..86 -> "Снегопад"
        in 95..99 -> "Гроза"
        else -> "Погода сейчас"
    }
}

/** Location access helpers for foreground weather and user-enabled background geofence checks. */
object LocationWeatherService {
    fun hasLocationPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackgroundLocationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    suspend fun currentLocation(
        context: Context,
        maxCacheAgeMillis: Long = 5 * 60_000L,
        preferFreshFix: Boolean = false
    ): Location? {
        if (!hasLocationPermission(context)) return null
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providerOrder = if (preferFreshFix) {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        } else {
            listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
        }
        val providers = providerOrder.filter { provider -> runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false) }
        if (providers.isEmpty()) return null

        val now = System.currentTimeMillis()
        val cached = providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
            .filter { location -> now - location.time in 0..maxCacheAgeMillis }
            .maxByOrNull { it.time }

        // Foreground weather can use a recent cache instantly. Geofence evaluation asks
        // for a fresh fix first, then may fall back only to a tightly age-bounded cache.
        if (!preferFreshFix && cached != null) return cached

        for (provider in providers) {
            val fresh = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    withTimeoutOrNull(if (preferFreshFix) 8_000L else 12_000L) { requestCurrent(manager, provider, context) }
                } else {
                    withTimeoutOrNull(if (preferFreshFix) 8_000L else 12_000L) { requestSingle(manager, provider) }
                }
            }.getOrNull()
            if (fresh != null && System.currentTimeMillis() - fresh.time in 0..maxCacheAgeMillis) return fresh
        }
        return cached
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestCurrent(manager: LocationManager, provider: String, context: Context): Location? =
        suspendCancellableCoroutine { continuation ->
            val cancellation = CancellationSignal()
            continuation.invokeOnCancellation { cancellation.cancel() }
            manager.getCurrentLocation(provider, cancellation, context.mainExecutor) { location ->
                if (continuation.isActive) continuation.resume(location)
            }
        }

    @Suppress("DEPRECATION", "MissingPermission")
    private suspend fun requestSingle(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (continuation.isActive) {
                        manager.removeUpdates(this)
                        continuation.resume(location)
                    }
                }
                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
            }
            continuation.invokeOnCancellation { manager.removeUpdates(listener) }
            manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        }

    suspend fun resolvePlaceName(context: Context, latitude: Double, longitude: Double): String = withContext(Dispatchers.IO) {
        if (!Geocoder.isPresent()) return@withContext "Местоположение"
        runCatching {
            @Suppress("DEPRECATION")
            Geocoder(context, Locale("ru")).getFromLocation(latitude, longitude, 1)
                ?.firstOrNull()
                ?.let { address ->
                    address.locality
                        ?: address.subLocality
                        ?: address.subAdminArea
                        ?: address.adminArea
                }
                ?.takeIf { it.isNotBlank() }
        }.getOrNull() ?: "Местоположение"
    }

    suspend fun currentWeather(
        latitude: Double,
        longitude: Double,
        placeName: String = "Местоположение",
        source: String = "open_meteo",
        yandexApiKey: String = ""
    ): CurrentWeather? = withContext(Dispatchers.IO) {
        if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return@withContext null
        if (source == "yandex") {
            if (yandexApiKey.isBlank()) return@withContext null
            val query = "lat=${"%.5f".format(Locale.US, latitude)}&lon=${"%.5f".format(Locale.US, longitude)}&lang=ru_RU"
            val parseYandex: (JSONObject) -> CurrentWeather? = fun(root: JSONObject): CurrentWeather? {
                val fact = root.optJSONObject("fact") ?: return null
                val temp = fact.optDouble("temp", Double.NaN)
                if (!temp.isFinite()) return null
                val condition = fact.optString("condition", "")
                val code = when {
                    condition.contains("clear", true) -> 0
                    condition.contains("partly", true) -> 2
                    condition.contains("cloudy", true) || condition == "overcast" -> 3
                    condition.contains("drizzle", true) -> 51
                    condition.contains("rain", true) || condition == "showers" -> 61
                    condition.contains("snow", true) || condition == "wet-snow" -> 71
                    condition.contains("thunder", true) -> 95
                    else -> -1
                }
                return CurrentWeather(
                    temperatureC = temp,
                    humidityPercent = fact.optInt("humidity", 0).coerceIn(0, 100),
                    precipitationMm = root.optJSONObject("forecast")?.optJSONArray("parts")?.optJSONObject(0)?.optDouble("prec_mm", 0.0)?.coerceAtLeast(0.0) ?: 0.0,
                    windMetersPerSecond = fact.optDouble("wind_speed", 0.0).coerceAtLeast(0.0),
                    weatherCode = code,
                    placeName = placeName.ifBlank { "Местоположение" },
                    sourceLabel = "Яндекс Погода",
                    descriptionOverride = yandexConditionLabel(condition)
                )
            }
            // The API endpoint depends on the Yandex tariff: try the test REST endpoint first,
            // then the website/informer endpoint. Both return the same fact block.
            // Respect the selected provider: do not silently switch to Open-Meteo
            // when the user chose Yandex. Try the endpoint supported by their plan,
            // then the alternative Yandex endpoint, and surface an unavailable state
            // if neither endpoint accepts the key.
            return@withContext requestWeather("https://api.weather.yandex.ru/v2/forecast?$query&limit=1&hours=false", placeName, "Яндекс Погода", yandexApiKey, parseYandex)
                ?: requestWeather("https://api.weather.yandex.ru/v2/informers?$query", placeName, "Яндекс Погода", yandexApiKey, parseYandex)
        }
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${"%.5f".format(Locale.US, latitude)}&longitude=${"%.5f".format(Locale.US, longitude)}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&wind_speed_unit=ms&timezone=auto"
        requestWeather(url, placeName, "Open-Meteo", null) { root ->
            val current = root.optJSONObject("current") ?: return@requestWeather null
            val temperature = current.optDouble("temperature_2m", Double.NaN)
            if (!temperature.isFinite()) return@requestWeather null
            CurrentWeather(
                temperatureC = temperature,
                humidityPercent = current.optDouble("relative_humidity_2m", 0.0).toInt().coerceIn(0, 100),
                precipitationMm = current.optDouble("precipitation", 0.0).coerceAtLeast(0.0),
                windMetersPerSecond = current.optDouble("wind_speed_10m", 0.0).coerceAtLeast(0.0),
                weatherCode = current.optInt("weather_code", -1),
                placeName = placeName.ifBlank { "Местоположение" },
                sourceLabel = "Open-Meteo"
            )
        }
    }

    private fun yandexConditionLabel(condition: String): String = when (condition.lowercase()) {
        "clear" -> "Ясно"; "partly-cloudy" -> "Малооблачно"; "cloudy" -> "Облачно с прояснениями"; "overcast" -> "Пасмурно"
        "drizzle" -> "Морось"; "light-rain" -> "Небольшой дождь"; "rain" -> "Дождь"; "moderate-rain" -> "Умеренный дождь"
        "heavy-rain" -> "Сильный дождь"; "continuous-heavy-rain" -> "Продолжительный ливень"; "showers" -> "Ливень"
        "wet-snow" -> "Дождь со снегом"; "light-snow" -> "Небольшой снег"; "snow" -> "Снег"; "snow-showers" -> "Снегопад"
        "hail" -> "Град"; "thunderstorm" -> "Гроза"; "thunderstorm-with-rain" -> "Гроза с дождём"
        "thunderstorm-with-hail" -> "Гроза с градом"; else -> "Погодные условия"
    }

    private fun requestWeather(
        url: String, placeName: String, sourceLabel: String, apiKey: String?, parse: (JSONObject) -> CurrentWeather?
    ): CurrentWeather? {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 8_000
            connection.readTimeout = 8_000
            connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
            if (!apiKey.isNullOrBlank()) connection.setRequestProperty("X-Yandex-Weather-Key", apiKey.trim())
            if (connection.responseCode !in 200..299) return null
            val root = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            return parse(root)
        } catch (_: Exception) {
            return null
        } finally { connection.disconnect() }
    }
}
