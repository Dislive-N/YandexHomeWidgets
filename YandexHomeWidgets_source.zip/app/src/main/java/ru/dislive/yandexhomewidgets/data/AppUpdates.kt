package ru.dislive.yandexhomewidgets.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class AppUpdateInfo(
    val version: String,
    val buildCode: Int,
    val releaseUrl: String,
    val apkUrl: String?,
    val notes: String
)

object AppUpdateChecker {
    private const val RELEASES_URL = "https://api.github.com/repos/Dislive-N/YandexHomeWidgets/releases?per_page=10"

    suspend fun check(installedVersion: String, installedBuildCode: Int): AppUpdateInfo? = withContext(Dispatchers.IO) {
        val connection = URL(RELEASES_URL).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
            connection.setRequestProperty("Cache-Control", "no-cache")
            val code = connection.responseCode
            if (code !in 200..299) {
                val errorBody = runCatching {
                    (connection.errorStream ?: connection.inputStream).bufferedReader(Charsets.UTF_8).use { it.readText() }
                }.getOrDefault("")
                val detail = runCatching { org.json.JSONObject(errorBody).optString("message") }.getOrDefault("")
                val message = when {
                    code == 403 && connection.getHeaderField("X-RateLimit-Remaining") == "0" ->
                        "GitHub временно ограничил проверку обновлений. Попробуй позже."
                    detail.isNotBlank() -> "GitHub: $detail (HTTP $code)"
                    else -> "GitHub вернул HTTP $code"
                }
                throw IllegalStateException(message)
            }
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val releases = JSONArray(body)
            if (releases.length() == 0) return@withContext null

            val installed = installedVersion.trim().removePrefix("v")
            val candidates = (0 until releases.length()).mapNotNull { releases.optJSONObject(it) }
                .filterNot { it.optBoolean("draft", false) }
                .mapNotNull { release ->
                    val tag = release.optString("tag_name")
                    val version = Regex("(?:app-)?v?([0-9]+(?:\\\\.[0-9]+){1,3})(?:-build|$)", RegexOption.IGNORE_CASE)
                        .find(tag)?.groupValues?.getOrNull(1)
                        ?: tag.removePrefix("v").substringBefore("-build").substringAfterLast("v")
                    val releaseBuild = Regex("build[-_](\\\\d+)", RegexOption.IGNORE_CASE)
                        .find(tag)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                    val apkUrl = release.optJSONArray("assets")?.let { assets ->
                        (0 until assets.length()).mapNotNull { assets.optJSONObject(it) }
                            .firstOrNull {
                                it.optString("name").endsWith(".apk", ignoreCase = true) &&
                                    it.optLong("size", 0L) > 1_000_000L
                            }
                            ?.optString("browser_download_url")
                            ?.takeIf { it.startsWith("https://", ignoreCase = true) }
                    }
                    if (apkUrl.isNullOrBlank()) null
                    else {
                        val newer = compareVersions(version, installed) > 0 ||
                            (compareVersions(version, installed) == 0 && releaseBuild > installedBuildCode)
                        if (!newer) null else Triple(release, version, Pair(releaseBuild, apkUrl))
                    }
                }
                .sortedWith(Comparator { left, right ->
                    val versionOrder = compareVersions(right.second, left.second)
                    if (versionOrder != 0) versionOrder else right.third.first.compareTo(left.third.first)
                })

            val selected = candidates.firstOrNull() ?: return@withContext null
            val release = selected.first
            val version = selected.second
            val releaseBuild = selected.third.first
            val apkUrl = selected.third.second
            AppUpdateInfo(
                version = version,
                buildCode = releaseBuild,
                releaseUrl = release.optString("html_url"),
                apkUrl = apkUrl,
                notes = release.optString("body").take(1200)
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun compareVersions(left: String, right: String): Int {
        val a = left.split('.').map { it.toIntOrNull() ?: 0 }
        val b = right.split('.').map { it.toIntOrNull() ?: 0 }
        for (index in 0 until maxOf(a.size, b.size)) {
            val diff = (a.getOrNull(index) ?: 0).compareTo(b.getOrNull(index) ?: 0)
            if (diff != 0) return diff
        }
        return 0
    }

}
