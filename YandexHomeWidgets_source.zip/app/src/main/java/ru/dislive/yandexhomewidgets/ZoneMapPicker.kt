package ru.dislive.yandexhomewidgets

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon
import java.util.Locale
import java.io.File
import android.content.Context
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase

@Composable
fun ZoneMapPickerDialog(
    initialLatitude: Double,
    initialLongitude: Double,
    initialRadiusMeters: Int,
    onDismiss: () -> Unit,
    onSave: (Double, Double, Int) -> Unit
) {
    val startLatitude = initialLatitude.takeIf { it.isFinite() && it in -90.0..90.0 } ?: 60.1699
    val startLongitude = initialLongitude.takeIf { it.isFinite() && it in -180.0..180.0 } ?: 24.9384
    var center by remember { mutableStateOf(GeoPoint(startLatitude, startLongitude)) }
    var radius by remember { mutableStateOf(initialRadiusMeters.coerceIn(50, 5000)) }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var circleOverlay by remember { mutableStateOf<Polygon?>(null) }

    fun refreshCircle() {
        val map = mapView ?: return
        val current = map.mapCenter
        center = GeoPoint(current.latitude, current.longitude)
        circleOverlay?.points = Polygon.pointsAsCircle(center, radius.toDouble())
        map.invalidate()
    }

    LaunchedEffect(radius, mapView) { refreshCircle() }
    DisposableEffect(mapView) {
        mapView?.onResume()
        onDispose {
            mapView?.onPause()
            mapView?.onDetach()
            mapView = null
            circleOverlay = null
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth(0.97f).fillMaxHeight(0.92f),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF44328E), Color(0xFF6F58CF), Color(0xFF257F9B)))).padding(17.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text("Настройка зоны", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    Text("Перемести карту под метку", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                Box(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp).clip(RoundedCornerShape(20.dp))
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context ->
                            val osmdroidConfig = Configuration.getInstance()
                            val cacheRoot = File(context.cacheDir, "osmdroid")
                            val tileCache = File(cacheRoot, "tiles")
                            cacheRoot.mkdirs()
                            tileCache.mkdirs()
                            osmdroidConfig.load(context, context.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
                            osmdroidConfig.osmdroidBasePath = cacheRoot
                            osmdroidConfig.osmdroidTileCache = tileCache
                            osmdroidConfig.userAgentValue = "YandexHomeWidgets/1.4.5 (${context.packageName})"
                            MapView(context).apply {
                                setTileSource(object : OnlineTileSourceBase(
                                    "OpenStreetMap HTTPS", 0, 19, 256, ".png",
                                    arrayOf("https://tile.openstreetmap.org/")
                                ) {
                                    override fun getTileURLString(tileIndex: Long): String =
                                        getBaseUrl() + org.osmdroid.util.MapTileIndex.getZoom(tileIndex) + "/" +
                                            org.osmdroid.util.MapTileIndex.getX(tileIndex) + "/" +
                                            org.osmdroid.util.MapTileIndex.getY(tileIndex) + ".png"
                                })
                                setUseDataConnection(true)
                                setTilesScaledToDpi(true)
                                setMultiTouchControls(true)
                                setFlingEnabled(true)
                                controller.setZoom(16.0)
                                controller.setCenter(GeoPoint(startLatitude, startLongitude))
                                val circle = Polygon(this).apply {
                                    fillColor = AndroidColor.argb(48, 106, 82, 214)
                                    strokeColor = AndroidColor.rgb(106, 82, 214)
                                    strokeWidth = 3.0f
                                    points = Polygon.pointsAsCircle(GeoPoint(startLatitude, startLongitude), radius.toDouble())
                                }
                                overlays.add(circle)
                                circleOverlay = circle
                                addMapListener(object : MapListener {
                                    override fun onScroll(event: ScrollEvent): Boolean {
                                        refreshCircle()
                                        return false
                                    }

                                    override fun onZoom(event: ZoomEvent): Boolean {
                                        refreshCircle()
                                        return false
                                    }
                                })
                                mapView = this
                            }
                        },
                        update = { map ->
                            val circle = circleOverlay
                            if (circle != null) circle.points = Polygon.pointsAsCircle(GeoPoint(map.mapCenter.latitude, map.mapCenter.longitude), radius.toDouble())
                        }
                    )
                    Box(
                        Modifier.align(Alignment.Center).size(34.dp).background(Color.White.copy(alpha = 0.94f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(15.dp).background(Color(0xFFE34D59), CircleShape))
                    }
                    Text(
                        "© OpenStreetMap contributors",
                        Modifier.align(Alignment.BottomStart).padding(8.dp).background(Color.White.copy(alpha = 0.88f), RoundedCornerShape(7.dp)).padding(horizontal = 7.dp, vertical = 4.dp),
                        color = Color(0xFF35313F), fontSize = 9.sp
                    )
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Радиус зоны", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("${radius} м", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Slider(value = radius.toFloat(), onValueChange = { radius = it.toInt().coerceIn(50, 5000) }, valueRange = 50f..5000f)
                    Text(
                        "Центр: ${String.format(Locale.US, "%.5f", center.latitude)}, ${String.format(Locale.US, "%.5f", center.longitude)}",
                        fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f)
                    )
                    Text("Двигай карту пальцем, меняй масштаб двумя пальцами. Красная метка останется в центре зоны.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
                }
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp)) { Text("Отмена") }
                    Button(onClick = {
                        val actualCenter = mapView?.mapCenter
                        val latitude = actualCenter?.latitude ?: center.latitude
                        val longitude = actualCenter?.longitude ?: center.longitude
                        onSave(latitude, longitude, radius)
                    }, modifier = Modifier.weight(1f).height(48.dp)) { Text("Сохранить зону") }
                }
            }
        }
    }
}
