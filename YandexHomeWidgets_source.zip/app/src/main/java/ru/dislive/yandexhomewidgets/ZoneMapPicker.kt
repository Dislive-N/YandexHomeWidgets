package ru.dislive.yandexhomewidgets

import android.content.Context
import android.graphics.Color as AndroidColor
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon

@Composable
fun ZoneMapPickerDialog(
    initialLatitude: Double,
    initialLongitude: Double,
    initialRadiusMeters: Int,
    onDismiss: () -> Unit,
    onSave: (Double, Double, Int) -> Unit
) {
    val startLatitude = initialLatitude.takeIf { it.isFinite() && it in -90.0..90.0 } ?: 60.1699
    val startLongitude = initialLongitude.takeIf { it.isFinite() && it in -180.0..180.0 } ?: 24.9384
    var radius by remember { mutableStateOf(initialRadiusMeters.coerceIn(50, 5000).toFloat()) }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var circle by remember { mutableStateOf<Polygon?>(null) }
    var currentPoint by remember { mutableStateOf(GeoPoint(startLatitude, startLongitude)) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(mapView, lifecycleOwner) {
        val activeMap = mapView
        var resumed = false
        fun resumeMap() {
            if (activeMap != null && !resumed) { activeMap.onResume(); resumed = true }
        }
        fun pauseMap() {
            if (activeMap != null && resumed) { activeMap.onPause(); resumed = false }
        }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> resumeMap()
                Lifecycle.Event.ON_PAUSE -> pauseMap()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) resumeMap()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            pauseMap()
            activeMap?.onDetach()
            if (mapView === activeMap) mapView = null
            circle = null
        }
    }

    LaunchedEffect(radius, mapView) {
        val activeMap = mapView ?: return@LaunchedEffect
        val centre = activeMap.mapCenter
        val point = GeoPoint(centre.latitude, centre.longitude)
        currentPoint = point
        circle?.points = Polygon.pointsAsCircle(point, radius.toDouble())
        activeMap.invalidate()
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth(0.97f).fillMaxHeight(0.93f),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xFF38246F), Color(0xFF6045A9), Color(0xFF176B83))))
                        .padding(17.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text("Выбор зоны", color = Color.White.copy(alpha = 0.78f), fontSize = 11.sp)
                    Text("Передвинь карту под метку", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Карта загружается автоматически — ключ разработчика не нужен.", color = Color.White.copy(alpha = 0.78f), fontSize = 10.sp)
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(19.dp))) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context ->
                            val mapCacheRoot = File(context.filesDir, "map-cache")
                            val tileCacheDirectory = File(mapCacheRoot, "tiles")
                            mapCacheRoot.mkdirs()
                            tileCacheDirectory.mkdirs()
                            Configuration.getInstance().apply {
                                load(context, context.getSharedPreferences("osmdroid_settings", Context.MODE_PRIVATE))
                                osmdroidBasePath = mapCacheRoot
                                osmdroidTileCache = tileCacheDirectory
                                tileDownloadThreads = 4
                                tileDownloadMaxQueueSize = 48
                                tileFileSystemCacheMaxBytes = 128L * 1024L * 1024L
                                tileFileSystemCacheTrimBytes = 96L * 1024L * 1024L
                                userAgentValue = "YandexHomeWidgets/1.4.8 (https://github.com/Dislive-N/YandexHomeWidgets)"
                            }
                            MapView(context).apply {
                                setTileSource(TileSourceFactory.MAPNIK)
                                setMultiTouchControls(true)
                                setBuiltInZoomControls(false)
                                controller.setZoom(15.5)
                                controller.setCenter(GeoPoint(startLatitude, startLongitude))
                                val zoneCircle = Polygon(this).apply {
                                    points = Polygon.pointsAsCircle(GeoPoint(startLatitude, startLongitude), radius.toDouble())
                                    fillPaint.color = AndroidColor.argb(48, 112, 87, 218)
                                    outlinePaint.color = AndroidColor.rgb(125, 104, 235)
                                    outlinePaint.strokeWidth = 4f
                                }
                                overlays.add(zoneCircle)
                                circle = zoneCircle
                                fun syncSelectedCentre() {
                                    val centre = mapCenter
                                    val selected = GeoPoint(centre.latitude, centre.longitude)
                                    currentPoint = selected
                                    zoneCircle.points = Polygon.pointsAsCircle(selected, radius.toDouble())
                                    invalidate()
                                }
                                addMapListener(object : MapListener {
                                    override fun onScroll(event: ScrollEvent?): Boolean { syncSelectedCentre(); return true }
                                    override fun onZoom(event: ZoomEvent?): Boolean { syncSelectedCentre(); return true }
                                })
                                mapView = this
                            }
                        },
                        update = { nativeMap ->
                            val centre = nativeMap.mapCenter
                            val selected = GeoPoint(centre.latitude, centre.longitude)
                            currentPoint = selected
                            circle?.points = Polygon.pointsAsCircle(selected, radius.toDouble())
                            nativeMap.invalidate()
                        }
                    )
                    Box(Modifier.align(Alignment.Center).size(34.dp).background(Color.White.copy(alpha = 0.96f), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(12.dp).background(Color(0xFFE34D59), CircleShape))
                    }
                    Column(Modifier.align(Alignment.BottomStart).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(
                            onClick = { mapView?.controller?.zoomIn() },
                            modifier = Modifier.size(42.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                        ) { Text("+", fontSize = 20.sp) }
                        OutlinedButton(
                            onClick = { mapView?.controller?.zoomOut() },
                            modifier = Modifier.size(42.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                        ) { Text("−", fontSize = 20.sp) }
                    }
                    Text(
                        "© OpenStreetMap contributors",
                        Modifier.align(Alignment.BottomEnd).padding(8.dp)
                            .background(Color.White.copy(alpha = 0.92f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 4.dp),
                        color = Color(0xFF282532), fontSize = 9.sp
                    )
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Радиус зоны", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text("${radius.toInt()} м", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Slider(value = radius, onValueChange = { radius = it }, valueRange = 50f..5000f)
                    Text(
                        "Центр метки: ${"%.5f".format(java.util.Locale.US, currentPoint.latitude)}, ${"%.5f".format(java.util.Locale.US, currentPoint.longitude)}",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f)
                    )
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Отмена") }
                    Button(onClick = { onSave(currentPoint.latitude, currentPoint.longitude, radius.toInt()) }, modifier = Modifier.weight(1f)) { Text("Сохранить зону") }
                }
            }
        }
    }
}
