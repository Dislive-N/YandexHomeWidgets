package ru.dislive.yandexhomewidgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.yandex.mapkit.MapKitFactory
import com.yandex.mapkit.geometry.Circle
import com.yandex.mapkit.geometry.Point
import com.yandex.mapkit.map.CameraListener
import com.yandex.mapkit.map.CameraPosition
import com.yandex.mapkit.map.CircleMapObject
import com.yandex.mapkit.map.Map
import com.yandex.mapkit.mapview.MapView as YandexMapView
import java.lang.ref.WeakReference
import java.util.Locale

@Composable
fun ZoneMapPickerDialog(
    initialLatitude: Double,
    initialLongitude: Double,
    initialRadiusMeters: Int,
    mapKitApiKey: String,
    onDismiss: () -> Unit,
    onSave: (Double, Double, Int) -> Unit
) {
    val startLatitude = initialLatitude.takeIf { it.isFinite() && it in -90.0..90.0 } ?: 60.1699
    val startLongitude = initialLongitude.takeIf { it.isFinite() && it in -180.0..180.0 } ?: 24.9384
    var radius by remember { mutableStateOf(initialRadiusMeters.coerceIn(50, 5000)) }
    var mapView by remember { mutableStateOf<YandexMapView?>(null) }
    var circle by remember { mutableStateOf<CircleMapObject?>(null) }
    var currentPoint by remember { mutableStateOf(Point(startLatitude, startLongitude)) }
    var cameraListener by remember { mutableStateOf<CameraListener?>(null) }

    LaunchedEffect(radius) {
        val point = mapView?.mapWindow?.map?.cameraPosition?.target ?: currentPoint
        currentPoint = point
        circle?.geometry = Circle(point, radius.toFloat())
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(mapView, lifecycleOwner) {
        val activeMapView = mapView
        var mapStarted = false

        fun startMap() {
            if (activeMapView != null && !mapStarted) {
                MapKitFactory.getInstance().onStart()
                activeMapView.onStart()
                mapStarted = true
            }
        }

        fun stopMap() {
            if (activeMapView != null && mapStarted) {
                activeMapView.onStop()
                MapKitFactory.getInstance().onStop()
                mapStarted = false
            }
        }

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> startMap()
                Lifecycle.Event.ON_STOP -> stopMap()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        // A Compose dialog can be created after the Activity has already received ON_START.
        // In that case LifecycleEventObserver will not replay the old event, so start MapKit
        // immediately when the newly-created MapView joins an already-started Activity.
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            startMap()
        }

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            stopMap()
            activeMapView?.destroy()
            if (mapView === activeMapView) mapView = null
            circle = null
            cameraListener = null
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth(0.97f).fillMaxHeight(0.92f),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF44328E), Color(0xFF6F58CF), Color(0xFF257F9B)))).padding(17.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text("Настройка зоны", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    Text("Перемести карту под метку", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                if (mapKitApiKey.isBlank()) {
                    Column(Modifier.weight(1f).fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Для Яндекс Карт нужен API-ключ MapKit", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Добавь ключ в Настройки → Яндекс Карты, затем перезапусти приложение. Без ключа карта не загрузится.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f))
                    }
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp).clip(RoundedCornerShape(20.dp))) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { context ->
                                YandexMapView(context).apply {
                                    mapWindow.map.move(CameraPosition(Point(startLatitude, startLongitude), 16f, 0f, 0f))
                                    circle = mapWindow.map.mapObjects.addCircle(Circle(Point(startLatitude, startLongitude), radius.toFloat())).apply {
                                        strokeWidth = 2.5f
                                        strokeColor = 0xFF6A52D6.toInt()
                                        fillColor = 0x306A52D6
                                        isGeodesic = true
                                    }
                                    val listener = CameraListener { map: Map, position: CameraPosition, _, _ ->
                                        currentPoint = position.target
                                        circle?.geometry = Circle(position.target, radius.toFloat())
                                    }
                                    cameraListener = listener
                                    mapWindow.map.addCameraListener(WeakReference(listener))
                                    mapView = this
                                }
                            },
                            update = { nativeMap ->
                                val point = nativeMap.mapWindow.map.cameraPosition.target
                                circle?.geometry = Circle(point, radius.toFloat())
                            }
                        )
                        Box(Modifier.align(Alignment.Center).size(34.dp).background(Color.White.copy(alpha = 0.96f), CircleShape), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(15.dp).background(Color(0xFFE34D59), CircleShape))
                        }
                        Text("Яндекс Карты", Modifier.align(Alignment.BottomStart).padding(8.dp).background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(7.dp)).padding(horizontal = 7.dp, vertical = 4.dp), color = Color(0xFF35313F), fontSize = 9.sp)
                    }
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Радиус зоны", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("${radius} м", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Slider(value = radius.toFloat(), onValueChange = { radius = it.toInt().coerceIn(50, 5000) }, valueRange = 50f..5000f, enabled = mapKitApiKey.isNotBlank())
                    Text("Центр: ${String.format(Locale.US, "%.5f", currentPoint.latitude)}, ${String.format(Locale.US, "%.5f", currentPoint.longitude)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
                    Text("Двигай карту пальцем, меняй масштаб двумя пальцами. Красная метка останется в центре зоны.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
                }
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp)) { Text("Отмена") }
                    Button(onClick = { onSave(currentPoint.latitude, currentPoint.longitude, radius) }, enabled = mapKitApiKey.isNotBlank(), modifier = Modifier.weight(1f).height(48.dp)) { Text("Сохранить зону") }
                }
            }
        }
    }
}
