package ru.dislive.yandexhomewidgets.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** App-local device groups. These do not modify groups in the Yandex Home service. */
data class DeviceGroup(
    val id: String,
    val name: String,
    val deviceIds: List<String>
)

object DeviceGroupStore {
    private const val PREFS = "device_groups"
    private const val KEY_GROUPS = "groups_json"

    fun load(context: Context): List<DeviceGroup> {
        val raw = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_GROUPS, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    val name = item.optString("name")
                    if (id.isBlank() || name.isBlank()) continue
                    val members = item.optJSONArray("devices") ?: JSONArray()
                    val deviceIds = (0 until members.length())
                        .mapNotNull { members.optString(it).takeIf(String::isNotBlank) }
                    add(DeviceGroup(id, name, deviceIds))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, groups: List<DeviceGroup>) {
        val array = JSONArray()
        groups.forEach { group ->
            array.put(
                JSONObject()
                    .put("id", group.id)
                    .put("name", group.name)
                    .put("devices", JSONArray(group.deviceIds.distinct()))
            )
        }
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_GROUPS, array.toString()).apply()
    }
}
