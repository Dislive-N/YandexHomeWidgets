package ru.dislive.yandexhomewidgets.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.Button
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi

private val DeviceIdKey = ActionParameters.Key<String>("device_id")
private val DesiredOnKey = ActionParameters.Key<Boolean>("desired_on")

class HomeWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val devices = HomeCache.favoriteDevices(context).take(4)
        provideContent {
            Column(
                modifier = GlanceModifier.fillMaxSize().background(ColorProvider(Color(0xFF171F31))).padding(12.dp),
                horizontalAlignment = Alignment.Horizontal.Start
            ) {
                Text("Яндекс Дом", style = TextStyle(color = ColorProvider(Color.White), fontSize = 16.sp, fontWeight = FontWeight.Bold))
                Spacer(GlanceModifier.height(6.dp))
                if (devices.isEmpty()) {
                    Text("Добавь устройства в избранное в приложении", style = TextStyle(color = ColorProvider(Color(0xFFB9C4D8)), fontSize = 12.sp))
                } else {
                    devices.forEach { device ->
                        Row(modifier = GlanceModifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Vertical.CenterVertically) {
                            Column(modifier = GlanceModifier.defaultWeight()) {
                                Text(device.name, maxLines = 1, style = TextStyle(color = ColorProvider(Color.White), fontSize = 13.sp, fontWeight = FontWeight.Medium))
                                if (device.room.isNotBlank()) Text(device.room, maxLines = 1, style = TextStyle(color = ColorProvider(Color(0xFF9BAAC4)), fontSize = 10.sp))
                            }
                            if (device.canToggle && device.onOff != null) {
                                Button(
                                    text = if (device.onOff) "Выкл." else "Вкл.",
                                    onClick = actionRunCallback<ToggleDeviceAction>(
                                        actionParametersOf(DeviceIdKey to device.id, DesiredOnKey to !device.onOff)
                                    )
                                )
                            } else {
                                Text("В приложении", style = TextStyle(color = ColorProvider(Color(0xFF9DB9FF)), fontSize = 10.sp))
                            }
                        }
                    }
                }
            }
        }
    }
}

class HomeWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = HomeWidget()
}

class ToggleDeviceAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val deviceId = parameters[DeviceIdKey] ?: return
        val desiredOn = parameters[DesiredOnKey] ?: return
        val clientId = context.getSharedPreferences("app_config", Context.MODE_PRIVATE).getString("client_id", "").orEmpty()
        if (clientId.isBlank()) return
        val token = TokenStore(context).getValidAccessToken() ?: return
        try {
            val api = YandexHomeApi(token)
            api.setOnOff(deviceId, desiredOn)
            HomeCache.saveHome(context, api.getHome())
            HomeWidget().updateAll(context)
        } catch (_: Exception) {
            // The next app refresh or scheduled sync will refresh the state.
        }
    }
}
