package ru.dislive.yandexhomewidgets.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class WidgetDevice(val id: String, val name: String, val room: String, val onOff: Boolean?, val canToggle: Boolean)

object HomeCache {
    private const val PREFS = "home_cache"
    private const val KEY_DEVICES = "devices_json"
    private const val KEY_FAVORITES = "favorite_ids"

    fun saveHome(context: Context, home: HomeData) {
        val array = JSONArray()
        home.devices.forEach { device ->
            val item = JSONObject().put("id", device.id).put("name", device.name)
                .put("room", device.room).put("can_toggle", device.canToggle)
            if (device.onOff == null) item.put("is_on", JSONObject.NULL) else item.put("is_on", device.onOff)
            array.put(item)
        }
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_DEVICES, array.toString()).apply()
    }

    fun setFavorite(context: Context, deviceId: String, favorite: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ids = prefs.getStringSet(KEY_FAVORITES, emptySet())?.toMutableSet() ?: mutableSetOf()
        if (favorite) ids.add(deviceId) else ids.remove(deviceId)
        prefs.edit().putStringSet(KEY_FAVORITES, ids).apply()
    }

    fun isFavorite(context: Context, deviceId: String): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_FAVORITES, emptySet())?.contains(deviceId) == true

    fun favoriteDevices(context: Context): List<WidgetDevice> {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ids = prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
        val array = try { JSONArray(prefs.getString(KEY_DEVICES, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val result = mutableListOf<WidgetDevice>()
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id !in ids) continue
            val onOff = if (obj.isNull("is_on")) null else obj.optBoolean("is_on")
            result += WidgetDevice(id, obj.optString("name", "Устройство"), obj.optString("room"), onOff, obj.optBoolean("can_toggle"))
        }
        return result
    }

    fun clear(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
