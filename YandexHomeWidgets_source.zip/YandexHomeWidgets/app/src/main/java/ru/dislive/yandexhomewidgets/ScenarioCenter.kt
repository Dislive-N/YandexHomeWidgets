package ru.dislive.yandexhomewidgets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.dislive.yandexhomewidgets.data.AutomationAction
import ru.dislive.yandexhomewidgets.data.AutomationActionType
import ru.dislive.yandexhomewidgets.data.AutomationCondition
import ru.dislive.yandexhomewidgets.data.AutomationConditionType
import ru.dislive.yandexhomewidgets.data.GlobalVariable
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.LocalAutomation
import ru.dislive.yandexhomewidgets.data.SmartAdvisor
import ru.dislive.yandexhomewidgets.data.SmartSuggestion
import java.util.UUID

@Composable
fun ScenarioCenterScreen(
    devices: List<HomeDevice>,
    cloudScenarios: List<HomeScenario>,
    automations: List<LocalAutomation>,
    variables: List<GlobalVariable>,
    isBusy: Boolean,
    onSaveAutomation: (LocalAutomation) -> Unit,
    onDeleteAutomation: (String) -> Unit,
    onToggleAutomation: (String, Boolean) -> Unit,
    onRunAutomation: (String) -> Unit,
    onSaveVariable: (GlobalVariable) -> Unit,
    onDeleteVariable: (String) -> Unit,
    onRunCloudScenario: (HomeScenario) -> Unit
) {
    val context = LocalContext.current
    val suggestions = remember(devices) { SmartAdvisor.suggestions(context, devices) }
    var editorOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<LocalAutomation?>(null) }
    var variablesOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Сценарии и автоматизации", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Создавай собственные правила: устройство, датчик, время или глобальная переменная запускают нужные действия. Эти правила хранятся на телефоне.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f)
                )
                Text("Проверка: при открытом приложении примерно раз в минуту. В фоне Android может запускать проверку реже.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.56f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { editing = null; editorOpen = true }, modifier = Modifier.weight(1f)) { Text("＋ Создать") }
                    OutlinedButton(onClick = { variablesOpen = true }, modifier = Modifier.weight(1f)) { Text("{} Переменные") }
                }
            }
        }

        if (suggestions.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Умный помощник", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Локальный алгоритм сравнивает новые измерения с обычным уровнем датчика и ищет необычные отклонения.", fontSize = 11.sp)
                    suggestions.forEach { suggestion -> SuggestionRow(suggestion) }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))) {
                Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Умный помощник", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("Алгоритм накопит историю измерений и покажет подсказки, когда заметит необычные изменения. Для анализа нужно несколько сохранённых измерений.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Мои автоматизации", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(automations.size.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        }
        if (automations.isEmpty()) {
            EmptyScenarioCard("Пока нет автоматизаций. Создай правило и добавь хотя бы одно условие и действие.")
        }
        automations.forEach { automation ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        IconTile(automation.iconKey, Modifier.size(48.dp), iconSize = 28.dp, active = automation.enabled)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(automation.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("${automation.conditions.size} усл. · ${automation.actions.size} действ. · ${if (automation.matchAllConditions) "все условия" else "любое условие"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        }
                        Switch(checked = automation.enabled, onCheckedChange = { onToggleAutomation(automation.id, it) })
                    }
                    Text(automation.conditions.joinToString(if (automation.matchAllConditions) " И " else " ИЛИ ") { conditionDescription(it, devices) }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f), maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Text("Тогда: " + automation.actions.joinToString("; ") { actionDescription(it, devices, variables, cloudScenarios) }, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Button(onClick = { onRunAutomation(automation.id) }, enabled = !isBusy, modifier = Modifier.weight(1f)) { Text("▶ Запустить", fontSize = 11.sp) }
                        OutlinedButton(onClick = { editing = automation; editorOpen = true }, modifier = Modifier.weight(1f)) { Text("Изменить", fontSize = 11.sp) }
                        TextButton(onClick = { onDeleteAutomation(automation.id) }) { Text("Удалить", fontSize = 11.sp) }
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Сценарии Яндекса", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(cloudScenarios.size.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        }
        Text("Это сценарии, уже созданные в приложении «Дом с Алисой». Их можно запускать отсюда.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
        if (cloudScenarios.isEmpty()) EmptyScenarioCard("Сценарии Яндекса не найдены.")
        cloudScenarios.forEach { scenario ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconTile(scenarioIconKind(scenario.name), Modifier.size(46.dp), iconSize = 27.dp, active = scenario.isActive)
                    Column(Modifier.weight(1f)) {
                        Text(scenario.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Сценарий Яндекса", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
                    }
                    Button(onClick = { onRunCloudScenario(scenario) }, enabled = !isBusy) { Text("▶") }
                }
            }
        }
    }

    if (editorOpen) {
        LocalAutomationEditor(
            initial = editing,
            devices = devices,
            cloudScenarios = cloudScenarios,
            variables = variables,
            onDismiss = { editorOpen = false; editing = null },
            onSave = { onSaveAutomation(it); editorOpen = false; editing = null }
        )
    }
    if (variablesOpen) {
        GlobalVariablesDialog(
            variables = variables,
            onDismiss = { variablesOpen = false },
            onSave = onSaveVariable,
            onDelete = onDeleteVariable
        )
    }
}

@Composable
private fun SuggestionRow(suggestion: SmartSuggestion) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SmartGlyph("sparkles", Modifier.size(17.dp), MaterialTheme.colorScheme.primary)
            Text(suggestion.title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
        Text(suggestion.detail, fontSize = 11.sp)
    }
}

@Composable
private fun EmptyScenarioCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
        Text(message, Modifier.fillMaxWidth().padding(14.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.64f))
    }
}

@Composable
private fun LocalAutomationEditor(
    initial: LocalAutomation?,
    devices: List<HomeDevice>,
    cloudScenarios: List<HomeScenario>,
    variables: List<GlobalVariable>,
    onDismiss: () -> Unit,
    onSave: (LocalAutomation) -> Unit
) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name.orEmpty()) }
    var matchAll by remember(initial?.id) { mutableStateOf(initial?.matchAllConditions ?: true) }
    var conditions by remember(initial?.id) { mutableStateOf(initial?.conditions.orEmpty()) }
    var actions by remember(initial?.id) { mutableStateOf(initial?.actions.orEmpty()) }
    var cooldown by remember(initial?.id) { mutableStateOf((initial?.cooldownMinutes ?: 2).toString()) }
    var iconKey by remember(initial?.id) { mutableStateOf(initial?.iconKey ?: scenarioIconKind(initial?.name.orEmpty())) }

    var conditionDialog by remember { mutableStateOf(false) }
    var actionDialog by remember { mutableStateOf(false) }
    var conditionType by remember { mutableStateOf(AutomationConditionType.DEVICE_POWER) }
    var conditionDevice by remember { mutableStateOf(devices.firstOrNull()?.id.orEmpty()) }
    var conditionProperty by remember { mutableStateOf(devices.firstOrNull()?.properties?.firstOrNull()?.instance ?: "temperature") }
    var conditionOperator by remember { mutableStateOf(">") }
    var conditionValue by remember { mutableStateOf("true") }
    var conditionVariable by remember { mutableStateOf(variables.firstOrNull()?.name.orEmpty()) }
    var timeStart by remember { mutableStateOf("22:00") }
    var timeEnd by remember { mutableStateOf("07:00") }

    var actionType by remember { mutableStateOf(AutomationActionType.DEVICE_POWER) }
    var actionDevice by remember { mutableStateOf(devices.firstOrNull()?.id.orEmpty()) }
    var actionEnabled by remember { mutableStateOf(true) }
    var actionBrightness by remember { mutableStateOf("50") }
    var actionVariable by remember { mutableStateOf(variables.firstOrNull()?.name.orEmpty()) }
    var actionVariableValue by remember { mutableStateOf("true") }
    var actionScenario by remember { mutableStateOf(cloudScenarios.firstOrNull()?.id.orEmpty()) }

    val deviceOptions = devices.map { it.id to "${it.name} · ${it.room}" }
    val powerDeviceOptions = devices.filter { it.canToggle }.map { it.id to "${it.name} · ${it.room}" }
    val dimmableDeviceOptions = devices.filter { it.canDim }.map { it.id to "${it.name} · ${it.room}" }
    val sensorDeviceOptions = devices.filter { device -> device.properties.any { it.value is Number } }
        .map { it.id to "${it.name} · ${it.room}" }
    val propertyOptions = devices.firstOrNull { it.id == conditionDevice }?.properties
        ?.filter { it.value is Number && it.instance.isNotBlank() }
        ?.map { it.instance }.orEmpty().distinct().map { it to propertyLabel(it) }
    val variableOptions = variables.map { it.name to it.name }

    val latestActions = rememberUpdatedState(actions)
    val reorderThreshold = with(LocalDensity.current) { 46.dp.toPx() }

    fun appendCondition() {
        val valid = when (conditionType) {
            AutomationConditionType.DEVICE_POWER -> conditionDevice.isNotBlank()
            AutomationConditionType.SENSOR_VALUE -> conditionDevice.isNotBlank() && conditionValue.toDoubleOrNull() != null
            AutomationConditionType.GLOBAL_VARIABLE -> conditionVariable.isNotBlank() && conditionValue.isNotBlank()
            AutomationConditionType.TIME_WINDOW -> timeStart.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d")) && timeEnd.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))
            else -> false
        }
        if (!valid) return
        val condition = when (conditionType) {
            AutomationConditionType.DEVICE_POWER -> AutomationCondition(type = conditionType, deviceId = conditionDevice, value = conditionValue)
            AutomationConditionType.SENSOR_VALUE -> AutomationCondition(type = conditionType, deviceId = conditionDevice, property = conditionProperty, operator = conditionOperator, value = conditionValue)
            AutomationConditionType.GLOBAL_VARIABLE -> AutomationCondition(type = conditionType, variableName = conditionVariable.trim(), operator = conditionOperator, value = conditionValue)
            AutomationConditionType.TIME_WINDOW -> AutomationCondition(type = conditionType, startTime = timeStart, endTime = timeEnd)
            else -> return
        }
        conditions = conditions + condition
        conditionDialog = false
    }

    fun appendAction() {
        val valid = when (actionType) {
            AutomationActionType.DEVICE_POWER -> actionDevice.isNotBlank()
            AutomationActionType.BRIGHTNESS -> actionDevice.isNotBlank() && actionBrightness.toIntOrNull() != null
            AutomationActionType.SET_VARIABLE -> actionVariable.isNotBlank()
            AutomationActionType.RUN_YANDEX_SCENARIO -> actionScenario.isNotBlank()
            else -> false
        }
        if (!valid) return
        val action = when (actionType) {
            AutomationActionType.DEVICE_POWER -> AutomationAction(type = actionType, deviceId = actionDevice, enabled = actionEnabled)
            AutomationActionType.BRIGHTNESS -> AutomationAction(type = actionType, deviceId = actionDevice, brightness = actionBrightness.toIntOrNull()?.coerceIn(0, 100) ?: 50)
            AutomationActionType.SET_VARIABLE -> AutomationAction(type = actionType, variableName = actionVariable.trim(), variableValue = actionVariableValue)
            AutomationActionType.RUN_YANDEX_SCENARIO -> AutomationAction(type = actionType, scenarioId = actionScenario)
            else -> return
        }
        actions = actions + action
        actionDialog = false
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth(0.96f).fillMaxSize(0.90f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF4E2A9D), Color(0xFF8A50D6), Color(0xFF3E6DC7)))).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(if (initial == null) "Новый сценарий" else "Настройка сценария", color = Color.White.copy(alpha = 0.82f), fontSize = 11.sp)
                    Text("Собери свою автоматизацию", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it.take(48) }, label = { Text("Название сценария") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Значок сценария", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("sun", "moon", "movie", "shield", "home", "light", "vacuum", "speaker", "temperature", "lock", "sparkles").forEach { kind ->
                            FilterChip(selected = iconKey == kind, onClick = { iconKey = kind }, label = {
                                SmartGlyph(kind, Modifier.size(18.dp), if (iconKey == kind) Color(0xFF8B5CF6) else MaterialTheme.colorScheme.primary)
                            })
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("ЕСЛИ", Modifier.weight(1f), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FilterChip(selected = matchAll, onClick = { matchAll = true }, label = { Text("Все") })
                                    FilterChip(selected = !matchAll, onClick = { matchAll = false }, label = { Text("Любое") })
                                }
                            }
                            if (conditions.isEmpty()) Text("Условия ещё не добавлены", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                            conditions.forEach { condition ->
                                RemovableLine(conditionDescription(condition, devices), onRemove = { conditions = conditions.filterNot { it.id == condition.id } })
                            }
                            Button(onClick = { conditionDialog = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                Text("＋ Добавить условие")
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("ТОГДА", color = Color(0xFF29A88F), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            if (actions.isEmpty()) Text("Действия ещё не добавлены", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                            actions.forEach { action ->
                                var dragDistance by remember(action.id) { mutableFloatStateOf(0f) }
                                Card(
                                    modifier = Modifier.fillMaxWidth().pointerInput(action.id) {
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = { dragDistance = 0f },
                                            onDragEnd = { dragDistance = 0f }
                                        ) { change, amount ->
                                            change.consume()
                                            dragDistance += amount.y
                                            if (kotlin.math.abs(dragDistance) >= reorderThreshold) {
                                                val current = latestActions.value
                                                val from = current.indexOfFirst { it.id == action.id }
                                                val to = (from + if (dragDistance > 0f) 1 else -1).coerceIn(0, current.lastIndex)
                                                if (from >= 0 && to != from) {
                                                    actions = current.toMutableList().apply { add(to, removeAt(from)) }
                                                }
                                                dragDistance = 0f
                                            }
                                        }
                                    },
                                    shape = RoundedCornerShape(15.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 4.dp, top = 9.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("⠿", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp)
                                        Text(actionDescription(action, devices, variables, cloudScenarios), Modifier.weight(1f), fontSize = 11.sp)
                                        TextButton(onClick = { actions = actions.filterNot { it.id == action.id } }) { Text("Убрать", fontSize = 10.sp) }
                                    }
                                }
                            }
                            Text("Зажми действие и перетащи вверх или вниз, чтобы изменить порядок.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f))
                            Button(onClick = { actionDialog = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                Text("＋ Добавить действие")
                            }
                        }
                    }
                    OutlinedTextField(value = cooldown, onValueChange = { cooldown = it.filter(Char::isDigit).take(4) }, label = { Text("Пауза между запусками, минут") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Отмена") }
                    Button(
                        enabled = name.isNotBlank() && conditions.isNotEmpty() && actions.isNotEmpty(),
                        onClick = {
                            onSave(LocalAutomation(
                                id = initial?.id ?: UUID.randomUUID().toString(),
                                name = name.trim(),
                                enabled = initial?.enabled ?: true,
                                matchAllConditions = matchAll,
                                conditions = conditions,
                                actions = actions,
                                cooldownMinutes = cooldown.toIntOrNull()?.coerceIn(0, 1440) ?: 2,
                                iconKey = iconKey
                            ))
                        }, modifier = Modifier.weight(1.2f), shape = RoundedCornerShape(14.dp)
                    ) { Text("Сохранить сценарий") }
                }
            }
        }
    }

    if (conditionDialog) {
        Dialog(onDismissRequest = { conditionDialog = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(Modifier.fillMaxWidth(0.94f).fillMaxSize(0.82f), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF5B52C9), Color(0xFF368FAE)))).padding(17.dp)) {
                        Text("Новое условие", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("Укажи, когда сценарий должен запускаться", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        ChoiceDropdown("Тип условия", conditionType, listOf(
                            AutomationConditionType.DEVICE_POWER to "Состояние устройства",
                            AutomationConditionType.SENSOR_VALUE to "Показание датчика",
                            AutomationConditionType.GLOBAL_VARIABLE to "Глобальная переменная",
                            AutomationConditionType.TIME_WINDOW to "Временной интервал"
                        )) { conditionType = it }
                        when (conditionType) {
                            AutomationConditionType.DEVICE_POWER -> {
                                ChoiceDropdown("Устройство", conditionDevice, powerDeviceOptions) { conditionDevice = it }
                                ChoiceDropdown("Состояние", conditionValue, listOf("true" to "Включено", "false" to "Выключено")) { conditionValue = it }
                            }
                            AutomationConditionType.SENSOR_VALUE -> {
                                ChoiceDropdown("Устройство с датчиком", conditionDevice, sensorDeviceOptions) { conditionDevice = it }
                                ChoiceDropdown("Показатель", conditionProperty, propertyOptions) { conditionProperty = it }
                                ChoiceDropdown("Сравнение", conditionOperator, operators) { conditionOperator = it }
                                OutlinedTextField(value = conditionValue, onValueChange = { conditionValue = it.take(16) }, label = { Text("Пороговое значение") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationConditionType.GLOBAL_VARIABLE -> {
                                if (variableOptions.isNotEmpty()) ChoiceDropdown("Переменная", conditionVariable, variableOptions) { conditionVariable = it }
                                else Text("Сначала создай глобальную переменную.", fontSize = 11.sp)
                                OutlinedTextField(value = conditionVariable, onValueChange = { conditionVariable = it.take(40) }, label = { Text("Имя переменной") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                ChoiceDropdown("Сравнение", conditionOperator, operators) { conditionOperator = it }
                                OutlinedTextField(value = conditionValue, onValueChange = { conditionValue = it.take(48) }, label = { Text("С чем сравнивать") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationConditionType.TIME_WINDOW -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = timeStart, onValueChange = { timeStart = it.take(5) }, label = { Text("С (ЧЧ:ММ)") }, singleLine = true, modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = timeEnd, onValueChange = { timeEnd = it.take(5) }, label = { Text("До (ЧЧ:ММ)") }, singleLine = true, modifier = Modifier.weight(1f))
                                }
                                Text("Интервал может проходить через полночь, например 22:00–07:00.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { conditionDialog = false }, modifier = Modifier.weight(1f)) { Text("Отмена") }
                        Button(onClick = ::appendCondition, modifier = Modifier.weight(1f)) { Text("Добавить") }
                    }
                }
            }
        }
    }

    if (actionDialog) {
        Dialog(onDismissRequest = { actionDialog = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(Modifier.fillMaxWidth(0.94f).fillMaxSize(0.82f), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF168F98), Color(0xFF4A72D5)))).padding(17.dp)) {
                        Text("Новое действие", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("Что должно произойти после выполнения условия", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        ChoiceDropdown("Тип действия", actionType, listOf(
                            AutomationActionType.DEVICE_POWER to "Включить / выключить устройство",
                            AutomationActionType.BRIGHTNESS to "Установить яркость",
                            AutomationActionType.SET_VARIABLE to "Изменить глобальную переменную",
                            AutomationActionType.RUN_YANDEX_SCENARIO to "Запустить сценарий Яндекса"
                        )) { actionType = it }
                        when (actionType) {
                            AutomationActionType.DEVICE_POWER -> {
                                ChoiceDropdown("Устройство", actionDevice, powerDeviceOptions) { actionDevice = it }
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    FilterChip(selected = actionEnabled, onClick = { actionEnabled = true }, label = { Text("Включить") })
                                    FilterChip(selected = !actionEnabled, onClick = { actionEnabled = false }, label = { Text("Выключить") })
                                }
                            }
                            AutomationActionType.BRIGHTNESS -> {
                                ChoiceDropdown("Лампа", actionDevice, dimmableDeviceOptions.ifEmpty { deviceOptions }) { actionDevice = it }
                                OutlinedTextField(value = actionBrightness, onValueChange = { actionBrightness = it.filter(Char::isDigit).take(3) }, label = { Text("Яркость 0–100%") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationActionType.SET_VARIABLE -> {
                                if (variableOptions.isNotEmpty()) ChoiceDropdown("Переменная", actionVariable, variableOptions) { actionVariable = it }
                                OutlinedTextField(value = actionVariable, onValueChange = { actionVariable = it.take(40) }, label = { Text("Имя переменной") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = actionVariableValue, onValueChange = { actionVariableValue = it.take(48) }, label = { Text("Новое значение") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                            AutomationActionType.RUN_YANDEX_SCENARIO -> ChoiceDropdown("Сценарий Яндекса", actionScenario, cloudScenarios.map { it.id to it.name }) { actionScenario = it }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { actionDialog = false }, modifier = Modifier.weight(1f)) { Text("Отмена") }
                        Button(onClick = ::appendAction, modifier = Modifier.weight(1f)) { Text("Добавить") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlobalVariablesDialog(
    variables: List<GlobalVariable>,
    onDismiss: () -> Unit,
    onSave: (GlobalVariable) -> Unit,
    onDelete: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var editingName by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Глобальные переменные") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Переменные общие для всех локальных автоматизаций и сохраняются на телефоне.", fontSize = 11.sp)
                if (variables.isEmpty()) Text("Пока нет переменных.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                variables.forEach { variable ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(variable.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(variable.value, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        }
                        TextButton(onClick = { editingName = variable.name; name = variable.name; value = variable.value }) { Text("Изменить") }
                        TextButton(onClick = { onDelete(variable.name); if (editingName == variable.name) { editingName = null; name = ""; value = "" } }) { Text("×") }
                    }
                }
                Spacer(Modifier.size(1.dp))
                Text(if (editingName == null) "Новая переменная" else "Изменить переменную", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text("Имя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = value, onValueChange = { value = it.take(80) }, label = { Text("Значение: число, текст или true/false") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                val newName = name.trim()
                onSave(GlobalVariable(newName, value))
                if (editingName != null && !editingName.equals(newName, ignoreCase = true)) onDelete(editingName!!)
                name = ""; value = ""; editingName = null
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Готово") } }
    )
}

@Composable
private fun ChoiceDropdown(
    label: String,
    selected: String,
    options: List<Pair<String, String>>,
    onSelect: (String) -> Unit
) {
    var expanded by remember(label) { mutableStateOf(false) }
    val selectedLabel = options.firstOrNull { it.first == selected }?.second ?: selected.ifBlank { "Не выбрано" }
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.64f))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = options.isNotEmpty()) {
                Text(selectedLabel, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                Text("⌄")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(text = { Text(option.second) }, onClick = { onSelect(option.first); expanded = false })
                }
            }
        }
    }
}

@Composable
private fun RemovableLine(text: String, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("• $text", Modifier.weight(1f), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.76f))
        TextButton(onClick = onRemove) { Text("Убрать", fontSize = 10.sp) }
    }
}

private val operators = listOf(">" to "Больше >", ">=" to "Не меньше ≥", "<" to "Меньше <", "<=" to "Не больше ≤", "==" to "Равно =", "!=" to "Не равно ≠")

private fun conditionDescription(condition: AutomationCondition, devices: List<HomeDevice>): String {
    val deviceName = devices.firstOrNull { it.id == condition.deviceId }?.name ?: "Устройство"
    return when (condition.type) {
        AutomationConditionType.DEVICE_POWER -> "$deviceName ${if (condition.value == "true") "включено" else "выключено"}"
        AutomationConditionType.SENSOR_VALUE -> "$deviceName: ${propertyLabel(condition.property)} ${condition.operator} ${condition.value}"
        AutomationConditionType.GLOBAL_VARIABLE -> "${condition.variableName} ${condition.operator} ${condition.value}"
        AutomationConditionType.TIME_WINDOW -> "Время между ${condition.startTime} и ${condition.endTime}"
        else -> "Условие"
    }
}

private fun actionDescription(action: AutomationAction, devices: List<HomeDevice>, variables: List<GlobalVariable>, cloudScenarios: List<HomeScenario>): String {
    val deviceName = devices.firstOrNull { it.id == action.deviceId }?.name ?: "Устройство"
    return when (action.type) {
        AutomationActionType.DEVICE_POWER -> "$deviceName: ${if (action.enabled) "включить" else "выключить"}"
        AutomationActionType.BRIGHTNESS -> "$deviceName: яркость ${action.brightness}%"
        AutomationActionType.SET_VARIABLE -> "${action.variableName} = ${action.variableValue}"
        AutomationActionType.RUN_YANDEX_SCENARIO -> "Запустить: ${cloudScenarios.firstOrNull { it.id == action.scenarioId }?.name ?: "сценарий Яндекса"}"
        else -> "Действие"
    }
}

private fun propertyLabel(instance: String): String = when (instance) {
    "temperature" -> "температура"
    "humidity" -> "влажность"
    "co2_level" -> "CO₂"
    "pressure" -> "давление"
    "illumination" -> "освещённость"
    "battery_level" -> "заряд"
    "power" -> "мощность"
    "motion" -> "движение"
    else -> instance.replace('_', ' ')
}
