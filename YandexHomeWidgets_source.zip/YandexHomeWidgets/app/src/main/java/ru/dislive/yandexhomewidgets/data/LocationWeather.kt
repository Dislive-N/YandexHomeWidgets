package ru.dislive.yandexhomewidgets.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.Geocoder
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

data class CurrentWeather(
    val temperatureC: Double,
    val humidityPercent: Int,
    val precipitationMm: Double,
    val windMetersPerSecond: Double,
    val weatherCode: Int,
    val placeName: String = "Местоположение",
    val fetchedAt: Long = System.currentTimeMillis()
) {
    val description: String get() = when (weatherCode) {
        0 -> "Ясно"
        1, 2 -> "Небольшая облачность"
        3 -> "Облачно"
        45, 48 -> "Туман"
        in 51..57 -> "Морось"
        in 61..67 -> "Дождь"
        in 71..77 -> "Снег"
        in 80..82 -> "Ливень"
        in 85..86 -> "Снегопад"
        in 95..99 -> "Гроза"
        else -> "Погода сейчас"
    }
}

/** Location access helpers for foreground weather and user-enabled background geofence checks. */
object LocationWeatherService {
    fun hasLocationPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackgroundLocationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            context.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    suspend fun currentLocation(context: Context): Location? {
        if (!hasLocationPermission(context)) return null
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { provider -> runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false) }
        if (providers.isEmpty()) return null

        val cached = providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
            .maxByOrNull { it.time }
        if (cached != null && System.currentTimeMillis() - cached.time <= 5 * 60_000L) return cached

        for (provider in providers) {
            val fresh = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    withTimeoutOrNull(12_000L) { requestCurrent(manager, provider, context) }
                } else {
                    withTimeoutOrNull(12_000L) { requestSingle(manager, provider) }
                }
            }.getOrNull()
            if (fresh != null) return fresh
        }
        return cached
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestCurrent(manager: LocationManager, provider: String, context: Context): Location? =
        suspendCancellableCoroutine { continuation ->
            val cancellation = CancellationSignal()
            continuation.invokeOnCancellation { cancellation.cancel() }
            manager.getCurrentLocation(provider, cancellation, context.mainExecutor) { location ->
                if (continuation.isActive) continuation.resume(location)
            }
        }

    @Suppress("DEPRECATION", "MissingPermission")
    private suspend fun requestSingle(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (continuation.isActive) {
                        manager.removeUpdates(this)
                        continuation.resume(location)
                    }
                }
                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
            }
            continuation.invokeOnCancellation { manager.removeUpdates(listener) }
            manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        }

    suspend fun resolvePlaceName(context: Context, latitude: Double, longitude: Double): String = withContext(Dispatchers.IO) {
        if (!Geocoder.isPresent()) return@withContext "Местоположение"
        runCatching {
            @Suppress("DEPRECATION")
            Geocoder(context, Locale("ru")).getFromLocation(latitude, longitude, 1)
                ?.firstOrNull()
                ?.let { address ->
                    address.locality
                        ?: address.subLocality
                        ?: address.subAdminArea
                        ?: address.adminArea
                }
                ?.takeIf { it.isNotBlank() }
        }.getOrNull() ?: "Местоположение"
    }

    suspend fun currentWeather(latitude: Double, longitude: Double, placeName: String = "Местоположение"): CurrentWeather? = withContext(Dispatchers.IO) {
        if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return@withContext null
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${"%.5f".format(java.util.Locale.US, latitude)}&longitude=${"%.5f".format(java.util.Locale.US, longitude)}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&wind_speed_unit=ms&timezone=auto"
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 8_000
            connection.readTimeout = 8_000
            connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
            if (connection.responseCode !in 200..299) return@withContext null
            val root = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val current = root.optJSONObject("current") ?: return@withContext null
            val temperature = current.optDouble("temperature_2m", Double.NaN)
            if (!temperature.isFinite()) return@withContext null
            CurrentWeather(
                temperatureC = temperature,
                humidityPercent = current.optDouble("relative_humidity_2m", 0.0).toInt().coerceIn(0, 100),
                precipitationMm = current.optDouble("precipitation", 0.0).coerceAtLeast(0.0),
                windMetersPerSecond = current.optDouble("wind_speed_10m", 0.0).coerceAtLeast(0.0),
                weatherCode = current.optInt("weather_code", -1),
                placeName = placeName.ifBlank { "Местоположение" }
            )
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }
}
