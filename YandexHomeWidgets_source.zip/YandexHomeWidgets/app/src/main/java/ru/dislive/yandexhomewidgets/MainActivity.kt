package ru.dislive.yandexhomewidgets

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch
import ru.dislive.yandexhomewidgets.data.AppUpdateChecker
import ru.dislive.yandexhomewidgets.data.AppUpdateInfo
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.HomeChange
import ru.dislive.yandexhomewidgets.data.HomeChangeDetector
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.HomeGroup
import ru.dislive.yandexhomewidgets.data.HomeHistoryStore
import ru.dislive.yandexhomewidgets.data.HomeNotificationCenter
import ru.dislive.yandexhomewidgets.data.HomeNotificationOptions
import ru.dislive.yandexhomewidgets.data.HomeNotificationSettings
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi
import ru.dislive.yandexhomewidgets.data.YandexOAuth
import ru.dislive.yandexhomewidgets.widget.HomeWidget
import ru.dislive.yandexhomewidgets.widget.WorkScheduler
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class AppPage { HOME, SCENARIOS, HISTORY, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkScheduler.schedule(this)
        HomeNotificationCenter.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4107)
        }
        setContent { YandexHomeApp() }
    }
}

@Composable
private fun YandexHomeApp() {
    val context = LocalContext.current
    val config = remember { context.getSharedPreferences("app_config", Context.MODE_PRIVATE) }
    val tokenStore = remember { TokenStore(context.applicationContext) }
    val scope = rememberCoroutineScope()

    var clientId by remember { mutableStateOf(config.getString("client_id", "").orEmpty()) }
    var redirectInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Сначала подключи Яндекс OAuth") }
    var error by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf(emptyList<HomeDevice>()) }
    var scenarios by remember { mutableStateOf(emptyList<HomeScenario>()) }
    var groups by remember { mutableStateOf(emptyList<HomeGroup>()) }
    var roomNames by remember { mutableStateOf(emptyList<String>()) }
    var notificationOptions by remember { mutableStateOf(HomeNotificationSettings.load(context)) }
    var history by remember { mutableStateOf(HomeHistoryStore.load(context)) }
    var page by remember { mutableStateOf(AppPage.HOME) }
    var isDarkTheme by remember { mutableStateOf(config.getBoolean("dark_theme", true)) }
    var isCheckingUpdate by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<AppUpdateInfo?>(null) }
    var updateMessage by remember { mutableStateOf("Нажми «Проверить обновления», чтобы проверить новую версию.") }

    suspend fun reloadHome() {
        isBusy = true
        error = ""
        try {
            val token = tokenStore.getValidAccessToken()
            if (token.isNullOrBlank()) {
                isConnected = false
                status = "Яндекс не подключён"
                return
            }
            val home = YandexHomeApi(token).getHome()
            val changes = HomeChangeDetector.collect(context, home)
            HomeNotificationCenter.showChanges(context, changes)
            devices = home.devices.map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }
            scenarios = home.scenarios
            groups = home.groups
            roomNames = home.rooms
            HomeCache.saveHome(context, home)
            history = HomeHistoryStore.load(context)
            isConnected = true
            status = "Подключено · ${devices.size} устройств · ${scenarios.size} сценариев"
            HomeWidget().updateAll(context)
        } catch (e: Exception) {
            error = e.message ?: "Не удалось загрузить умный дом"
            status = "Не удалось обновить данные"
        } finally {
            isBusy = false
        }
    }

    fun performDeviceAction(action: suspend (YandexHomeApi) -> Unit) {
        scope.launch {
            isBusy = true
            error = ""
            try {
                val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                action(YandexHomeApi(token))
                reloadHome()
            } catch (e: Exception) {
                error = e.message ?: "Не удалось выполнить команду"
                isBusy = false
            }
        }
    }

    fun checkUpdates() {
        scope.launch {
            isCheckingUpdate = true
            updateMessage = "Проверяю GitHub Releases…"
            updateInfo = null
            try {
                val found = AppUpdateChecker.check(BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)
                updateInfo = found
                updateMessage = if (found == null) "Установлена последняя доступная версия (${BuildConfig.VERSION_NAME})." else "Доступна версия ${found.version} (сборка ${found.buildCode})."
            } catch (e: Exception) {
                updateMessage = e.message ?: "Не удалось проверить обновления. Проверь подключение к интернету."
            } finally {
                isCheckingUpdate = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (clientId.isNotBlank()) reloadHome()
    }

    val colors = if (isDarkTheme) darkColorScheme(
        primary = Color(0xFF9DB8FF), onPrimary = Color(0xFF10203D),
        secondary = Color(0xFFB6C7EA), background = Color(0xFF101522),
        surface = Color(0xFF192236), onSurface = Color(0xFFF2F5FC),
        onBackground = Color(0xFFF2F5FC)
    ) else lightColorScheme(
        primary = Color(0xFF315DA8), onPrimary = Color.White,
        secondary = Color(0xFF536B91), background = Color(0xFFF5F7FB),
        surface = Color.White, onSurface = Color(0xFF1A2333),
        onBackground = Color(0xFF1A2333)
    )

    MaterialTheme(colorScheme = colors) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            when (page) {
                                AppPage.HOME -> "Яндекс Дом"
                                AppPage.SCENARIOS -> "Сценарии"
                                AppPage.HISTORY -> "История изменений"
                                AppPage.SETTINGS -> "Настройки"
                            }, fontSize = 25.sp, fontWeight = FontWeight.Bold
                        )
                        Text(status, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (page == AppPage.HOME || page == AppPage.SCENARIOS) {
                        TextButton(onClick = { page = AppPage.SETTINGS }) { Text("⚙") }
                    } else {
                        TextButton(onClick = { page = AppPage.HOME }) { Text("Назад") }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                if (!isConnected && page != AppPage.SETTINGS) {
                    ConnectionScreen(
                        clientId = clientId,
                        onClientIdChange = {
                            clientId = it
                            config.edit().putString("client_id", it.trim()).apply()
                        },
                        redirectInput = redirectInput,
                        onRedirectChange = { redirectInput = it },
                        isBusy = isBusy,
                        error = error,
                        onOpenOAuth = {
                            try {
                                val url = YandexOAuth.authorizationUrl(clientId, tokenStore)
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                status = "Подтверди доступ на странице Яндекса, затем вернись сюда"
                            } catch (e: Exception) { error = e.message ?: "Не удалось открыть авторизацию" }
                        },
                        onConnect = {
                            scope.launch {
                                isBusy = true
                                error = ""
                                try {
                                    val response = YandexOAuth.exchangeRedirect(redirectInput, clientId, tokenStore)
                                    tokenStore.saveTokens(response)
                                    redirectInput = ""
                                    status = "Токен получен. Загружаю устройства…"
                                    reloadHome()
                                } catch (e: Exception) {
                                    error = e.message ?: "Не удалось завершить подключение"
                                    isBusy = false
                                }
                            }
                        }
                    )
                } else {
                    when (page) {
                        AppPage.HOME -> HomeScreen(
                            devices = devices,
                            groups = groups,
                            rooms = roomNames,
                            isBusy = isBusy,
                            onRefresh = { scope.launch { reloadHome() } },
                            onHistory = { history = HomeHistoryStore.load(context); page = AppPage.HISTORY },
                            onFavorite = { device, favorite ->
                                HomeCache.setFavorite(context, device.id, favorite)
                                devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                scope.launch { HomeWidget().updateAll(context) }
                            },
                            onToggle = { device, value -> performDeviceAction { it.setOnOff(device.id, value) } },
                            onBrightness = { device, value -> performDeviceAction { it.setBrightness(device.id, value) } },
                            onHue = { device, hue -> performDeviceAction {
                                val cap = device.colorCapability
                                if (cap?.colorModel == "hsv") it.setColorHsv(device.id, hue)
                                else it.setColorRgb(device.id, android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 1f, 1f)) and 0x00FFFFFF)
                            } },
                            onTemperature = { device, value -> performDeviceAction { it.setColorTemperature(device.id, value) } },
                            onColorScene = { device, value -> performDeviceAction { it.setColorScene(device.id, value) } },
                            onMode = { device, instance, value -> performDeviceAction { it.setMode(device.id, instance, value) } }
                        )
                        AppPage.SCENARIOS -> ScenariosScreen(
                            scenarios = scenarios,
                            isBusy = isBusy,
                            onRun = { scenario -> performDeviceAction { it.runScenario(scenario.id) } }
                        )
                        AppPage.HISTORY -> HistoryScreen(
                            history = history,
                            onClear = { HomeHistoryStore.clear(context); history = emptyList() }
                        )
                        AppPage.SETTINGS -> SettingsScreen(
                            isDarkTheme = isDarkTheme,
                            onThemeChange = {
                                isDarkTheme = it
                                config.edit().putBoolean("dark_theme", it).apply()
                            },
                            options = notificationOptions,
                            onNotificationChange = {
                                notificationOptions = it
                                HomeNotificationSettings.save(context, it)
                            },
                            updateMessage = updateMessage,
                            updateInfo = updateInfo,
                            isCheckingUpdate = isCheckingUpdate,
                            onCheckUpdates = ::checkUpdates,
                            onDisconnect = {
                                tokenStore.clear()
                                HomeCache.clear(context)
                                devices = emptyList()
                                scenarios = emptyList()
                                groups = emptyList()
                                roomNames = emptyList()
                                isConnected = false
                                page = AppPage.HOME
                                status = "Яндекс отключён"
                                error = ""
                                scope.launch { HomeWidget().updateAll(context) }
                            },
                            onNotificationPermission = {
                                if (Build.VERSION.SDK_INT >= 33) {
                                    context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                                }
                            }
                        )
                    }
                }

                if (error.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(error, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                if (isConnected && (page == AppPage.HOME || page == AppPage.SCENARIOS)) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = page == AppPage.HOME,
                            onClick = { page = AppPage.HOME },
                            icon = { Text("⌂") }, label = { Text("Главная") }
                        )
                        NavigationBarItem(
                            selected = page == AppPage.SCENARIOS,
                            onClick = { page = AppPage.SCENARIOS },
                            icon = { Text("▶") }, label = { Text("Сценарии") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionScreen(
    clientId: String,
    onClientIdChange: (String) -> Unit,
    redirectInput: String,
    onRedirectChange: (String) -> Unit,
    isBusy: Boolean,
    error: String,
    onOpenOAuth: () -> Unit,
    onConnect: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Подключение к Яндексу", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Создай приложение в Яндекс OAuth типа «Для доступа к API или отладки». Выдай разрешения iot:view и iot:control. В Redirect URI укажи https://oauth.yandex.ru/verification_code.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), fontSize = 13.sp
                )
                TextButton(onClick = { openUrl(context, "https://oauth.yandex.ru/client/new/") }) { Text("Открыть Яндекс OAuth") }
                OutlinedTextField(value = clientId, onValueChange = onClientIdChange, modifier = Modifier.fillMaxWidth(), label = { Text("Client ID") }, singleLine = true)
                Button(onClick = onOpenOAuth, enabled = clientId.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) { Text("Открыть страницу подтверждения") }
                Divider()
                Text("После подтверждения скопируй полный адрес из адресной строки браузера и вставь ниже. Пароль и Client Secret сюда вводить не нужно.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                OutlinedTextField(value = redirectInput, onValueChange = onRedirectChange, modifier = Modifier.fillMaxWidth(), label = { Text("Полный адрес после подтверждения") }, minLines = 2)
                Button(onClick = onConnect, enabled = clientId.isNotBlank() && redirectInput.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) {
                    if (isBusy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Подключить")
                }
                Text("OAuth PKCE. Токены хранятся зашифрованными через Android Keystore.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    devices: List<HomeDevice>,
    groups: List<HomeGroup>,
    rooms: List<String>,
    isBusy: Boolean,
    onRefresh: () -> Unit,
    onHistory: () -> Unit,
    onFavorite: (HomeDevice, Boolean) -> Unit,
    onToggle: (HomeDevice, Boolean) -> Unit,
    onBrightness: (HomeDevice, Int) -> Unit,
    onHue: (HomeDevice, Int) -> Unit,
    onTemperature: (HomeDevice, Int) -> Unit,
    onColorScene: (HomeDevice, String) -> Unit,
    onMode: (HomeDevice, String, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onHistory, modifier = Modifier.weight(1f)) { Text("История изменений") }
            OutlinedButton(onClick = onRefresh, enabled = !isBusy) {
                if (isBusy) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Обновить")
            }
        }
        if (devices.isEmpty()) {
            EmptyCard("Устройства не найдены. Проверь, что они добавлены в Дом с Алисой.")
        } else {
            val devicesByRoom = devices.groupBy { it.room.ifBlank { "Без комнаты" } }
            val allRooms = (rooms + devicesByRoom.keys).distinct().ifEmpty { listOf("Без комнаты") }
            allRooms.forEach { roomName ->
                Text(roomName, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                val roomDevices = devicesByRoom[roomName].orEmpty()
                if (roomDevices.isEmpty()) Text("Нет устройств", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontSize = 12.sp)
                roomDevices.forEach { device ->
                    DeviceCard(
                        device = device,
                        onFavorite = { onFavorite(device, it) },
                        onToggle = { onToggle(device, it) },
                        onBrightness = { onBrightness(device, it) },
                        onHue = { onHue(device, it) },
                        onTemperature = { onTemperature(device, it) },
                        onColorScene = { onColorScene(device, it) },
                        onMode = { instance, value -> onMode(device, instance, value) }
                    )
                }
            }
        }
        if (groups.isNotEmpty()) {
            Text("Группы", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            groups.forEach { group ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(group.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Text("${group.deviceIds.size} устройств", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceCard(
    device: HomeDevice,
    onFavorite: (Boolean) -> Unit,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    var sliderValue by remember(device.id, device.brightness) { mutableFloatStateOf((device.brightness ?: device.brightnessMin).toFloat()) }
    val colorCapability = device.colorCapability
    var hue by remember(device.id) { mutableFloatStateOf(210f) }
    var temperature by remember(device.id, colorCapability?.value) {
        mutableFloatStateOf((colorCapability?.value as? Number)?.toFloat() ?: ((colorCapability?.temperatureMin ?: 2700) + (colorCapability?.temperatureMax ?: 6500)) / 2f)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(device.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(device.type.removePrefix("devices.types.").replace('.', ' '), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                }
                TextButton(onClick = { onFavorite(!device.isFavorite) }) { Text(if (device.isFavorite) "★" else "☆", fontSize = 20.sp) }
                if (device.canToggle && device.onOff != null) Switch(checked = device.onOff, onCheckedChange = onToggle)
            }
            if (device.canDim && device.brightness != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Яркость", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Spacer(Modifier.weight(1f))
                    Text("${sliderValue.toInt()}%", fontSize = 12.sp)
                }
                val lower = device.brightnessMin.toFloat()
                val upper = device.brightnessMax.toFloat().coerceAtLeast(lower + 1f)
                Slider(value = sliderValue.coerceIn(lower, upper), onValueChange = { sliderValue = it },
                    onValueChangeFinished = { onBrightness(sliderValue.toInt()) }, valueRange = lower..upper)
            }
            if (colorCapability != null) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Text("Цвет лампы", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                if (colorCapability.colorModel == "rgb" || colorCapability.colorModel == "hsv") {
                    Text("Выбери оттенок", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(0f, 25f, 55f, 115f, 175f, 210f, 270f, 325f).forEach { presetHue ->
                            Box(modifier = Modifier.size(25.dp).background(Color.hsv(presetHue, 1f, 1f), CircleShape)
                                .clickable { hue = presetHue; onHue(presetHue.toInt()) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Тон", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        Spacer(Modifier.width(8.dp))
                        Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f,
                            onValueChangeFinished = { onHue(hue.toInt()) }, modifier = Modifier.weight(1f))
                    }
                }
                if (colorCapability.temperatureSupported && colorCapability.temperatureMax > colorCapability.temperatureMin) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Температура света", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Spacer(Modifier.weight(1f))
                        Text("${temperature.toInt()} K", fontSize = 11.sp)
                    }
                    Slider(value = temperature.coerceIn(colorCapability.temperatureMin.toFloat(), colorCapability.temperatureMax.toFloat()),
                        onValueChange = { temperature = it },
                        onValueChangeFinished = { onTemperature(temperature.toInt()) },
                        valueRange = colorCapability.temperatureMin.toFloat()..colorCapability.temperatureMax.toFloat())
                }
                if (colorCapability.colorScenes.isNotEmpty()) {
                    Text("Световые эффекты", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        colorCapability.colorScenes.forEach { scene ->
                            FilterChip(selected = colorCapability.instance == "scene" && colorCapability.value == scene,
                                onClick = { onColorScene(scene) }, label = { Text(sceneLabel(scene), fontSize = 11.sp) })
                        }
                    }
                }
            }
            device.modeCapabilities.forEach { capability ->
                Text(modeInstanceLabel(capability.instance), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    capability.modeOptions.forEach { mode ->
                        FilterChip(
                            selected = capability.value == mode,
                            onClick = { onMode(capability.instance, mode) },
                            label = { Text(modeLabel(mode), fontSize = 11.sp) }
                        )
                    }
                }
            }
            if (device.properties.isNotEmpty()) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Text("Показатели датчиков", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                device.properties.forEach { property ->
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(sensorLabel(property.instance), modifier = Modifier.weight(1f), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text(sensorValue(property.instance, property.value), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            if (!device.canToggle && !device.canDim && colorCapability == null && device.modeCapabilities.isEmpty() && device.properties.isEmpty()) {
                Text("Устройство доступно для просмотра, но API не предоставил поддерживаемых элементов управления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
        }
    }
}

@Composable
private fun ScenariosScreen(scenarios: List<HomeScenario>, isBusy: Boolean, onRun: (HomeScenario) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Запускай созданные в приложении «Дом с Алисой» сценарии.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        if (scenarios.isEmpty()) EmptyCard("Сценарии не найдены.")
        scenarios.forEach { scenario ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(scenario.name, fontWeight = FontWeight.Medium)
                        Text(if (scenario.isActive) "Активен" else "Сценарий", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), fontSize = 11.sp)
                    }
                    Button(onClick = { onRun(scenario) }, enabled = !isBusy) { Text("Запустить") }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(history: List<HomeChange>, onClear: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Последние изменения", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            TextButton(onClick = onClear, enabled = history.isNotEmpty()) { Text("Очистить") }
        }
        if (history.isEmpty()) {
            EmptyCard("История пока пуста. Она начнёт заполняться после обнаружения изменений в доме.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { "${it.timestamp}-${it.kind}-${it.title}-${it.detail}" }) { change ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(change.title, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            Text(change.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                            Text(SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()).format(Date(change.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    isDarkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit,
    options: HomeNotificationOptions,
    onNotificationChange: (HomeNotificationOptions) -> Unit,
    updateMessage: String,
    updateInfo: AppUpdateInfo?,
    isCheckingUpdate: Boolean,
    onCheckUpdates: () -> Unit,
    onDisconnect: () -> Unit,
    onNotificationPermission: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Оформление", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Тёмная тема", isDarkTheme, onThemeChange)
                Text(if (isDarkTheme) "Используется тёмное оформление." else "Используется светлое оформление.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Уведомления", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Все уведомления", options.enabled) { onNotificationChange(options.copy(enabled = it)) }
                if (options.enabled) {
                    Divider()
                    SettingSwitch("Устройства, комнаты и структура дома", options.deviceChanges) { onNotificationChange(options.copy(deviceChanges = it)) }
                    SettingSwitch("Изменения состояний устройств", options.capabilityChanges) { onNotificationChange(options.copy(capabilityChanges = it)) }
                    SettingSwitch("Датчики и показатели", options.sensorChanges) { onNotificationChange(options.copy(sensorChanges = it)) }
                    SettingSwitch("Группы и сценарии", options.groupScenarioChanges) { onNotificationChange(options.copy(groupScenarioChanges = it)) }
                }
                Text("Фоновая проверка выполняется примерно раз в 15 минут. Android может задерживать её; это не мгновенные push-уведомления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                OutlinedButton(onClick = onNotificationPermission, modifier = Modifier.fillMaxWidth()) { Text("Разрешения уведомлений Android") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Обновление приложения", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Установленная версия: ${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Text(updateMessage, fontSize = 12.sp)
                if (!updateInfo?.notes.isNullOrBlank()) Text(updateInfo?.notes.orEmpty(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Button(onClick = onCheckUpdates, enabled = !isCheckingUpdate, modifier = Modifier.fillMaxWidth()) {
                    if (isCheckingUpdate) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Проверить обновления")
                }
                if (updateInfo != null) {
                    Button(onClick = { openUrl(context, updateInfo.apkUrl ?: updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Скачать обновление ${updateInfo.version}") }
                    TextButton(onClick = { openUrl(context, updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Описание версии на GitHub") }
                }
                Text("Обновление загружается с GitHub Releases. После скачивания Android попросит подтвердить установку.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
        }
        OutlinedButton(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) { Text("Отключить Яндекс") }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Text(message, modifier = Modifier.fillMaxWidth().padding(16.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}

private fun sensorLabel(instance: String): String = when (instance) {
    "temperature" -> "Температура"
    "humidity" -> "Влажность"
    "pressure" -> "Давление"
    "battery_level" -> "Заряд батареи"
    "voltage" -> "Напряжение"
    "current" -> "Ток"
    "power" -> "Мощность"
    "illumination" -> "Освещённость"
    "co2_level" -> "Уровень CO₂"
    "pm1_density" -> "PM1"
    "pm2.5_density" -> "PM2.5"
    "pm10_density" -> "PM10"
    "open" -> "Открытие"
    "motion" -> "Движение"
    "vibration" -> "Вибрация"
    "water_leak" -> "Протечка"
    "smoke" -> "Дым"
    "gas" -> "Газ"
    else -> instance.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun sensorValue(instance: String, value: Any?): String {
    val raw = when (value) {
        null -> "Нет данных"
        is Boolean -> if (value) "Да" else "Нет"
        else -> value.toString()
    }
    val unit = when (instance) {
        "temperature" -> " °C"
        "humidity", "battery_level" -> "%"
        "pressure" -> " гПа"
        "illumination" -> " лк"
        "co2_level" -> " ppm"
        "voltage" -> " В"
        "current" -> " А"
        "power" -> " Вт"
        else -> ""
    }
    return when (raw.lowercase()) {
        "open" -> "Открыто"
        "closed" -> "Закрыто"
        "detected" -> "Обнаружено"
        "not_detected" -> "Не обнаружено"
        else -> raw + unit
    }
}

private fun sceneLabel(id: String): String = when (id) {
    "alarm" -> "Тревога"
    "alice" -> "Алиса"
    "candle" -> "Свеча"
    "dinner" -> "Ужин"
    "fantasy" -> "Фантазия"
    "garland" -> "Гирлянда"
    "jungle" -> "Джунгли"
    "movie" -> "Кино"
    "neon" -> "Неон"
    "night" -> "Ночь"
    "ocean" -> "Океан"
    "party" -> "Вечеринка"
    "reading" -> "Чтение"
    "rest" -> "Отдых"
    "romance" -> "Романтика"
    "siren" -> "Сирена"
    else -> id
}

private fun modeInstanceLabel(instance: String): String = when (instance) {
    "thermostat" -> "Режим термостата"
    "cleanup_mode" -> "Режим уборки"
    "fan_speed" -> "Скорость вентилятора"
    else -> "Режим: $instance"
}

private fun modeLabel(value: String): String = when (value) {
    "auto" -> "Авто"
    "heat" -> "Обогрев"
    "cool" -> "Охлаждение"
    "dry" -> "Осушение"
    "fan_only" -> "Вентиляция"
    "on" -> "Вкл."
    "off" -> "Выкл."
    "high" -> "Высокая"
    "medium" -> "Средняя"
    "low" -> "Низкая"
    "turbo" -> "Турбо"
    "eco" -> "Эко"
    else -> value.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
