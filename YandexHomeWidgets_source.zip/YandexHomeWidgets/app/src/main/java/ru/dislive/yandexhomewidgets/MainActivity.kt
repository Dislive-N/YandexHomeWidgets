package ru.dislive.yandexhomewidgets

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch
import ru.dislive.yandexhomewidgets.data.AppUpdateChecker
import ru.dislive.yandexhomewidgets.data.AppUpdateInfo
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.HomeChange
import ru.dislive.yandexhomewidgets.data.HomeChangeDetector
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.DeviceGroup
import ru.dislive.yandexhomewidgets.data.DeviceGroupStore
import ru.dislive.yandexhomewidgets.data.HomeGroup
import ru.dislive.yandexhomewidgets.data.HomeHistoryStore
import ru.dislive.yandexhomewidgets.data.HomeNotificationCenter
import ru.dislive.yandexhomewidgets.data.HomeNotificationOptions
import ru.dislive.yandexhomewidgets.data.HomeNotificationSettings
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi
import ru.dislive.yandexhomewidgets.data.YandexOAuth
import ru.dislive.yandexhomewidgets.widget.HomeWidget
import ru.dislive.yandexhomewidgets.widget.WorkScheduler
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class AppPage { HOME, SCENARIOS, HISTORY, SETTINGS, DEVICE, GROUPS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkScheduler.schedule(this)
        HomeNotificationCenter.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4107)
        }
        setContent { YandexHomeApp() }
    }
}

@Composable
private fun YandexHomeApp() {
    val context = LocalContext.current
    val config = remember { context.getSharedPreferences("app_config", Context.MODE_PRIVATE) }
    val tokenStore = remember { TokenStore(context.applicationContext) }
    val scope = rememberCoroutineScope()

    var clientId by remember { mutableStateOf(config.getString("client_id", "").orEmpty()) }
    var redirectInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Сначала подключи Яндекс OAuth") }
    var error by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf(emptyList<HomeDevice>()) }
    var scenarios by remember { mutableStateOf(emptyList<HomeScenario>()) }
    var groups by remember { mutableStateOf(emptyList<HomeGroup>()) }
    var customGroups by remember { mutableStateOf(DeviceGroupStore.load(context)) }
    var selectedDeviceId by remember { mutableStateOf<String?>(null) }
    var roomNames by remember { mutableStateOf(emptyList<String>()) }
    var notificationOptions by remember { mutableStateOf(HomeNotificationSettings.load(context)) }
    var history by remember { mutableStateOf(HomeHistoryStore.load(context)) }
    var page by remember { mutableStateOf(AppPage.HOME) }
    var isDarkTheme by remember { mutableStateOf(config.getBoolean("dark_theme", true)) }
    var isCheckingUpdate by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<AppUpdateInfo?>(null) }
    var updateMessage by remember { mutableStateOf("Нажми «Проверить обновления», чтобы проверить новую версию.") }

    suspend fun reloadHome() {
        isBusy = true
        error = ""
        try {
            val token = tokenStore.getValidAccessToken()
            if (token.isNullOrBlank()) {
                isConnected = false
                status = "Яндекс не подключён"
                return
            }
            val home = YandexHomeApi(token).getHome()
            val changes = HomeChangeDetector.collect(context, home)
            HomeNotificationCenter.showChanges(context, changes)
            devices = home.devices.map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }
            scenarios = home.scenarios
            groups = home.groups
            roomNames = home.rooms
            HomeCache.saveHome(context, home)
            history = HomeHistoryStore.load(context)
            isConnected = true
            status = "Подключено · ${devices.size} устройств · ${scenarios.size} сценариев"
            HomeWidget().updateAll(context)
        } catch (e: Exception) {
            error = e.message ?: "Не удалось загрузить умный дом"
            status = "Не удалось обновить данные"
        } finally {
            isBusy = false
        }
    }

    fun performDeviceAction(action: suspend (YandexHomeApi) -> Unit) {
        scope.launch {
            isBusy = true
            error = ""
            try {
                val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                action(YandexHomeApi(token))
                reloadHome()
            } catch (e: Exception) {
                error = e.message ?: "Не удалось выполнить команду"
                isBusy = false
            }
        }
    }

    fun checkUpdates() {
        scope.launch {
            isCheckingUpdate = true
            updateMessage = "Проверяю GitHub Releases…"
            updateInfo = null
            try {
                val found = AppUpdateChecker.check(BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)
                updateInfo = found
                updateMessage = if (found == null) "Установлена последняя доступная версия (${BuildConfig.VERSION_NAME})." else "Доступна версия ${found.version} (сборка ${found.buildCode})."
            } catch (e: Exception) {
                updateMessage = e.message ?: "Не удалось проверить обновления. Проверь подключение к интернету."
            } finally {
                isCheckingUpdate = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (clientId.isNotBlank()) reloadHome()
    }

    val colors = if (isDarkTheme) darkColorScheme(
        primary = Color(0xFF9DB8FF), onPrimary = Color(0xFF10203D),
        secondary = Color(0xFFB6C7EA), background = Color(0xFF101522),
        surface = Color(0xFF192236), onSurface = Color(0xFFF2F5FC),
        onBackground = Color(0xFFF2F5FC)
    ) else lightColorScheme(
        primary = Color(0xFF315DA8), onPrimary = Color.White,
        secondary = Color(0xFF536B91), background = Color(0xFFF5F7FB),
        surface = Color.White, onSurface = Color(0xFF1A2333),
        onBackground = Color(0xFF1A2333)
    )

    MaterialTheme(colorScheme = colors) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            when (page) {
                                AppPage.HOME -> "Яндекс Дом"
                                AppPage.SCENARIOS -> "Сценарии"
                                AppPage.HISTORY -> "История изменений"
                                AppPage.SETTINGS -> "Настройки"
                                AppPage.DEVICE -> devices.firstOrNull { it.id == selectedDeviceId }?.name ?: "Устройство"
                                AppPage.GROUPS -> "Настройка групп"
                            }, fontSize = 25.sp, fontWeight = FontWeight.Bold
                        )
                        Text(status, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (page == AppPage.HOME || page == AppPage.SCENARIOS) {
                        TextButton(onClick = { page = AppPage.SETTINGS }) { Text("⚙") }
                    } else {
                        TextButton(onClick = { page = AppPage.HOME; selectedDeviceId = null }) { Text("← Назад") }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                Box(modifier = Modifier.weight(1f)) {
                    if (!isConnected && page != AppPage.SETTINGS) {
                        ConnectionScreen(
                            clientId = clientId,
                            onClientIdChange = {
                                clientId = it
                                config.edit().putString("client_id", it.trim()).apply()
                            },
                            redirectInput = redirectInput,
                            onRedirectChange = { redirectInput = it },
                            isBusy = isBusy,
                            error = error,
                            onOpenOAuth = {
                                try {
                                    val url = YandexOAuth.authorizationUrl(clientId, tokenStore)
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    status = "Подтверди доступ на странице Яндекса, затем вернись сюда"
                                } catch (e: Exception) { error = e.message ?: "Не удалось открыть авторизацию" }
                            },
                            onConnect = {
                                scope.launch {
                                    isBusy = true
                                    error = ""
                                    try {
                                        val response = YandexOAuth.exchangeRedirect(redirectInput, clientId, tokenStore)
                                        tokenStore.saveTokens(response)
                                        redirectInput = ""
                                        status = "Токен получен. Загружаю устройства…"
                                        reloadHome()
                                    } catch (e: Exception) {
                                        error = e.message ?: "Не удалось завершить подключение"
                                        isBusy = false
                                    }
                                }
                            }
                        )
                    } else {
                        when (page) {
                            AppPage.HOME -> HomeScreen(
                                devices = devices,
                                customGroups = customGroups,
                                rooms = roomNames,
                                isBusy = isBusy,
                                onRefresh = { if (!isBusy) scope.launch { reloadHome() } },
                                onHistory = { history = HomeHistoryStore.load(context); page = AppPage.HISTORY },
                                onOpenGroups = { page = AppPage.GROUPS },
                                onOpenDevice = { selectedDeviceId = it.id; page = AppPage.DEVICE },
                                onToggle = { device, value ->
                                    if (!isBusy && device.canToggle) performDeviceAction { it.setOnOff(device.id, value) }
                                }
                            )
                            AppPage.DEVICE -> {
                                val device = devices.firstOrNull { it.id == selectedDeviceId }
                                if (device == null) EmptyCard("Устройство больше не найдено. Обнови список устройств.")
                                else DeviceDetailsScreen(
                                    device = device,
                                    isBusy = isBusy,
                                    onFavorite = { favorite ->
                                        HomeCache.setFavorite(context, device.id, favorite)
                                        devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                        scope.launch { HomeWidget().updateAll(context) }
                                    },
                                    onToggle = { value -> if (!isBusy) performDeviceAction { it.setOnOff(device.id, value) } },
                                    onBrightness = { value -> if (!isBusy) performDeviceAction { it.setBrightness(device.id, value) } },
                                    onHue = { hue -> if (!isBusy) performDeviceAction {
                                        val cap = device.colorCapability
                                        if (cap?.colorModel == "hsv") it.setColorHsv(device.id, hue)
                                        else it.setColorRgb(device.id, android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 1f, 1f)) and 0x00FFFFFF)
                                    } },
                                    onTemperature = { value -> if (!isBusy) performDeviceAction { it.setColorTemperature(device.id, value) } },
                                    onColorScene = { value -> if (!isBusy) performDeviceAction { it.setColorScene(device.id, value) } },
                                    onMode = { instance, value -> if (!isBusy) performDeviceAction { it.setMode(device.id, instance, value) } }
                                )
                            }
                            AppPage.GROUPS -> GroupsScreen(
                                groups = customGroups,
                                devices = devices,
                                onSave = { group ->
                                    val claimed = group.deviceIds.toSet()
                                    customGroups = (
                                        customGroups.filterNot { it.id == group.id }
                                            .map { old -> old.copy(deviceIds = old.deviceIds.filterNot { it in claimed }) }
                                            .filter { it.deviceIds.isNotEmpty() } + group
                                    ).sortedBy { it.name.lowercase() }
                                    DeviceGroupStore.save(context, customGroups)
                                },
                                onDelete = { group ->
                                    customGroups = customGroups.filterNot { it.id == group.id }
                                    DeviceGroupStore.save(context, customGroups)
                                }
                            )
                            AppPage.SCENARIOS -> ScenariosScreen(
                                scenarios = scenarios,
                                isBusy = isBusy,
                                onRun = { scenario -> if (!isBusy) performDeviceAction { it.runScenario(scenario.id) } }
                            )
                            AppPage.HISTORY -> HistoryScreen(
                                history = history,
                                onClear = { HomeHistoryStore.clear(context); history = emptyList() }
                            )
                            AppPage.SETTINGS -> SettingsScreen(
                                isDarkTheme = isDarkTheme,
                                onThemeChange = {
                                    isDarkTheme = it
                                    config.edit().putBoolean("dark_theme", it).apply()
                                },
                                options = notificationOptions,
                                onNotificationChange = {
                                    notificationOptions = it
                                    HomeNotificationSettings.save(context, it)
                                },
                                updateMessage = updateMessage,
                                updateInfo = updateInfo,
                                isCheckingUpdate = isCheckingUpdate,
                                onCheckUpdates = ::checkUpdates,
                                onDisconnect = {
                                    tokenStore.clear()
                                    HomeCache.clear(context)
                                    devices = emptyList()
                                    scenarios = emptyList()
                                    groups = emptyList()
                                    roomNames = emptyList()
                                    isConnected = false
                                    page = AppPage.HOME
                                    status = "Яндекс отключён"
                                    error = ""
                                    scope.launch { HomeWidget().updateAll(context) }
                                },
                                onNotificationPermission = {
                                    if (Build.VERSION.SDK_INT >= 33) {
                                        context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                                    }
                                }
                            )
                        }
                    }
                }

                if (error.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(error, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                    }
                }
                if (isConnected && (page == AppPage.HOME || page == AppPage.SCENARIOS)) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = page == AppPage.HOME,
                            onClick = { page = AppPage.HOME },
                            icon = { Text("⌂") }, label = { Text("Главная") }
                        )
                        NavigationBarItem(
                            selected = page == AppPage.SCENARIOS,
                            onClick = { page = AppPage.SCENARIOS },
                            icon = { Text("▶") }, label = { Text("Сценарии") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionScreen(
    clientId: String,
    onClientIdChange: (String) -> Unit,
    redirectInput: String,
    onRedirectChange: (String) -> Unit,
    isBusy: Boolean,
    error: String,
    onOpenOAuth: () -> Unit,
    onConnect: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Подключение к Яндексу", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Создай приложение в Яндекс OAuth типа «Для доступа к API или отладки». Выдай разрешения iot:view и iot:control. В Redirect URI укажи https://oauth.yandex.ru/verification_code.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), fontSize = 13.sp
                )
                TextButton(onClick = { openUrl(context, "https://oauth.yandex.ru/client/new/") }) { Text("Открыть Яндекс OAuth") }
                OutlinedTextField(value = clientId, onValueChange = onClientIdChange, modifier = Modifier.fillMaxWidth(), label = { Text("Client ID") }, singleLine = true)
                Button(onClick = onOpenOAuth, enabled = clientId.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) { Text("Открыть страницу подтверждения") }
                Divider()
                Text("После подтверждения скопируй полный адрес из адресной строки браузера и вставь ниже. Пароль и Client Secret сюда вводить не нужно.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                OutlinedTextField(value = redirectInput, onValueChange = onRedirectChange, modifier = Modifier.fillMaxWidth(), label = { Text("Полный адрес после подтверждения") }, minLines = 2)
                Button(onClick = onConnect, enabled = clientId.isNotBlank() && redirectInput.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) {
                    if (isBusy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Подключить")
                }
                Text("OAuth PKCE. Токены хранятся зашифрованными через Android Keystore.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    devices: List<HomeDevice>,
    customGroups: List<DeviceGroup>,
    rooms: List<String>,
    isBusy: Boolean,
    onRefresh: () -> Unit,
    onHistory: () -> Unit,
    onOpenGroups: () -> Unit,
    onOpenDevice: (HomeDevice) -> Unit,
    onToggle: (HomeDevice, Boolean) -> Unit
) {
    val groupedIds = remember(customGroups) { customGroups.flatMap { it.deviceIds }.toSet() }
    val ungroupedByRoom = remember(devices, groupedIds) {
        devices.filterNot { it.id in groupedIds }.groupBy { it.room.ifBlank { "Без комнаты" } }
    }
    val allRooms = remember(rooms, ungroupedByRoom) {
        (rooms.filter { ungroupedByRoom.containsKey(it) } + ungroupedByRoom.keys).distinct()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item(key = "home_actions") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = onHistory, modifier = Modifier.weight(1f)) { Text("История", fontSize = 12.sp) }
                OutlinedButton(onClick = onOpenGroups, modifier = Modifier.weight(1f)) { Text("Группы", fontSize = 12.sp) }
                Button(onClick = onRefresh, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                    if (isBusy) CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp)
                    else Text("Обновить", fontSize = 12.sp)
                }
            }
        }
        if (devices.isEmpty()) {
            item(key = "empty_devices") {
                EmptyCard("Устройства не найдены. Проверь, что они добавлены в Дом с Алисой.")
            }
        } else {
            customGroups.forEach { group ->
                val members = devices.filter { it.id in group.deviceIds }
                if (members.isNotEmpty()) {
                    item(key = "group_${group.id}") {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 7.dp)) {
                            Text(group.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${members.size}", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), fontSize = 12.sp)
                        }
                    }
                    items(members, key = { "device_${it.id}" }) { device ->
                        CompactDeviceRow(
                            device = device,
                            enabled = !isBusy,
                            onOpen = { onOpenDevice(device) },
                            onToggle = { onToggle(device, it) }
                        )
                    }
                }
            }
            allRooms.forEach { roomName ->
                val roomDevices = ungroupedByRoom[roomName].orEmpty()
                if (roomDevices.isNotEmpty()) {
                    item(key = "room_$roomName") {
                        Text(roomName, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
                    }
                    items(roomDevices, key = { "device_${it.id}" }) { device ->
                        CompactDeviceRow(
                            device = device,
                            enabled = !isBusy,
                            onOpen = { onOpenDevice(device) },
                            onToggle = { onToggle(device, it) }
                        )
                    }
                }
            }
        }
        if (customGroups.none { group -> devices.any { it.id in group.deviceIds } } && devices.isNotEmpty()) {
            item(key = "group_hint") {
                Text("Создай группы, чтобы объединить устройства по своему усмотрению.", fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}

@Composable
private fun CompactDeviceRow(
    device: HomeDevice,
    enabled: Boolean,
    onOpen: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier.size(45.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(deviceIcon(device.type), fontSize = 24.sp)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(device.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    when (device.onOff) {
                        true -> "Включено"
                        false -> "Выключено"
                        null -> device.room.ifBlank { "Устройство" }
                    },
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f),
                    maxLines = 1
                )
            }
            Button(
                onClick = { onToggle(!(device.onOff ?: false)) },
                enabled = enabled && device.canToggle && device.onOff != null,
                modifier = Modifier.size(44.dp),
                contentPadding = PaddingValues(0.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (device.onOff == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (device.onOff == true) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Text("⏻", fontSize = 22.sp)
            }
        }
    }
}

private fun deviceIcon(type: String): String {
    val value = type.lowercase()
    return when {
        "light" in value || "lamp" in value -> "💡"
        "socket" in value || "plug" in value -> "🔌"
        "sensor" in value || "temperature" in value -> "🌡️"
        "camera" in value -> "📷"
        "vacuum" in value || "cleaner" in value -> "🤖"
        "switch" in value -> "🔘"
        "thermostat" in value -> "🌡️"
        "speaker" in value -> "🔊"
        "lock" in value -> "🔒"
        "curtain" in value -> "🪟"
        else -> "⌂"
    }
}

@Composable
private fun DeviceDetailsScreen(
    device: HomeDevice,
    isBusy: Boolean,
    onFavorite: (Boolean) -> Unit,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "device_intro") {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier.size(64.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.13f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(deviceIcon(device.type), fontSize = 32.sp) }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(device.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(device.room.ifBlank { "Без комнаты" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Text(device.type.removePrefix("devices.types.").replace('.', ' '), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f))
                    }
                    TextButton(onClick = { onFavorite(!device.isFavorite) }) {
                        Text(if (device.isFavorite) "★" else "☆", fontSize = 22.sp)
                    }
                }
            }
        }
        item(key = "device_controls") {
            DeviceCard(
                device = device,
                isBusy = isBusy,
                onToggle = onToggle,
                onBrightness = onBrightness,
                onHue = onHue,
                onTemperature = onTemperature,
                onColorScene = onColorScene,
                onMode = onMode
            )
        }
    }
}

@Composable
private fun GroupsScreen(
    groups: List<DeviceGroup>,
    devices: List<HomeDevice>,
    onSave: (DeviceGroup) -> Unit,
    onDelete: (DeviceGroup) -> Unit
) {
    var editorOpen by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf("") }
    var draftName by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    fun edit(group: DeviceGroup?) {
        editingId = group?.id.orEmpty()
        draftName = group?.name.orEmpty()
        selectedIds = group?.deviceIds?.toSet().orEmpty()
        editorOpen = true
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Объединяй устройства в удобные группы. Группы сохраняются в этом приложении и не меняют комнаты в «Доме с Алисой».",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
        )
        Button(onClick = { edit(null) }, modifier = Modifier.fillMaxWidth()) { Text("＋ Создать группу") }
        if (groups.isEmpty()) EmptyCard("Пока нет групп. Создай первую и выбери устройства для неё.")
        groups.forEach { group ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(group.name, fontWeight = FontWeight.SemiBold)
                    Text("${group.deviceIds.size} устройств", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { edit(group) }, modifier = Modifier.weight(1f)) { Text("Изменить") }
                        TextButton(onClick = { onDelete(group) }, modifier = Modifier.weight(1f)) { Text("Удалить") }
                    }
                }
            }
        }
    }

    if (editorOpen) {
        AlertDialog(
            onDismissRequest = { editorOpen = false },
            title = { Text(if (editingId.isBlank()) "Новая группа" else "Изменить группу") },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    OutlinedTextField(
                        value = draftName,
                        onValueChange = { draftName = it.take(40) },
                        label = { Text("Название группы") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Устройства", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    if (devices.isEmpty()) Text("Сначала подключи устройства.", fontSize = 12.sp)
                    devices.forEach { device ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = device.id in selectedIds,
                                onCheckedChange = { checked ->
                                    selectedIds = if (checked) selectedIds + device.id else selectedIds - device.id
                                }
                            )
                            Text("${deviceIcon(device.type)}  ${device.name}", fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = draftName.isNotBlank() && selectedIds.isNotEmpty(),
                    onClick = {
                        val id = editingId.ifBlank { java.util.UUID.randomUUID().toString() }
                        onSave(DeviceGroup(id, draftName.trim(), selectedIds.toList()))
                        editorOpen = false
                    }
                ) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { editorOpen = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun DeviceCard(
    device: HomeDevice,
    isBusy: Boolean,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    var sliderValue by remember(device.id, device.brightness) { mutableFloatStateOf((device.brightness ?: device.brightnessMin).toFloat()) }
    val colorCapability = device.colorCapability
    var hue by remember(device.id) { mutableFloatStateOf(210f) }
    var temperature by remember(device.id, colorCapability?.value) {
        mutableFloatStateOf((colorCapability?.value as? Number)?.toFloat() ?: ((colorCapability?.temperatureMin ?: 2700) + (colorCapability?.temperatureMax ?: 6500)) / 2f)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Управление устройством", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                if (device.canToggle && device.onOff != null) Switch(checked = device.onOff, onCheckedChange = onToggle, enabled = !isBusy)
            }
            if (device.canDim && device.brightness != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Яркость", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Spacer(Modifier.weight(1f))
                    Text("${sliderValue.toInt()}%", fontSize = 12.sp)
                }
                val lower = device.brightnessMin.toFloat()
                val upper = device.brightnessMax.toFloat().coerceAtLeast(lower + 1f)
                Box(modifier = Modifier.fillMaxWidth().height(7.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(50))) {
                    Box(modifier = Modifier.fillMaxWidth(((sliderValue - lower) / (upper - lower)).coerceIn(0f, 1f)).height(7.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(50)))
                }
                Slider(value = sliderValue.coerceIn(lower, upper), onValueChange = { sliderValue = it },
                    onValueChangeFinished = { onBrightness(sliderValue.toInt()) }, valueRange = lower..upper, enabled = !isBusy)
            }
            if (colorCapability != null) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(modifier = Modifier.size(44.dp).background(Color.hsv(hue, 0.92f, 1f), CircleShape))
                    Column {
                        Text("Цвет лампы", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Предпросмотр оттенка", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
                if (colorCapability.colorModel == "rgb" || colorCapability.colorModel == "hsv") {
                    Text("Выбери оттенок", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(0f, 25f, 55f, 115f, 175f, 210f, 270f, 325f).forEach { presetHue ->
                            Box(modifier = Modifier.size(29.dp).background(Color.hsv(presetHue, 1f, 1f), CircleShape)
                                .clickable(enabled = !isBusy) { hue = presetHue; onHue(presetHue.toInt()) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Тон", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        Spacer(Modifier.width(8.dp))
                        Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f,
                            onValueChangeFinished = { onHue(hue.toInt()) }, modifier = Modifier.weight(1f), enabled = !isBusy)
                    }
                }
                if (colorCapability.temperatureSupported && colorCapability.temperatureMax > colorCapability.temperatureMin) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Температура света", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Spacer(Modifier.weight(1f))
                        Text("${temperature.toInt()} K", fontSize = 11.sp)
                    }
                    Slider(value = temperature.coerceIn(colorCapability.temperatureMin.toFloat(), colorCapability.temperatureMax.toFloat()),
                        onValueChange = { temperature = it },
                        onValueChangeFinished = { onTemperature(temperature.toInt()) },
                        valueRange = colorCapability.temperatureMin.toFloat()..colorCapability.temperatureMax.toFloat(), enabled = !isBusy)
                }
                if (colorCapability.colorScenes.isNotEmpty()) {
                    Text("Световые эффекты", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        colorCapability.colorScenes.forEach { scene ->
                            FilterChip(selected = colorCapability.instance == "scene" && colorCapability.value == scene,
                                onClick = { onColorScene(scene) }, enabled = !isBusy, label = { Text(sceneLabel(scene), fontSize = 11.sp) })
                        }
                    }
                }
            }
            device.modeCapabilities.forEach { capability ->
                Text(modeInstanceLabel(capability.instance), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    capability.modeOptions.forEach { mode ->
                        FilterChip(
                            selected = capability.value == mode,
                            onClick = { onMode(capability.instance, mode) },
                            enabled = !isBusy,
                            label = { Text(modeLabel(mode), fontSize = 11.sp) }
                        )
                    }
                }
            }
            if (device.properties.isNotEmpty()) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Text("Показатели датчиков", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                device.properties.forEach { property ->
                    SensorVisualization(property = property)
                }
            }
            if (!device.canToggle && !device.canDim && colorCapability == null && device.modeCapabilities.isEmpty() && device.properties.isEmpty()) {
                Text("Устройство доступно для просмотра, но API не предоставил поддерживаемых элементов управления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
        }
    }
}

@Composable
private fun SensorVisualization(property: ru.dislive.yandexhomewidgets.data.HomeProperty) {
    val numeric = (property.value as? Number)?.toFloat()
    val progress = numeric?.let { sensorProgress(property.instance, it) }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sensorIcon(property.instance), fontSize = 19.sp)
                Spacer(Modifier.width(8.dp))
                Text(sensorLabel(property.instance), modifier = Modifier.weight(1f), fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f))
                Text(sensorValue(property.instance, property.value), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            if (progress != null) {
                Box(
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.09f), RoundedCornerShape(50))
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth(progress).height(8.dp)
                            .background(
                                Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.primary)),
                                RoundedCornerShape(50)
                            )
                    )
                }
            } else if (property.value is Boolean || property.value is String) {
                val active = when (property.value) {
                    true -> true
                    false -> false
                    "open", "detected", "motion", "alarm" -> true
                    else -> false
                }
                Text(
                    if (active) "Состояние активно" else "Состояние не активно",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f)
                )
            }
        }
    }
}

private fun sensorProgress(instance: String, value: Float): Float? {
    val fraction = when (instance) {
        "temperature" -> (value + 10f) / 60f
        "humidity", "battery_level" -> value / 100f
        "pressure" -> (value - 900f) / 300f
        "illumination" -> value / 1000f
        "co2_level" -> (value - 400f) / 1600f
        "pm1_density", "pm2.5_density", "pm10_density" -> value / 150f
        "voltage" -> value / 24f
        "power" -> value / 1500f
        else -> return null
    }
    return fraction.coerceIn(0f, 1f)
}

private fun sensorIcon(instance: String): String = when (instance) {
    "temperature" -> "🌡️"
    "humidity" -> "💧"
    "pressure" -> "📈"
    "battery_level" -> "🔋"
    "illumination" -> "☀️"
    "co2_level" -> "🌫️"
    "open" -> "🚪"
    "motion" -> "👁️"
    "water_leak" -> "💦"
    "smoke", "gas" -> "⚠️"
    else -> "◉"
}

@Composable
private fun ScenariosScreen(scenarios: List<HomeScenario>, isBusy: Boolean, onRun: (HomeScenario) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Запускай созданные в приложении «Дом с Алисой» сценарии.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        if (scenarios.isEmpty()) EmptyCard("Сценарии не найдены.")
        scenarios.forEach { scenario ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(scenario.name, fontWeight = FontWeight.Medium)
                        Text(if (scenario.isActive) "Активен" else "Сценарий", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), fontSize = 11.sp)
                    }
                    Button(onClick = { onRun(scenario) }, enabled = !isBusy) { Text("Запустить") }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(history: List<HomeChange>, onClear: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Последние изменения", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            TextButton(onClick = onClear, enabled = history.isNotEmpty()) { Text("Очистить") }
        }
        if (history.isEmpty()) {
            EmptyCard("История пока пуста. Она начнёт заполняться после обнаружения изменений в доме.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { "${it.timestamp}-${it.kind}-${it.title}-${it.detail}" }) { change ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(change.title, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            Text(change.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                            Text(SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()).format(Date(change.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    isDarkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit,
    options: HomeNotificationOptions,
    onNotificationChange: (HomeNotificationOptions) -> Unit,
    updateMessage: String,
    updateInfo: AppUpdateInfo?,
    isCheckingUpdate: Boolean,
    onCheckUpdates: () -> Unit,
    onDisconnect: () -> Unit,
    onNotificationPermission: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Оформление", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Тёмная тема", isDarkTheme, onThemeChange)
                Text(if (isDarkTheme) "Используется тёмное оформление." else "Используется светлое оформление.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Уведомления", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Все уведомления", options.enabled) { onNotificationChange(options.copy(enabled = it)) }
                if (options.enabled) {
                    Divider()
                    SettingSwitch("Устройства, комнаты и структура дома", options.deviceChanges) { onNotificationChange(options.copy(deviceChanges = it)) }
                    SettingSwitch("Изменения состояний устройств", options.capabilityChanges) { onNotificationChange(options.copy(capabilityChanges = it)) }
                    SettingSwitch("Датчики и показатели", options.sensorChanges) { onNotificationChange(options.copy(sensorChanges = it)) }
                    SettingSwitch("Группы и сценарии", options.groupScenarioChanges) { onNotificationChange(options.copy(groupScenarioChanges = it)) }
                }
                Text("Фоновая проверка выполняется примерно раз в 15 минут. Android может задерживать её; это не мгновенные push-уведомления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                OutlinedButton(onClick = onNotificationPermission, modifier = Modifier.fillMaxWidth()) { Text("Разрешения уведомлений Android") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Обновление приложения", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Установленная версия: ${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Text(updateMessage, fontSize = 12.sp)
                if (!updateInfo?.notes.isNullOrBlank()) Text(updateInfo?.notes.orEmpty(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Button(onClick = onCheckUpdates, enabled = !isCheckingUpdate, modifier = Modifier.fillMaxWidth()) {
                    if (isCheckingUpdate) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Проверить обновления")
                }
                if (updateInfo != null) {
                    Button(onClick = { openUrl(context, updateInfo.apkUrl ?: updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Скачать обновление ${updateInfo.version}") }
                    TextButton(onClick = { openUrl(context, updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Описание версии на GitHub") }
                }
                Text("Обновление загружается с GitHub Releases. После скачивания Android попросит подтвердить установку.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
        }
        OutlinedButton(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) { Text("Отключить Яндекс") }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Text(message, modifier = Modifier.fillMaxWidth().padding(16.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}

private fun sensorLabel(instance: String): String = when (instance) {
    "temperature" -> "Температура"
    "humidity" -> "Влажность"
    "pressure" -> "Давление"
    "battery_level" -> "Заряд батареи"
    "voltage" -> "Напряжение"
    "current" -> "Ток"
    "power" -> "Мощность"
    "illumination" -> "Освещённость"
    "co2_level" -> "Уровень CO₂"
    "pm1_density" -> "PM1"
    "pm2.5_density" -> "PM2.5"
    "pm10_density" -> "PM10"
    "open" -> "Открытие"
    "motion" -> "Движение"
    "vibration" -> "Вибрация"
    "water_leak" -> "Протечка"
    "smoke" -> "Дым"
    "gas" -> "Газ"
    else -> instance.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun sensorValue(instance: String, value: Any?): String {
    val raw = when (value) {
        null -> "Нет данных"
        is Boolean -> if (value) "Да" else "Нет"
        else -> value.toString()
    }
    val unit = when (instance) {
        "temperature" -> " °C"
        "humidity", "battery_level" -> "%"
        "pressure" -> " гПа"
        "illumination" -> " лк"
        "co2_level" -> " ppm"
        "voltage" -> " В"
        "current" -> " А"
        "power" -> " Вт"
        else -> ""
    }
    return when (raw.lowercase()) {
        "open" -> "Открыто"
        "closed" -> "Закрыто"
        "detected" -> "Обнаружено"
        "not_detected" -> "Не обнаружено"
        else -> raw + unit
    }
}

private fun sceneLabel(id: String): String = when (id) {
    "alarm" -> "Тревога"
    "alice" -> "Алиса"
    "candle" -> "Свеча"
    "dinner" -> "Ужин"
    "fantasy" -> "Фантазия"
    "garland" -> "Гирлянда"
    "jungle" -> "Джунгли"
    "movie" -> "Кино"
    "neon" -> "Неон"
    "night" -> "Ночь"
    "ocean" -> "Океан"
    "party" -> "Вечеринка"
    "reading" -> "Чтение"
    "rest" -> "Отдых"
    "romance" -> "Романтика"
    "siren" -> "Сирена"
    else -> id
}

private fun modeInstanceLabel(instance: String): String = when (instance) {
    "thermostat" -> "Режим термостата"
    "cleanup_mode" -> "Режим уборки"
    "fan_speed" -> "Скорость вентилятора"
    else -> "Режим: $instance"
}

private fun modeLabel(value: String): String = when (value) {
    "auto" -> "Авто"
    "heat" -> "Обогрев"
    "cool" -> "Охлаждение"
    "dry" -> "Осушение"
    "fan_only" -> "Вентиляция"
    "on" -> "Вкл."
    "off" -> "Выкл."
    "high" -> "Высокая"
    "medium" -> "Средняя"
    "low" -> "Низкая"
    "turbo" -> "Турбо"
    "eco" -> "Эко"
    else -> value.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
