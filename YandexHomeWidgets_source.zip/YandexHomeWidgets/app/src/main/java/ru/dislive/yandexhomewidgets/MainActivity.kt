package ru.dislive.yandexhomewidgets

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import ru.dislive.yandexhomewidgets.data.AppUpdateChecker
import ru.dislive.yandexhomewidgets.data.AppUpdateInfo
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.HomeSnapshotStore
import ru.dislive.yandexhomewidgets.data.HomeChange
import ru.dislive.yandexhomewidgets.data.HomeChangeDetector
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.DeviceGroup
import ru.dislive.yandexhomewidgets.data.DeviceGroupStore
import ru.dislive.yandexhomewidgets.data.HomeGroup
import ru.dislive.yandexhomewidgets.data.HomeHistoryStore
import ru.dislive.yandexhomewidgets.data.SensorHistoryStore
import ru.dislive.yandexhomewidgets.data.HomeNotificationCenter
import ru.dislive.yandexhomewidgets.data.HomeNotificationOptions
import ru.dislive.yandexhomewidgets.data.HomeNotificationSettings
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.LocalAutomation
import ru.dislive.yandexhomewidgets.data.GlobalVariable
import ru.dislive.yandexhomewidgets.data.LocalAutomationStore
import ru.dislive.yandexhomewidgets.data.LocalAutomationEngine
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi
import ru.dislive.yandexhomewidgets.data.YandexOAuth
import ru.dislive.yandexhomewidgets.widget.HomeWidget
import ru.dislive.yandexhomewidgets.widget.ScenarioWidget
import ru.dislive.yandexhomewidgets.widget.WorkScheduler
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class AppPage { HOME, SCENARIOS, HISTORY, ANALYTICS, SETTINGS, DEVICE, GROUPS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkScheduler.schedule(this)
        HomeNotificationCenter.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4107)
        }
        setContent { YandexHomeApp() }
    }
}

@Composable
private fun YandexHomeApp() {
    val context = LocalContext.current
    val config = remember { context.getSharedPreferences("app_config", Context.MODE_PRIVATE) }
    val tokenStore = remember { TokenStore(context.applicationContext) }
    val cachedHome = remember { HomeSnapshotStore.load(context.applicationContext) }
    val scope = rememberCoroutineScope()

    var clientId by remember { mutableStateOf(config.getString("client_id", "").orEmpty()) }
    var redirectInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(clientId.isNotBlank()) }
    var isBusy by remember { mutableStateOf(false) }
    var isSyncing by remember { mutableStateOf(clientId.isNotBlank()) }
    var refreshRequested by remember { mutableStateOf(false) }
    var pendingDeviceIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var status by remember { mutableStateOf("Сначала подключи Яндекс OAuth") }
    var error by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf(cachedHome?.devices.orEmpty().map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }) }
    var scenarios by remember { mutableStateOf(cachedHome?.scenarios.orEmpty()) }
    var localAutomations by remember { mutableStateOf(LocalAutomationStore.loadAutomations(context)) }
    var globalVariables by remember { mutableStateOf(LocalAutomationStore.loadVariables(context)) }
    var groups by remember { mutableStateOf(cachedHome?.groups.orEmpty()) }
    var customGroups by remember { mutableStateOf(DeviceGroupStore.load(context)) }
    var selectedDeviceId by remember { mutableStateOf<String?>(null) }
    var roomNames by remember { mutableStateOf(cachedHome?.rooms.orEmpty()) }
    var notificationOptions by remember { mutableStateOf(HomeNotificationSettings.load(context)) }
    var history by remember { mutableStateOf(HomeHistoryStore.load(context)) }
    var page by remember { mutableStateOf(AppPage.HOME) }
    var isDarkTheme by remember { mutableStateOf(config.getBoolean("dark_theme", true)) }
    var isCheckingUpdate by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<AppUpdateInfo?>(null) }
    var updateMessage by remember { mutableStateOf("Нажми «Проверить обновления», чтобы проверить новую версию.") }

    suspend fun reloadHome(showLoading: Boolean = true) {
        if (isSyncing) {
            if (!showLoading) refreshRequested = true
            return
        }
        isSyncing = true
        if (showLoading) isBusy = true
        error = ""
        try {
            val token = tokenStore.getValidAccessToken()
            if (token.isNullOrBlank()) {
                // Keep the last-known dashboard visible; authentication can be repaired from Settings.
                isConnected = devices.isNotEmpty() || cachedHome != null
                status = if (isConnected) "Нет активной сессии · показаны сохранённые данные" else "Яндекс не подключён"
                return
            }
            val api = YandexHomeApi(token)
            val home = api.getHome()
            val changes = HomeChangeDetector.collect(context, home)
            HomeNotificationCenter.showChanges(context, changes)
            SensorHistoryStore.record(context, home.devices)
            LocalAutomationEngine.evaluate(context, api, home)
            localAutomations = LocalAutomationStore.loadAutomations(context)
            globalVariables = LocalAutomationStore.loadVariables(context)
            devices = home.devices.map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }
            scenarios = home.scenarios
            groups = home.groups
            roomNames = home.rooms
            HomeCache.saveHome(context, home)
            HomeSnapshotStore.save(context, home)
            history = HomeHistoryStore.load(context)
            isConnected = true
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            status = "Обновлено $time · ${devices.size} устройств · автообновление 60 с"
            HomeWidget().updateAll(context)
            ScenarioWidget().updateAll(context)
        } catch (e: Exception) {
            error = e.message ?: "Не удалось загрузить умный дом"
            status = "Нет связи · показаны последние данные"
            if (devices.isNotEmpty()) isConnected = true
        } finally {
            isSyncing = false
            if (showLoading) isBusy = false
            if (refreshRequested) {
                refreshRequested = false
                scope.launch { delay(350); reloadHome(showLoading = false) }
            }
        }
    }

    fun performDeviceAction(action: suspend (YandexHomeApi) -> Unit) {
        scope.launch {
            isBusy = true
            error = ""
            try {
                val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                action(YandexHomeApi(token))
                reloadHome(showLoading = false)
            } catch (e: Exception) {
                error = e.message ?: "Не удалось выполнить команду"
            } finally {
                isBusy = false
            }
        }
    }

    fun performOnOff(deviceIds: List<String>, value: Boolean) {
        val ids = deviceIds.distinct().filter { id -> devices.any { it.id == id && it.canToggle } }
        if (ids.isEmpty() || ids.any { it in pendingDeviceIds }) return
        // Optimistic UI: the tile responds instantly while the network request runs.
        devices = devices.map { if (it.id in ids) it.copy(onOff = value) else it }
        pendingDeviceIds = pendingDeviceIds + ids
        scope.launch {
            var succeeded = false
            try {
                val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                YandexHomeApi(token).setOnOffBulk(ids, value)
                succeeded = true
            } catch (e: Exception) {
                error = e.message ?: "Не удалось изменить состояние группы"
                reloadHome(showLoading = false)
            } finally {
                pendingDeviceIds = pendingDeviceIds - ids.toSet()
            }
            if (succeeded) {
                delay(500)
                reloadHome(showLoading = false)
            }
        }
    }

    fun checkUpdates() {
        scope.launch {
            isCheckingUpdate = true
            updateMessage = "Проверяю GitHub Releases…"
            updateInfo = null
            try {
                val found = AppUpdateChecker.check(BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)
                updateInfo = found
                updateMessage = if (found == null) "Установлена последняя доступная версия (${BuildConfig.VERSION_NAME})." else "Доступна версия ${found.version} (сборка ${found.buildCode})."
            } catch (e: Exception) {
                updateMessage = e.message ?: "Не удалось проверить обновления. Проверь подключение к интернету."
            } finally {
                isCheckingUpdate = false
            }
        }
    }

    LaunchedEffect(Unit) {
        // With saved API settings the dashboard and its loading indicator are visible
        // on the very first frame. Start the request without replacing that screen.
        if (clientId.isNotBlank()) {
            isSyncing = false
            reloadHome(showLoading = false)
        }
    }

    // Visible-screen polling only. A minute is frequent enough for status awareness
    // without repeatedly refreshing every device while the user is elsewhere.
    LaunchedEffect(isConnected, page) {
        if (isConnected && page in setOf(AppPage.HOME, AppPage.SCENARIOS, AppPage.DEVICE, AppPage.ANALYTICS)) {
            while (true) {
                delay(60_000)
                if (!isBusy && !isSyncing) reloadHome(showLoading = false)
            }
        }
    }

    val colors = if (isDarkTheme) darkColorScheme(
        primary = Color(0xFFC4A5FF), onPrimary = Color(0xFF24143F),
        secondary = Color(0xFF8B5CF6), background = Color(0xFF100B1C),
        surface = Color(0xFF1D1630), onSurface = Color(0xFFF5F0FF),
        onBackground = Color(0xFFF5F0FF)
    ) else lightColorScheme(
        primary = Color(0xFF7546C8), onPrimary = Color.White,
        secondary = Color(0xFF9A6AE8), background = Color(0xFFF7F3FF),
        surface = Color.White, onSurface = Color(0xFF251B36),
        onBackground = Color(0xFF251B36)
    )

    MaterialTheme(colorScheme = colors) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            when (page) {
                                AppPage.HOME -> "Яндекс Дом"
                                AppPage.SCENARIOS -> "Сценарии"
                                AppPage.HISTORY -> "История изменений"
                                AppPage.ANALYTICS -> "Аналитика датчиков"
                                AppPage.SETTINGS -> "Настройки"
                                AppPage.DEVICE -> devices.firstOrNull { it.id == selectedDeviceId }?.name ?: "Устройство"
                                AppPage.GROUPS -> "Настройка групп"
                            }, fontSize = 25.sp, fontWeight = FontWeight.Bold
                        )
                        if (isSyncing) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(11.dp), strokeWidth = 1.7.dp)
                                Text(if (devices.isEmpty()) "Загрузка устройств…" else "Обновление состояния…", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                            }
                        } else {
                            Text(status, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (page == AppPage.HOME || page == AppPage.SCENARIOS) {
                        TextButton(onClick = { page = AppPage.SETTINGS }) { Text("⚙") }
                    } else {
                        TextButton(onClick = { page = AppPage.HOME; selectedDeviceId = null }) { Text("← Назад") }
                    }
                }
                if (isSyncing) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    )
                } else {
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                }

                Box(modifier = Modifier.weight(1f)) {
                    if (!isConnected && page != AppPage.SETTINGS) {
                        ConnectionScreen(
                            clientId = clientId,
                            onClientIdChange = {
                                clientId = it
                                config.edit().putString("client_id", it.trim()).apply()
                            },
                            redirectInput = redirectInput,
                            onRedirectChange = { redirectInput = it },
                            isBusy = isBusy,
                            error = error,
                            onOpenOAuth = {
                                try {
                                    val url = YandexOAuth.authorizationUrl(clientId, tokenStore)
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    status = "Подтверди доступ на странице Яндекса, затем вернись сюда"
                                } catch (e: Exception) { error = e.message ?: "Не удалось открыть авторизацию" }
                            },
                            onConnect = {
                                scope.launch {
                                    isBusy = true
                                    error = ""
                                    try {
                                        val response = YandexOAuth.exchangeRedirect(redirectInput, clientId, tokenStore)
                                        tokenStore.saveTokens(response)
                                        redirectInput = ""
                                        status = "Токен получен. Загружаю устройства…"
                                        reloadHome()
                                    } catch (e: Exception) {
                                        error = e.message ?: "Не удалось завершить подключение"
                                        isBusy = false
                                    }
                                }
                            }
                        )
                    } else {
                        when (page) {
                            AppPage.HOME -> HomeScreen(
                                devices = devices,
                                customGroups = customGroups,
                                rooms = roomNames,
                                isBusy = isBusy,
                                isLoading = isSyncing,
                                pendingDeviceIds = pendingDeviceIds,
                                onRefresh = { if (!isBusy && !isSyncing) scope.launch { reloadHome() } },
                                onHistory = { history = HomeHistoryStore.load(context); page = AppPage.HISTORY },
                                onAnalytics = { page = AppPage.ANALYTICS },
                                onOpenGroups = { page = AppPage.GROUPS },
                                onOpenDevice = { selectedDeviceId = it.id; page = AppPage.DEVICE },
                                onToggle = { device, value -> if (!isBusy) performOnOff(listOf(device.id), value) },
                                onToggleGroup = { members, value -> if (!isBusy) performOnOff(members.map { it.id }, value) }
                            )
                            AppPage.DEVICE -> {
                                val device = devices.firstOrNull { it.id == selectedDeviceId }
                                if (device == null) EmptyCard("Устройство больше не найдено. Обнови список устройств.")
                                else DeviceDetailsScreen(
                                    device = device,
                                    isBusy = isBusy,
                                    onFavorite = { favorite ->
                                        HomeCache.setFavorite(context, device.id, favorite)
                                        devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                        scope.launch { HomeWidget().updateAll(context) }
                                    },
                                    onToggle = { value -> if (!isBusy) performOnOff(listOf(device.id), value) },
                                    onBrightness = { value -> if (!isBusy) performDeviceAction { it.setBrightness(device.id, value) } },
                                    onHue = { hue -> if (!isBusy) performDeviceAction {
                                        val cap = device.colorCapability
                                        if (cap?.colorModel == "hsv") it.setColorHsv(device.id, hue)
                                        else it.setColorRgb(device.id, android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 1f, 1f)) and 0x00FFFFFF)
                                    } },
                                    onTemperature = { value -> if (!isBusy) performDeviceAction { it.setColorTemperature(device.id, value) } },
                                    onColorScene = { value -> if (!isBusy) performDeviceAction { it.setColorScene(device.id, value) } },
                                    onMode = { instance, value -> if (!isBusy) performDeviceAction { it.setMode(device.id, instance, value) } }
                                )
                            }
                            AppPage.ANALYTICS -> SensorAnalyticsScreen(devices = devices)
                            AppPage.GROUPS -> GroupsScreen(
                                groups = customGroups,
                                devices = devices,
                                onSave = { group ->
                                    val claimed = group.deviceIds.toSet()
                                    customGroups = (
                                        customGroups.filterNot { it.id == group.id }
                                            .map { old -> old.copy(deviceIds = old.deviceIds.filterNot { it in claimed }) }
                                            .filter { it.deviceIds.isNotEmpty() } + group
                                    ).sortedBy { it.name.lowercase() }
                                    DeviceGroupStore.save(context, customGroups)
                                },
                                onDelete = { group ->
                                    customGroups = customGroups.filterNot { it.id == group.id }
                                    DeviceGroupStore.save(context, customGroups)
                                }
                            )
                            AppPage.SCENARIOS -> ScenarioCenterScreen(
                                devices = devices,
                                cloudScenarios = scenarios,
                                automations = localAutomations,
                                variables = globalVariables,
                                isBusy = isBusy,
                                onSaveAutomation = { automation ->
                                    LocalAutomationStore.saveAutomation(context, automation)
                                    localAutomations = LocalAutomationStore.loadAutomations(context)
                                    scope.launch { ScenarioWidget().updateAll(context) }
                                },
                                onDeleteAutomation = { id ->
                                    LocalAutomationStore.deleteAutomation(context, id)
                                    localAutomations = LocalAutomationStore.loadAutomations(context)
                                    scope.launch { ScenarioWidget().updateAll(context) }
                                },
                                onToggleAutomation = { id, enabled ->
                                    LocalAutomationStore.setAutomationEnabled(context, id, enabled)
                                    localAutomations = LocalAutomationStore.loadAutomations(context)
                                    scope.launch { ScenarioWidget().updateAll(context) }
                                },
                                onRunAutomation = { id ->
                                    scope.launch {
                                        isBusy = true
                                        error = ""
                                        try {
                                            val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                                            val api = YandexHomeApi(token)
                                            val home = api.getHome()
                                            LocalAutomationEngine.runManually(context, api, home, id)
                                            globalVariables = LocalAutomationStore.loadVariables(context)
                                            reloadHome(showLoading = false)
                                        } catch (e: Exception) {
                                            error = e.message ?: "Не удалось запустить автоматизацию"
                                        } finally {
                                            isBusy = false
                                        }
                                    }
                                },
                                onSaveVariable = { variable ->
                                    LocalAutomationStore.saveVariable(context, variable)
                                    globalVariables = LocalAutomationStore.loadVariables(context)
                                },
                                onDeleteVariable = { name ->
                                    LocalAutomationStore.deleteVariable(context, name)
                                    globalVariables = LocalAutomationStore.loadVariables(context)
                                },
                                onRunCloudScenario = { scenario -> if (!isBusy) performDeviceAction { it.runScenario(scenario.id) } }
                            )
                            AppPage.HISTORY -> HistoryScreen(
                                history = history,
                                onClear = { HomeHistoryStore.clear(context); history = emptyList() }
                            )
                            AppPage.SETTINGS -> SettingsScreen(
                                isDarkTheme = isDarkTheme,
                                onThemeChange = {
                                    isDarkTheme = it
                                    config.edit().putBoolean("dark_theme", it).apply()
                                },
                                options = notificationOptions,
                                onNotificationChange = {
                                    notificationOptions = it
                                    HomeNotificationSettings.save(context, it)
                                },
                                updateMessage = updateMessage,
                                updateInfo = updateInfo,
                                isCheckingUpdate = isCheckingUpdate,
                                onCheckUpdates = ::checkUpdates,
                                onDisconnect = {
                                    tokenStore.clear()
                                    HomeCache.clear(context)
                                    context.getSharedPreferences("home_snapshot", Context.MODE_PRIVATE).edit().clear().apply()
                                    devices = emptyList()
                                    scenarios = emptyList()
                                    groups = emptyList()
                                    roomNames = emptyList()
                                    isConnected = false
                                    page = AppPage.HOME
                                    status = "Яндекс отключён"
                                    error = ""
                                    scope.launch { HomeWidget().updateAll(context) }
                                },
                                onNotificationPermission = {
                                    if (Build.VERSION.SDK_INT >= 33) {
                                        context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                                    }
                                }
                            )
                        }
                    }
                }

                if (error.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(error, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                    }
                }
                if (isConnected && page in setOf(AppPage.HOME, AppPage.SCENARIOS, AppPage.DEVICE, AppPage.ANALYTICS)) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = page == AppPage.HOME,
                            onClick = { page = AppPage.HOME },
                            icon = { SmartGlyph("home", Modifier.size(22.dp), if (page == AppPage.HOME) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f)) }, label = { Text("Главная") }
                        )
                        NavigationBarItem(
                            selected = page == AppPage.SCENARIOS,
                            onClick = { page = AppPage.SCENARIOS },
                            icon = { SmartGlyph("sparkles", Modifier.size(22.dp), if (page == AppPage.SCENARIOS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f)) }, label = { Text("Сценарии") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionScreen(
    clientId: String,
    onClientIdChange: (String) -> Unit,
    redirectInput: String,
    onRedirectChange: (String) -> Unit,
    isBusy: Boolean,
    error: String,
    onOpenOAuth: () -> Unit,
    onConnect: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Подключение к Яндексу", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Создай приложение в Яндекс OAuth типа «Для доступа к API или отладки». Выдай разрешения iot:view и iot:control. В Redirect URI укажи https://oauth.yandex.ru/verification_code.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), fontSize = 13.sp
                )
                TextButton(onClick = { openUrl(context, "https://oauth.yandex.ru/client/new/") }) { Text("Открыть Яндекс OAuth") }
                OutlinedTextField(value = clientId, onValueChange = onClientIdChange, modifier = Modifier.fillMaxWidth(), label = { Text("Client ID") }, singleLine = true)
                Button(onClick = onOpenOAuth, enabled = clientId.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) { Text("Открыть страницу подтверждения") }
                Divider()
                Text("После подтверждения скопируй полный адрес из адресной строки браузера и вставь ниже. Пароль и Client Secret сюда вводить не нужно.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                OutlinedTextField(value = redirectInput, onValueChange = onRedirectChange, modifier = Modifier.fillMaxWidth(), label = { Text("Полный адрес после подтверждения") }, minLines = 2)
                Button(onClick = onConnect, enabled = clientId.isNotBlank() && redirectInput.isNotBlank() && !isBusy, modifier = Modifier.fillMaxWidth()) {
                    if (isBusy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Подключить")
                }
                Text("OAuth PKCE. Токены хранятся зашифрованными через Android Keystore.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun DashboardMetric(kind: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        SmartGlyph(kind, Modifier.size(16.dp), Color.White.copy(alpha = 0.92f))
        Text(value, color = Color.White.copy(alpha = 0.94f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HomeScreen(
    devices: List<HomeDevice>,
    customGroups: List<DeviceGroup>,
    rooms: List<String>,
    isBusy: Boolean,
    isLoading: Boolean,
    pendingDeviceIds: Set<String>,
    onRefresh: () -> Unit,
    onHistory: () -> Unit,
    onAnalytics: () -> Unit,
    onOpenGroups: () -> Unit,
    onOpenDevice: (HomeDevice) -> Unit,
    onToggle: (HomeDevice, Boolean) -> Unit,
    onToggleGroup: (List<HomeDevice>, Boolean) -> Unit
) {
    val groupedIds = remember(customGroups) { customGroups.flatMap { it.deviceIds }.toSet() }
    val ungrouped = remember(devices, groupedIds) { devices.filterNot { it.id in groupedIds } }
    val ungroupedByRoom = remember(ungrouped) { ungrouped.groupBy { it.room.ifBlank { "Без комнаты" } } }
    val allRooms = remember(rooms, ungroupedByRoom) {
        (rooms.filter { ungroupedByRoom.containsKey(it) } + ungroupedByRoom.keys).distinct()
    }
    val activeCount = devices.count { it.onOff == true }
    val temperature = devices.flatMap { device -> device.properties.filter { it.instance == "temperature" }.mapNotNull { (it.value as? Number)?.toDouble() } }.takeIf { it.isNotEmpty() }?.average()
    val humidity = devices.flatMap { device -> device.properties.filter { it.instance == "humidity" }.mapNotNull { (it.value as? Number)?.toDouble() } }.takeIf { it.isNotEmpty() }?.average()
    val currentPower = devices.flatMap { device -> device.properties.filter { it.instance == "power" }.mapNotNull { (it.value as? Number)?.toDouble() } }.takeIf { it.isNotEmpty() }?.sum()

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 154.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }, key = "dashboard_summary") {
            Box(
                modifier = Modifier.fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF3B176E), Color(0xFF7545C5), Color(0xFF34205D))),
                        RoundedCornerShape(24.dp)
                    ).padding(17.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Панель дома", color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp)
                            Text("Всё под контролем", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(modifier = Modifier.size(42.dp).background(Color.White.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
                            SmartGlyph("home", Modifier.size(27.dp), Color.White)
                        }
                    }
                    Text("$activeCount из ${devices.size} устройств включено", color = Color.White, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (temperature != null) DashboardMetric("temperature", "${"%.1f".format(Locale.getDefault(), temperature)} °C")
                        if (humidity != null) DashboardMetric("humidity", "${"%.0f".format(Locale.getDefault(), humidity)}%")
                        if (currentPower != null) DashboardMetric("power", "${"%.0f".format(Locale.getDefault(), currentPower)} Вт")
                        if (temperature == null && humidity == null && currentPower == null) Text("Состояния обновляются автоматически", color = Color.White.copy(alpha = 0.84f), fontSize = 11.sp)
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }, key = "home_actions") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = onAnalytics, modifier = Modifier.weight(1f)) { Text("Аналитика", fontSize = 11.sp) }
                OutlinedButton(onClick = onHistory, modifier = Modifier.weight(1f)) { Text("История", fontSize = 11.sp) }
                OutlinedButton(onClick = onOpenGroups, modifier = Modifier.weight(1f)) { Text("Группы", fontSize = 11.sp) }
                Button(onClick = onRefresh, enabled = !isBusy, modifier = Modifier.weight(1f)) {
                    if (isBusy) CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp) else Text("↻", fontSize = 18.sp)
                }
            }
        }
        if (devices.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }, key = "empty_devices") {
                if (isLoading) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("Загружаем дом", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Главная уже открыта. Устройства появятся здесь после ответа API.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f))
                            }
                        }
                    }
                } else {
                    EmptyCard("Устройства не найдены. Проверь, что они добавлены в Дом с Алисой.")
                }
            }
        } else {
            customGroups.forEach { group ->
                val members = devices.filter { it.id in group.deviceIds }
                if (members.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "group_${group.id}") {
                        GroupGridHeader(
                            title = group.name,
                            members = members,
                            pending = pendingDeviceIds,
                            onToggleGroup = onToggleGroup
                        )
                    }
                    gridItems(members, key = { "device_${it.id}" }) { device ->
                        CompactDeviceTile(
                            device = device,
                            enabled = !isBusy && device.id !in pendingDeviceIds,
                            pending = device.id in pendingDeviceIds,
                            onOpen = { onOpenDevice(device) },
                            onToggle = { onToggle(device, it) }
                        )
                    }
                }
            }
            allRooms.forEach { roomName ->
                val roomDevices = ungroupedByRoom[roomName].orEmpty()
                if (roomDevices.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, key = "room_$roomName") {
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(roomName, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${roomDevices.size}", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.48f), fontSize = 11.sp)
                        }
                    }
                    gridItems(roomDevices, key = { "device_${it.id}" }) { device ->
                        CompactDeviceTile(
                            device = device,
                            enabled = !isBusy && device.id !in pendingDeviceIds,
                            pending = device.id in pendingDeviceIds,
                            onOpen = { onOpenDevice(device) },
                            onToggle = { onToggle(device, it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupGridHeader(
    title: String,
    members: List<HomeDevice>,
    pending: Set<String>,
    onToggleGroup: (List<HomeDevice>, Boolean) -> Unit
) {
    val switchable = members.filter { it.canToggle }
    val allOn = switchable.isNotEmpty() && switchable.all { it.onOff == true }
    val hasPending = switchable.any { it.id in pending }
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 7.dp)
            .background(Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f))), RoundedCornerShape(17.dp))
            .padding(start = 13.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("${members.size} устройств · ${switchable.count { it.onOff == true }} включено", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
        }
        OutlinedButton(
            onClick = { onToggleGroup(switchable, !allOn) },
            enabled = switchable.isNotEmpty() && !hasPending,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 5.dp)
        ) {
            Text(if (hasPending) "…" else if (allOn) "Выключить все" else "Включить все", fontSize = 10.sp)
        }
    }
}

@Composable
private fun CompactDeviceTile(
    device: HomeDevice,
    enabled: Boolean,
    pending: Boolean,
    onOpen: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    val on = device.onOff == true
    val tileBrush = if (on) {
        Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.17f), MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f)))
    } else {
        Brush.linearGradient(listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f)))
    }
    Box(
        modifier = Modifier.fillMaxWidth().background(tileBrush, RoundedCornerShape(21.dp))
            .clickable(onClick = onOpen).padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(deviceIconKind(device.type, device.name), Modifier.size(42.dp), iconSize = 25.dp, active = on)
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { onToggle(!on) },
                    enabled = enabled && device.canToggle,
                    modifier = Modifier.size(36.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                ) {
                    if (pending) CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp)
                    else SmartGlyph(if (on) "off" else "power", Modifier.size(19.dp), if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(device.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    when {
                        pending && on -> "Включение…"
                        pending && !on -> "Выключение…"
                        device.onOff == true -> "Включено"
                        device.onOff == false -> "Выключено"
                        else -> device.room.ifBlank { "Только просмотр" }
                    },
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f),
                    maxLines = 1
                )
            }
        }
    }
}

private fun deviceIcon(type: String): String = deviceIconKind(type)

@Composable
private fun DeviceDetailsScreen(
    device: HomeDevice,
    isBusy: Boolean,
    onFavorite: (Boolean) -> Unit,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "device_intro") {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    IconTile(deviceIconKind(device.type, device.name), Modifier.size(62.dp), iconSize = 38.dp, active = device.onOff == true)
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(device.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(device.room.ifBlank { "Без комнаты" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Text(device.type.removePrefix("devices.types.").replace('.', ' '), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.52f))
                    }
                    TextButton(onClick = { onFavorite(!device.isFavorite) }) {
                        Text(if (device.isFavorite) "★" else "☆", fontSize = 22.sp)
                    }
                }
            }
        }
        item(key = "device_controls") {
            DeviceCard(
                device = device,
                isBusy = isBusy,
                onToggle = onToggle,
                onBrightness = onBrightness,
                onHue = onHue,
                onTemperature = onTemperature,
                onColorScene = onColorScene,
                onMode = onMode
            )
        }
    }
}

@Composable
private fun GroupsScreen(
    groups: List<DeviceGroup>,
    devices: List<HomeDevice>,
    onSave: (DeviceGroup) -> Unit,
    onDelete: (DeviceGroup) -> Unit
) {
    var editorOpen by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf("") }
    var draftName by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    fun edit(group: DeviceGroup?) {
        editingId = group?.id.orEmpty()
        draftName = group?.name.orEmpty()
        selectedIds = group?.deviceIds?.toSet().orEmpty()
        editorOpen = true
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Объединяй устройства в удобные группы. Группы сохраняются в этом приложении и не меняют комнаты в «Доме с Алисой».",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
        )
        Button(onClick = { edit(null) }, modifier = Modifier.fillMaxWidth()) { Text("＋ Создать группу") }
        if (groups.isEmpty()) EmptyCard("Пока нет групп. Создай первую и выбери устройства для неё.")
        groups.forEach { group ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(group.name, fontWeight = FontWeight.SemiBold)
                    Text("${group.deviceIds.size} устройств", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { edit(group) }, modifier = Modifier.weight(1f)) { Text("Изменить") }
                        TextButton(onClick = { onDelete(group) }, modifier = Modifier.weight(1f)) { Text("Удалить") }
                    }
                }
            }
        }
    }

    if (editorOpen) {
        AlertDialog(
            onDismissRequest = { editorOpen = false },
            title = { Text(if (editingId.isBlank()) "Новая группа" else "Изменить группу") },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    OutlinedTextField(
                        value = draftName,
                        onValueChange = { draftName = it.take(40) },
                        label = { Text("Название группы") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Устройства", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    if (devices.isEmpty()) Text("Сначала подключи устройства.", fontSize = 12.sp)
                    devices.forEach { device ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = device.id in selectedIds,
                                onCheckedChange = { checked ->
                                    selectedIds = if (checked) selectedIds + device.id else selectedIds - device.id
                                }
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                SmartGlyph(deviceIconKind(device.type, device.name), Modifier.size(20.dp), MaterialTheme.colorScheme.primary)
                                Text(device.name, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = draftName.isNotBlank() && selectedIds.isNotEmpty(),
                    onClick = {
                        val id = editingId.ifBlank { java.util.UUID.randomUUID().toString() }
                        onSave(DeviceGroup(id, draftName.trim(), selectedIds.toList()))
                        editorOpen = false
                    }
                ) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { editorOpen = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun DeviceCard(
    device: HomeDevice,
    isBusy: Boolean,
    onToggle: (Boolean) -> Unit,
    onBrightness: (Int) -> Unit,
    onHue: (Int) -> Unit,
    onTemperature: (Int) -> Unit,
    onColorScene: (String) -> Unit,
    onMode: (String, String) -> Unit
) {
    var sliderValue by remember(device.id, device.brightness) { mutableFloatStateOf((device.brightness ?: device.brightnessMin).toFloat()) }
    val colorCapability = device.colorCapability
    var hue by remember(device.id) { mutableFloatStateOf(210f) }
    var temperature by remember(device.id, colorCapability?.value) {
        mutableFloatStateOf((colorCapability?.value as? Number)?.toFloat() ?: ((colorCapability?.temperatureMin ?: 2700) + (colorCapability?.temperatureMax ?: 6500)) / 2f)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Управление устройством", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                if (device.canToggle) {
                    Button(onClick = { onToggle(device.onOff != true) }, enabled = !isBusy) {
                        Text(if (device.onOff == true) "Выключить" else "Включить", fontSize = 12.sp)
                    }
                }
            }
            if (device.canDim && device.brightness != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Яркость", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Spacer(Modifier.weight(1f))
                    Text("${sliderValue.toInt()}%", fontSize = 12.sp)
                }
                val lower = device.brightnessMin.toFloat()
                val upper = device.brightnessMax.toFloat().coerceAtLeast(lower + 1f)
                GradientControlSlider(
                    value = sliderValue.coerceIn(lower, upper), valueRange = lower..upper,
                    gradient = listOf(Color(0xFF34224F), Color(0xFF7650B5), Color(0xFFB98BFF), Color(0xFFF5ECFF)),
                    onValueChange = { sliderValue = it },
                    onValueChangeFinished = { onBrightness(sliderValue.toInt()) }, enabled = !isBusy
                )
            }
            if (colorCapability != null) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(modifier = Modifier.size(44.dp).background(Color.hsv(hue, 0.92f, 1f), CircleShape))
                    Column {
                        Text("Цвет лампы", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Предпросмотр оттенка", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
                if (colorCapability.colorModel == "rgb" || colorCapability.colorModel == "hsv") {
                    Text("Выбери оттенок", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(0f, 25f, 55f, 115f, 175f, 210f, 270f, 325f).forEach { presetHue ->
                            Box(modifier = Modifier.size(29.dp).background(Color.hsv(presetHue, 1f, 1f), CircleShape)
                                .clickable(enabled = !isBusy) { hue = presetHue; onHue(presetHue.toInt()) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Тон", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        Spacer(Modifier.width(8.dp))
                        GradientControlSlider(
                            value = hue, valueRange = 0f..360f,
                            gradient = listOf(Color.Red, Color(0xFFFF9800), Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color(0xFF8B00FF), Color.Red),
                            onValueChange = { hue = it }, onValueChangeFinished = { onHue(hue.toInt()) },
                            modifier = Modifier.weight(1f), enabled = !isBusy
                        )
                    }
                }
                if (colorCapability.temperatureSupported && colorCapability.temperatureMax > colorCapability.temperatureMin) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Температура света", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Spacer(Modifier.weight(1f))
                        Text("${temperature.toInt()} K", fontSize = 11.sp)
                    }
                    GradientControlSlider(
                        value = temperature.coerceIn(colorCapability.temperatureMin.toFloat(), colorCapability.temperatureMax.toFloat()),
                        valueRange = colorCapability.temperatureMin.toFloat()..colorCapability.temperatureMax.toFloat(),
                        gradient = listOf(Color(0xFFFFA84A), Color(0xFFFFE7B8), Color(0xFFD4E5FF)),
                        onValueChange = { temperature = it }, onValueChangeFinished = { onTemperature(temperature.toInt()) }, enabled = !isBusy
                    )
                }
                if (colorCapability.colorScenes.isNotEmpty()) {
                    Text("Световые эффекты", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        colorCapability.colorScenes.forEach { scene ->
                            FilterChip(selected = colorCapability.instance == "scene" && colorCapability.value == scene,
                                onClick = { onColorScene(scene) }, enabled = !isBusy, label = { Text(sceneLabel(scene), fontSize = 11.sp) })
                        }
                    }
                }
            }
            device.modeCapabilities.forEach { capability ->
                Text(modeInstanceLabel(capability.instance), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    capability.modeOptions.forEach { mode ->
                        FilterChip(
                            selected = capability.value == mode,
                            onClick = { onMode(capability.instance, mode) },
                            enabled = !isBusy,
                            label = { Text(modeLabel(mode), fontSize = 11.sp) }
                        )
                    }
                }
            }
            if (device.properties.isNotEmpty()) {
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Text("Показатели датчиков", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                device.properties.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                        pair.forEach { property ->
                            SensorVisualization(
                                property = property,
                                modifier = Modifier.weight(1f).aspectRatio(1f)
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f).aspectRatio(1f))
                    }
                }
                device.properties.filter { it.value is Number }.forEach { property ->
                    SensorHistoryChart(deviceId = device.id, property = property)
                }
            }
            if (!device.canToggle && !device.canDim && colorCapability == null && device.modeCapabilities.isEmpty() && device.properties.isEmpty()) {
                Text("Устройство доступно для просмотра, но API не предоставил поддерживаемых элементов управления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
        }
    }
}

@Composable
private fun GradientControlSlider(
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    gradient: List<Color>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val insetPx = with(density) { 12.dp.toPx() }
    val currentChange by rememberUpdatedState(onValueChange)
    val currentFinished by rememberUpdatedState(onValueChangeFinished)
    val rangeStart = valueRange.start
    val rangeEnd = valueRange.endInclusive.coerceAtLeast(rangeStart + 0.001f)

    fun updateFromX(x: Float, width: Float) {
        val usableWidth = (width - insetPx * 2f).coerceAtLeast(1f)
        val fraction = ((x - insetPx) / usableWidth).coerceIn(0f, 1f)
        currentChange(rangeStart + (rangeEnd - rangeStart) * fraction)
    }

    val touchModifier = Modifier
        .pointerInput(enabled, valueRange) {
            if (enabled) {
                detectTapGestures(onTap = { point ->
                    updateFromX(point.x, size.width.toFloat())
                    currentFinished()
                })
            }
        }
        .pointerInput(enabled, valueRange) {
            if (enabled) {
                detectDragGestures(
                    onDragStart = { point -> updateFromX(point.x, size.width.toFloat()) },
                    onDrag = { change, _ ->
                        change.consume()
                        updateFromX(change.position.x, size.width.toFloat())
                    },
                    onDragEnd = { currentFinished() }
                )
            }
        }

    Box(
        modifier = modifier.fillMaxWidth().height(42.dp).then(touchModifier),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val left = insetPx
            val right = (size.width - insetPx).coerceAtLeast(left + 1f)
            val centerY = size.height / 2f
            val trackHeight = 7.dp.toPx()
            val radius = trackHeight / 2f
            val fraction = ((value - rangeStart) / (rangeEnd - rangeStart)).coerceIn(0f, 1f)
            val thumbX = left + (right - left) * fraction
            drawRoundRect(
                color = Color(0xFF8A7A9F).copy(alpha = if (enabled) 0.22f else 0.10f),
                topLeft = Offset(left, centerY - radius),
                size = androidx.compose.ui.geometry.Size(right - left, trackHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius)
            )
            drawRoundRect(
                brush = Brush.horizontalGradient(colors = gradient, startX = left, endX = right),
                topLeft = Offset(left, centerY - radius),
                size = androidx.compose.ui.geometry.Size(right - left, trackHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius)
            )
            drawCircle(Color.Black.copy(alpha = 0.22f), 10.dp.toPx(), Offset(thumbX, centerY + 1.dp.toPx()))
            drawCircle(Color(0xFFF8F2FF), 9.dp.toPx(), Offset(thumbX, centerY))
            drawCircle(if (enabled) Color(0xFF7546C8) else Color(0xFF8B8296), 5.5.dp.toPx(), Offset(thumbX, centerY))
        }
    }
}

@Composable
private fun SensorVisualization(
    property: ru.dislive.yandexhomewidgets.data.HomeProperty,
    modifier: Modifier = Modifier
) {
    val numeric = (property.value as? Number)?.toFloat()
    val progress = numeric?.let { sensorProgress(property.instance, it) }
    val isDoor = property.instance.lowercase() in setOf("open", "contact", "door_open", "opening")
    val isOpen = when (val value = property.value) {
        is Boolean -> value
        is Number -> value.toInt() != 0
        is String -> value.lowercase() in setOf("open", "opened", "true", "detected", "1", "on")
        else -> false
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.72f)),
        modifier = modifier
    ) {
        if (isDoor) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                SmartGlyph(if (isOpen) "door_open" else "door_closed", Modifier.size(34.dp),
                    if (isOpen) Color(0xFFFFB35C) else Color(0xFFBCA5F5))
                Text(if (isOpen) "Открыто" else "Закрыто", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        } else {
            Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconTile(sensorIconKind(property.instance), Modifier.size(34.dp), iconSize = 21.dp, active = false)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(sensorLabel(property.instance), fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f), maxLines = 2)
                        Text(sensorValue(property.instance, property.value), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
                if (progress != null) {
                    Box(modifier = Modifier.fillMaxWidth().height(5.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.09f), RoundedCornerShape(50))) {
                        Box(modifier = Modifier.fillMaxWidth(progress).height(5.dp)
                            .background(Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFC4A5FF))), RoundedCornerShape(50)))
                    }
                }
            }
        }
    }
}

private fun sensorIconKind(instance: String): String = when (instance) {
    "temperature" -> "temperature"
    "humidity" -> "humidity"
    "pressure" -> "air"
    "battery_level" -> "power"
    "illumination" -> "sun"
    "co2_level" -> "air"
    "open", "contact", "door_open", "opening" -> "door_closed"
    "motion" -> "motion"
    "water_leak" -> "leak"
    "smoke", "gas" -> "air"
    else -> "sparkles"
}

private fun sensorProgress(instance: String, value: Float): Float? {
    val fraction = when (instance) {
        "temperature" -> (value + 10f) / 60f
        "humidity", "battery_level" -> value / 100f
        "pressure" -> (value - 900f) / 300f
        "illumination" -> value / 1000f
        "co2_level" -> (value - 400f) / 1600f
        "pm1_density", "pm2.5_density", "pm10_density" -> value / 150f
        "voltage" -> value / 24f
        "power" -> value / 1500f
        else -> return null
    }
    return fraction.coerceIn(0f, 1f)
}


@Composable
private fun ScenariosScreen(scenarios: List<HomeScenario>, isBusy: Boolean, onRun: (HomeScenario) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Запускай созданные в приложении «Дом с Алисой» сценарии.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        if (scenarios.isEmpty()) EmptyCard("Сценарии не найдены.")
        scenarios.forEach { scenario ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(scenario.name, fontWeight = FontWeight.Medium)
                        Text(if (scenario.isActive) "Активен" else "Сценарий", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), fontSize = 11.sp)
                    }
                    Button(onClick = { onRun(scenario) }, enabled = !isBusy) { Text("Запустить") }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(history: List<HomeChange>, onClear: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Последние изменения", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            TextButton(onClick = onClear, enabled = history.isNotEmpty()) { Text("Очистить") }
        }
        if (history.isEmpty()) {
            EmptyCard("История пока пуста. Она начнёт заполняться после обнаружения изменений в доме.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { "${it.timestamp}-${it.kind}-${it.title}-${it.detail}" }) { change ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(change.title, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            Text(change.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                            Text(SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()).format(Date(change.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SensorAnalyticsScreen(devices: List<HomeDevice>) {
    val numericSensors = devices.flatMap { device ->
        device.properties.filter { it.value is Number }.map { property -> device to property }
    }
    val alerts = buildList {
        devices.forEach { device ->
            device.properties.forEach propertyLoop@{ property ->
                if (property.instance == "water_leak" && (property.value == true || property.value == "detected")) {
                    add("${device.name}: датчик сообщает о воде")
                    return@propertyLoop
                }
                val value = (property.value as? Number)?.toDouble() ?: return@propertyLoop
                when {
                    property.instance == "battery_level" && value < 20 -> add("${device.name}: низкий заряд батареи (${value.toInt()}%)")
                    property.instance == "co2_level" && value > 1000 -> add("${device.name}: CO₂ выше 1000 ppm")
                }
            }
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "analytics_intro") {
            Box(
                modifier = Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF285B78), Color(0xFF4E65A5), Color(0xFF7658A7))),
                    RoundedCornerShape(22.dp)
                ).padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Тренды и состояние дома", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Локальные графики показаний за последние 24 часа или 7 дней", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                }
            }
        }
        item(key = "analytics_alerts_title") { Text("На что обратить внимание", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        item(key = "analytics_alerts") {
            if (alerts.isEmpty()) {
                EmptyCard("По доступным показаниям сейчас нет активных предупреждений.")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    alerts.forEach { alert ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                            Text("• $alert", modifier = Modifier.fillMaxWidth().padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item(key = "analytics_sensors_title") { Text("История датчиков", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        if (numericSensors.isEmpty()) {
            item(key = "analytics_empty") { EmptyCard("Числовые датчики пока не найдены. Графики появятся после первого получения показаний.") }
        } else {
            items(numericSensors, key = { (device, property) -> "${device.id}_${property.instance}" }) { (device, property) ->
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("${device.name} · ${sensorLabel(property.instance)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    SensorVisualization(property)
                    SensorHistoryChart(deviceId = device.id, property = property)
                }
            }
        }
    }
}

@Composable
private fun SensorHistoryChart(deviceId: String, property: ru.dislive.yandexhomewidgets.data.HomeProperty) {
    var hours by remember(deviceId, property.instance) { mutableStateOf(24) }
    val samples = SensorHistoryStore.load(LocalContext.current, deviceId, property.instance, hours)
    val chartColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.11f)
    val latest = samples.lastOrNull()?.value ?: (property.value as? Number)?.toDouble()
    val minValue = samples.minOfOrNull { it.value }
    val maxValue = samples.maxOfOrNull { it.value }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))) {
        Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("История показаний", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                    Text(latest?.let { sensorValue(property.instance, it) } ?: "Нет данных", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                FilterChip(selected = hours == 24, onClick = { hours = 24 }, label = { Text("24 ч", fontSize = 10.sp) })
                Spacer(Modifier.width(4.dp))
                FilterChip(selected = hours == 168, onClick = { hours = 168 }, label = { Text("7 д", fontSize = 10.sp) })
            }
            if (samples.isEmpty()) {
                Text("История начнёт накапливаться после обновления показаний.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
            } else {
                Canvas(modifier = Modifier.fillMaxWidth().height(104.dp)) {
                    val left = 3.dp.toPx()
                    val right = size.width - 3.dp.toPx()
                    val top = 8.dp.toPx()
                    val bottom = size.height - 8.dp.toPx()
                    val values = samples.map { it.value }
                    val low = values.minOrNull() ?: 0.0
                    val high = values.maxOrNull() ?: low + 1.0
                    val span = (high - low).takeIf { it > 0.0001 } ?: 1.0
                    for (line in 0..2) {
                        val y = top + (bottom - top) * line / 2f
                        drawLine(
                            color = gridColor,
                            start = Offset(left, y), end = Offset(right, y), strokeWidth = 1.dp.toPx()
                        )
                    }
                    val path = Path()
                    samples.forEachIndexed { index, sample ->
                        val x = if (samples.size <= 1) (left + right) / 2f else left + (right - left) * index / (samples.size - 1).toFloat()
                        val y = bottom - ((sample.value - low) / span).toFloat() * (bottom - top)
                        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, color = chartColor, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                    val last = samples.last()
                    val lastY = bottom - ((last.value - low) / span).toFloat() * (bottom - top)
                    drawCircle(color = chartColor, radius = 4.dp.toPx(), center = Offset(right, lastY))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(minValue?.let { "Мин. ${"%.1f".format(Locale.getDefault(), it)}" } ?: "", modifier = Modifier.weight(1f), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
                    Text("${samples.size} точек · локально", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
                    Text(maxValue?.let { "Макс. ${"%.1f".format(Locale.getDefault(), it)}" } ?: "", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.58f))
                }
                val firstDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(samples.first().timestamp))
                val lastDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(samples.last().timestamp))
                Text("$firstDate — $lastDate", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    isDarkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit,
    options: HomeNotificationOptions,
    onNotificationChange: (HomeNotificationOptions) -> Unit,
    updateMessage: String,
    updateInfo: AppUpdateInfo?,
    isCheckingUpdate: Boolean,
    onCheckUpdates: () -> Unit,
    onDisconnect: () -> Unit,
    onNotificationPermission: () -> Unit
) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Оформление", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Тёмная тема", isDarkTheme, onThemeChange)
                Text(if (isDarkTheme) "Используется тёмное оформление." else "Используется светлое оформление.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Уведомления", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                SettingSwitch("Все уведомления", options.enabled) { onNotificationChange(options.copy(enabled = it)) }
                if (options.enabled) {
                    Divider()
                    SettingSwitch("Устройства, комнаты и структура дома", options.deviceChanges) { onNotificationChange(options.copy(deviceChanges = it)) }
                    SettingSwitch("Изменения состояний устройств", options.capabilityChanges) { onNotificationChange(options.copy(capabilityChanges = it)) }
                    SettingSwitch("Датчики и показатели", options.sensorChanges) { onNotificationChange(options.copy(sensorChanges = it)) }
                    SettingSwitch("Группы и сценарии", options.groupScenarioChanges) { onNotificationChange(options.copy(groupScenarioChanges = it)) }
                }
                Text("Фоновая проверка выполняется примерно раз в 15 минут. Android может задерживать её; это не мгновенные push-уведомления.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                OutlinedButton(onClick = onNotificationPermission, modifier = Modifier.fillMaxWidth()) { Text("Разрешения уведомлений Android") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Обновление приложения", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Установленная версия: ${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Text(updateMessage, fontSize = 12.sp)
                if (!updateInfo?.notes.isNullOrBlank()) Text(updateInfo?.notes.orEmpty(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                Button(onClick = onCheckUpdates, enabled = !isCheckingUpdate, modifier = Modifier.fillMaxWidth()) {
                    if (isCheckingUpdate) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Проверить обновления")
                }
                if (updateInfo != null) {
                    Button(onClick = { openUrl(context, updateInfo.apkUrl ?: updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Скачать обновление ${updateInfo.version}") }
                    TextButton(onClick = { openUrl(context, updateInfo.releaseUrl) }, modifier = Modifier.fillMaxWidth()) { Text("Описание версии на GitHub") }
                }
                Text("Обновление загружается с GitHub Releases. После скачивания Android попросит подтвердить установку.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
        }
        OutlinedButton(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) { Text("Отключить Яндекс") }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Text(message, modifier = Modifier.fillMaxWidth().padding(16.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}

private fun sensorLabel(instance: String): String = when (instance) {
    "temperature" -> "Температура"
    "humidity" -> "Влажность"
    "pressure" -> "Давление"
    "battery_level" -> "Заряд батареи"
    "voltage" -> "Напряжение"
    "current" -> "Ток"
    "power" -> "Мощность"
    "illumination" -> "Освещённость"
    "co2_level" -> "Уровень CO₂"
    "pm1_density" -> "PM1"
    "pm2.5_density" -> "PM2.5"
    "pm10_density" -> "PM10"
    "open" -> "Открытие"
    "motion" -> "Движение"
    "vibration" -> "Вибрация"
    "water_leak" -> "Протечка"
    "smoke" -> "Дым"
    "gas" -> "Газ"
    else -> instance.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun sensorValue(instance: String, value: Any?): String {
    val raw = when (value) {
        null -> "Нет данных"
        is Boolean -> if (value) "Да" else "Нет"
        else -> value.toString()
    }
    val unit = when (instance) {
        "temperature" -> " °C"
        "humidity", "battery_level" -> "%"
        "pressure" -> " гПа"
        "illumination" -> " лк"
        "co2_level" -> " ppm"
        "voltage" -> " В"
        "current" -> " А"
        "power" -> " Вт"
        else -> ""
    }
    return when (raw.lowercase()) {
        "open" -> "Открыто"
        "closed" -> "Закрыто"
        "detected" -> "Обнаружено"
        "not_detected" -> "Не обнаружено"
        else -> raw + unit
    }
}

private fun sceneLabel(id: String): String = when (id) {
    "alarm" -> "Тревога"
    "alice" -> "Алиса"
    "candle" -> "Свеча"
    "dinner" -> "Ужин"
    "fantasy" -> "Фантазия"
    "garland" -> "Гирлянда"
    "jungle" -> "Джунгли"
    "movie" -> "Кино"
    "neon" -> "Неон"
    "night" -> "Ночь"
    "ocean" -> "Океан"
    "party" -> "Вечеринка"
    "reading" -> "Чтение"
    "rest" -> "Отдых"
    "romance" -> "Романтика"
    "siren" -> "Сирена"
    else -> id
}

private fun modeInstanceLabel(instance: String): String = when (instance) {
    "thermostat" -> "Режим термостата"
    "cleanup_mode" -> "Режим уборки"
    "fan_speed" -> "Скорость вентилятора"
    else -> "Режим: $instance"
}

private fun modeLabel(value: String): String = when (value) {
    "auto" -> "Авто"
    "heat" -> "Обогрев"
    "cool" -> "Охлаждение"
    "dry" -> "Осушение"
    "fan_only" -> "Вентиляция"
    "on" -> "Вкл."
    "off" -> "Выкл."
    "high" -> "Высокая"
    "medium" -> "Средняя"
    "low" -> "Низкая"
    "turbo" -> "Турбо"
    "eco" -> "Эко"
    else -> value.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
