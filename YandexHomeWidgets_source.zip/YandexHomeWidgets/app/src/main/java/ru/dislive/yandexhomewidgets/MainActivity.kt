package ru.dislive.yandexhomewidgets

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.HomeDevice
import ru.dislive.yandexhomewidgets.data.HomeGroup
import ru.dislive.yandexhomewidgets.data.HomeScenario
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi
import ru.dislive.yandexhomewidgets.data.YandexOAuth
import ru.dislive.yandexhomewidgets.widget.HomeWidget
import ru.dislive.yandexhomewidgets.widget.WorkScheduler

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkScheduler.schedule(this)
        setContent { YandexHomeApp() }
    }
}

@Composable
private fun YandexHomeApp() {
    val context = LocalContext.current
    val config = remember { context.getSharedPreferences("app_config", Context.MODE_PRIVATE) }
    val tokenStore = remember { TokenStore(context.applicationContext) }
    val scope = rememberCoroutineScope()

    var clientId by remember { mutableStateOf(config.getString("client_id", "").orEmpty()) }
    var redirectInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Сначала подключи Яндекс OAuth") }
    var error by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf(emptyList<HomeDevice>()) }
    var scenarios by remember { mutableStateOf(emptyList<HomeScenario>()) }
    var groups by remember { mutableStateOf(emptyList<HomeGroup>()) }

    suspend fun reloadHome() {
        isBusy = true
        error = ""
        try {
            val token = tokenStore.getValidAccessToken()
            if (token.isNullOrBlank()) {
                isConnected = false
                status = "Яндекс не подключён"
                return
            }
            val home = YandexHomeApi(token).getHome()
            devices = home.devices.map { it.copy(isFavorite = HomeCache.isFavorite(context, it.id)) }
            scenarios = home.scenarios
            groups = home.groups
            HomeCache.saveHome(context, home)
            isConnected = true
            status = "Подключено · ${devices.size} устройств · ${scenarios.size} сценариев"
            HomeWidget().updateAll(context)
        } catch (e: Exception) {
            error = e.message ?: "Не удалось загрузить умный дом"
            status = "Не удалось обновить данные"
        } finally {
            isBusy = false
        }
    }

    LaunchedEffect(Unit) {
        if (clientId.isNotBlank()) reloadHome()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9DB8FF),
            onPrimary = Color(0xFF10203D),
            secondary = Color(0xFFB6C7EA),
            background = Color(0xFF101522),
            surface = Color(0xFF192236),
            onSurface = Color(0xFFF2F5FC),
            onBackground = Color(0xFFF2F5FC)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF101522)) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Яндекс Дом", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Устройства, сценарии и быстрые виджеты", color = Color(0xFF9BAAC4), fontSize = 14.sp)
                }

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2942))) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(modifier = Modifier.width(9.dp).height(9.dp), shape = MaterialTheme.shapes.small,
                                color = if (isConnected) Color(0xFF60D6A2) else Color(0xFFF0B86E)) {}
                            Spacer(Modifier.width(9.dp))
                            Text(status, color = Color.White, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.weight(1f))
                            if (isBusy) CircularProgressIndicator(modifier = Modifier.width(20.dp).height(20.dp), strokeWidth = 2.dp, color = Color(0xFF9DB8FF))
                        }
                        if (isConnected) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { scope.launch { reloadHome() } }, enabled = !isBusy) { Text("Обновить") }
                                OutlinedButton(onClick = {
                                    tokenStore.clear()
                                    HomeCache.clear(context)
                                    devices = emptyList()
                                    scenarios = emptyList()
                                    groups = emptyList()
                                    isConnected = false
                                    status = "Яндекс отключён"
                                    error = ""
                                    scope.launch { HomeWidget().updateAll(context) }
                                }) { Text("Отключить") }
                            }
                        }
                    }
                }

                if (!isConnected) {
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF192236))) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Подключение к Яндексу", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Создай приложение в Яндекс OAuth типа «Для доступа к API или отладки». Выдай разрешения iot:view и iot:control. В Redirect URI укажи https://oauth.yandex.ru/verification_code.",
                                color = Color(0xFFB8C4D8), fontSize = 13.sp
                            )
                            TextButton(onClick = {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://oauth.yandex.ru/client/new/")))
                            }) { Text("Открыть Яндекс OAuth") }
                            OutlinedTextField(
                                value = clientId,
                                onValueChange = { clientId = it; config.edit().putString("client_id", it.trim()).apply() },
                                modifier = Modifier.fillMaxWidth(), label = { Text("Client ID") }, singleLine = true
                            )
                            Button(onClick = {
                                try {
                                    val url = YandexOAuth.authorizationUrl(clientId, tokenStore)
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    error = ""
                                    status = "Подтверди доступ на странице Яндекса, затем вернись сюда"
                                } catch (e: Exception) { error = e.message ?: "Не удалось открыть авторизацию" }
                            }, enabled = clientId.isNotBlank() && !isBusy) { Text("Открыть страницу подтверждения") }
                            Divider(color = Color(0xFF34425B))
                            Text(
                                "После подтверждения Яндекс перенаправит на verification_code. Скопируй полный адрес из адресной строки браузера и вставь ниже. Не вводи здесь пароль или Client Secret.",
                                color = Color(0xFFB8C4D8), fontSize = 13.sp
                            )
                            OutlinedTextField(
                                value = redirectInput, onValueChange = { redirectInput = it },
                                modifier = Modifier.fillMaxWidth(), label = { Text("Полный адрес после подтверждения") }, minLines = 2
                            )
                            Button(onClick = {
                                scope.launch {
                                    isBusy = true
                                    error = ""
                                    try {
                                        val response = YandexOAuth.exchangeRedirect(redirectInput, clientId, tokenStore)
                                        tokenStore.saveTokens(response)
                                        redirectInput = ""
                                        status = "Токен получен. Загружаю устройства…"
                                        reloadHome()
                                    } catch (e: Exception) {
                                        error = e.message ?: "Не удалось завершить подключение"
                                        isBusy = false
                                    }
                                }
                            }, enabled = clientId.isNotBlank() && redirectInput.isNotBlank() && !isBusy) { Text("Подключить") }
                            Text("OAuth PKCE. Токены хранятся зашифрованными через Android Keystore.", color = Color(0xFF8797B2), fontSize = 11.sp)
                        }
                    }
                }

                if (isConnected) {
                    if (groups.isNotEmpty()) {
                        Text("Группы", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        groups.forEach { group ->
                            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF192236))) {
                                Text(group.name, modifier = Modifier.padding(14.dp), color = Color.White, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                    if (devices.isEmpty()) {
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF192236))) {
                            Text("В этом аккаунте пока не найдено устройств.", modifier = Modifier.padding(16.dp), color = Color(0xFFB8C4D8))
                        }
                    } else {
                        Text("Устройства", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        devices.forEach { device ->
                            DeviceCard(
                                device = device,
                                onFavorite = { favorite ->
                                    HomeCache.setFavorite(context, device.id, favorite)
                                    devices = devices.map { if (it.id == device.id) it.copy(isFavorite = favorite) else it }
                                    scope.launch { HomeWidget().updateAll(context) }
                                },
                                onToggle = { value ->
                                    scope.launch {
                                        isBusy = true
                                        error = ""
                                        try {
                                            val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                                            YandexHomeApi(token).setOnOff(device.id, value)
                                            reloadHome()
                                        } catch (e: Exception) { error = e.message ?: "Не удалось управлять устройством"; isBusy = false }
                                    }
                                },
                                onBrightness = { value ->
                                    scope.launch {
                                        isBusy = true
                                        error = ""
                                        try {
                                            val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                                            YandexHomeApi(token).setBrightness(device.id, value)
                                            reloadHome()
                                        } catch (e: Exception) { error = e.message ?: "Не удалось изменить яркость"; isBusy = false }
                                    }
                                }
                            )
                        }
                    }
                    if (scenarios.isNotEmpty()) {
                        Spacer(Modifier.height(2.dp))
                        Text("Сценарии", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        scenarios.forEach { scenario ->
                            ScenarioCard(scenario) {
                                scope.launch {
                                    isBusy = true
                                    error = ""
                                    try {
                                        val token = tokenStore.getValidAccessToken() ?: throw IllegalStateException("Нужно заново подключить Яндекс")
                                        YandexHomeApi(token).runScenario(scenario.id)
                                        status = "Сценарий «${scenario.name}» запущен"
                                    } catch (e: Exception) { error = e.message ?: "Не удалось запустить сценарий" }
                                    finally { isBusy = false }
                                }
                            }
                        }
                    }
                    Text("Отметь звёздочкой нужные устройства, затем добавь виджет «Яндекс Дом» на главный экран телефона.", color = Color(0xFF9BAAC4), fontSize = 12.sp)
                }

                if (error.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF382631))) {
                        Text(error, modifier = Modifier.padding(14.dp), color = Color(0xFFFFC2C2), fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Фоновая синхронизация зависит от ограничений Android. Система может отложить её; для обновления вручную нажми «Обновить».", color = Color(0xFF71819C), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DeviceCard(device: HomeDevice, onFavorite: (Boolean) -> Unit, onToggle: (Boolean) -> Unit, onBrightness: (Int) -> Unit) {
    var sliderValue by remember(device.id, device.brightness) { mutableFloatStateOf((device.brightness ?: device.brightnessMin).toFloat()) }
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF192236))) {
        Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(device.name, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(device.room.ifBlank { "Без комнаты" }, fontSize = 12.sp, color = Color(0xFF9BAAC4))
                }
                TextButton(onClick = { onFavorite(!device.isFavorite) }) { Text(if (device.isFavorite) "★" else "☆", fontSize = 20.sp) }
                if (device.canToggle && device.onOff != null) Switch(checked = device.onOff, onCheckedChange = onToggle)
            }
            if (device.canDim && device.brightness != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Яркость", color = Color(0xFFB8C4D8), fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${sliderValue.toInt()}%", color = Color.White, fontSize = 12.sp)
                }
                val lower = device.brightnessMin.toFloat()
                val upper = device.brightnessMax.toFloat().coerceAtLeast(lower + 1f)
                Slider(value = sliderValue.coerceIn(lower, upper), onValueChange = { sliderValue = it },
                    onValueChangeFinished = { onBrightness(sliderValue.toInt()) }, valueRange = lower..upper)
            }
            if (!device.canToggle && !device.canDim) Text("Показывается состояние; управление этим типом пока не добавлено.", color = Color(0xFF8797B2), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ScenarioCard(scenario: HomeScenario, onRun: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF192236))) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(scenario.name, color = Color.White, fontWeight = FontWeight.Medium)
                Text(if (scenario.isActive) "Активен" else "Сценарий", color = Color(0xFF9BAAC4), fontSize = 11.sp)
            }
            Button(onClick = onRun) { Text("Запустить") }
        }
    }
}
