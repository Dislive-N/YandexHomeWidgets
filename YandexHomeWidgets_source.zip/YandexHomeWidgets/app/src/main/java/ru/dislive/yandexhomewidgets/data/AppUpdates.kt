package ru.dislive.yandexhomewidgets.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class AppUpdateInfo(
    val version: String,
    val buildCode: Int,
    val releaseUrl: String,
    val apkUrl: String?,
    val notes: String
)

object AppUpdateChecker {
    private const val RELEASES_URL = "https://api.github.com/repos/Dislive-N/YandexHomeWidgets/releases?per_page=10"

    suspend fun check(installedVersion: String, installedBuildCode: Int): AppUpdateInfo? = withContext(Dispatchers.IO) {
        val connection = URL(RELEASES_URL).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
            connection.setRequestProperty("Cache-Control", "no-cache")
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("GitHub вернул HTTP $code")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val releases = JSONArray(body)
            if (releases.length() == 0) return@withContext null
            val release = (0 until releases.length()).mapNotNull { releases.optJSONObject(it) }
                .filterNot { it.optBoolean("draft", false) }
                .maxByOrNull { it.optString("published_at", it.optString("created_at")) }
                ?: return@withContext null
            val tag = release.optString("tag_name")
            val version = Regex("(?:app-)?v?([0-9]+(?:\\.[0-9]+){1,3})(?:-build|$)", RegexOption.IGNORE_CASE)
                .find(tag)?.groupValues?.getOrNull(1)
                ?: tag.removePrefix("v").substringBefore("-build").substringAfterLast("v")
            val releaseBuild = Regex("build[-_](\\d+)", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
            val apkUrl = release.optJSONArray("assets")?.let { assets ->
                (0 until assets.length()).mapNotNull { assets.optJSONObject(it) }
                    .firstOrNull { it.optString("name").endsWith(".apk", ignoreCase = true) }
                    ?.optString("browser_download_url")?.takeIf(String::isNotBlank)
            }
            val versionComparison = compareVersions(version, installedVersion)
            val isNewer = versionComparison > 0 || (versionComparison == 0 && releaseBuild > installedBuildCode)
            if (apkUrl.isNullOrBlank() || !isNewer) return@withContext null
            AppUpdateInfo(
                version = version,
                buildCode = releaseBuild,
                releaseUrl = release.optString("html_url"),
                apkUrl = apkUrl,
                notes = release.optString("body").take(1200)
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun compareVersions(left: String, right: String): Int {
        val a = left.split('.').map { it.toIntOrNull() ?: 0 }
        val b = right.split('.').map { it.toIntOrNull() ?: 0 }
        for (index in 0 until maxOf(a.size, b.size)) {
            val diff = (a.getOrNull(index) ?: 0).compareTo(b.getOrNull(index) ?: 0)
            if (diff != 0) return diff
        }
        return 0
    }
}


/** Uses Android's download service so APK downloads survive leaving the app and show progress/notification. */
object AppUpdateInstaller {
    fun download(context: Context, update: AppUpdateInfo): Long {
        val url = update.apkUrl?.takeIf { it.startsWith("https://", ignoreCase = true) }
            ?: throw IllegalArgumentException("Ссылка на APK в GitHub Release не найдена")
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("Яндекс Дом ${update.version}")
            .setDescription("Загрузка обновления приложения")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "YandexHomeWidgets-${update.version}.apk")
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return manager.enqueue(request)
    }
}
