package ru.dislive.yandexhomewidgets.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.os.Build
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class AppUpdateInfo(
    val version: String,
    val buildCode: Int,
    val releaseUrl: String,
    val apkUrl: String?,
    val notes: String
)

object AppUpdateChecker {
    private const val RELEASES_URL = "https://api.github.com/repos/Dislive-N/YandexHomeWidgets/releases?per_page=10"

    suspend fun check(installedVersion: String, installedBuildCode: Int): AppUpdateInfo? = withContext(Dispatchers.IO) {
        val connection = URL(RELEASES_URL).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
            connection.setRequestProperty("Cache-Control", "no-cache")
            val code = connection.responseCode
            if (code !in 200..299) {
                val errorBody = runCatching {
                    (connection.errorStream ?: connection.inputStream).bufferedReader(Charsets.UTF_8).use { it.readText() }
                }.getOrDefault("")
                val detail = runCatching { org.json.JSONObject(errorBody).optString("message") }.getOrDefault("")
                val message = when {
                    code == 403 && connection.getHeaderField("X-RateLimit-Remaining") == "0" ->
                        "GitHub временно ограничил проверку обновлений. Попробуй позже."
                    detail.isNotBlank() -> "GitHub: $detail (HTTP $code)"
                    else -> "GitHub вернул HTTP $code"
                }
                throw IllegalStateException(message)
            }
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val releases = JSONArray(body)
            if (releases.length() == 0) return@withContext null

            val installed = installedVersion.trim().removePrefix("v")
            val candidates = (0 until releases.length()).mapNotNull { releases.optJSONObject(it) }
                .filterNot { it.optBoolean("draft", false) }
                .mapNotNull { release ->
                    val tag = release.optString("tag_name")
                    val version = Regex("(?:app-)?v?([0-9]+(?:\\\\.[0-9]+){1,3})(?:-build|$)", RegexOption.IGNORE_CASE)
                        .find(tag)?.groupValues?.getOrNull(1)
                        ?: tag.removePrefix("v").substringBefore("-build").substringAfterLast("v")
                    val releaseBuild = Regex("build[-_](\\\\d+)", RegexOption.IGNORE_CASE)
                        .find(tag)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                    val apkUrl = release.optJSONArray("assets")?.let { assets ->
                        (0 until assets.length()).mapNotNull { assets.optJSONObject(it) }
                            .firstOrNull {
                                it.optString("name").endsWith(".apk", ignoreCase = true) &&
                                    it.optLong("size", 0L) > 1_000_000L
                            }
                            ?.optString("browser_download_url")
                            ?.takeIf { it.startsWith("https://", ignoreCase = true) }
                    }
                    if (apkUrl.isNullOrBlank()) null
                    else {
                        val newer = compareVersions(version, installed) > 0 ||
                            (compareVersions(version, installed) == 0 && releaseBuild > installedBuildCode)
                        if (!newer) null else Triple(release, version, Pair(releaseBuild, apkUrl))
                    }
                }
                .sortedWith(Comparator { left, right ->
                    val versionOrder = compareVersions(right.second, left.second)
                    if (versionOrder != 0) versionOrder else right.third.first.compareTo(left.third.first)
                })

            val selected = candidates.firstOrNull() ?: return@withContext null
            val release = selected.first
            val version = selected.second
            val releaseBuild = selected.third.first
            val apkUrl = selected.third.second
            AppUpdateInfo(
                version = version,
                buildCode = releaseBuild,
                releaseUrl = release.optString("html_url"),
                apkUrl = apkUrl,
                notes = release.optString("body").take(1200)
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun compareVersions(left: String, right: String): Int {
        val a = left.split('.').map { it.toIntOrNull() ?: 0 }
        val b = right.split('.').map { it.toIntOrNull() ?: 0 }
        for (index in 0 until maxOf(a.size, b.size)) {
            val diff = (a.getOrNull(index) ?: 0).compareTo(b.getOrNull(index) ?: 0)
            if (diff != 0) return diff
        }
        return 0
    }

}


/** Android DownloadManager downloader plus explicit package-installer handoff. */
object AppUpdateInstaller {
    fun download(context: Context, update: AppUpdateInfo): Long {
        val url = update.apkUrl?.takeIf { it.startsWith("https://", ignoreCase = true) }
            ?: throw IllegalArgumentException("Ссылка на APK в GitHub Release не найдена")
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("Яндекс Дом ${update.version}")
            .setDescription("Загрузка обновления приложения")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "YandexHomeWidgets-${update.version}.apk")
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return manager.enqueue(request)
    }

    /** Returns null while running, "ready" when complete, or a readable failure message. */
    fun downloadState(context: Context, downloadId: Long): String? {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query().setFilterById(downloadId)) ?: return "Не удалось получить состояние загрузки."
        cursor.use {
            if (!it.moveToFirst()) return "Загрузка не найдена. Запусти скачивание ещё раз."
            return when (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                DownloadManager.STATUS_SUCCESSFUL -> "ready"
                DownloadManager.STATUS_FAILED -> {
                    val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    val detail = when (reason) {
                        DownloadManager.ERROR_CANNOT_RESUME -> "не удалось продолжить загрузку"
                        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "не найдено место для сохранения"
                        DownloadManager.ERROR_FILE_ERROR -> "ошибка записи файла"
                        DownloadManager.ERROR_HTTP_DATA_ERROR -> "ошибка передачи данных"
                        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "недостаточно свободного места"
                        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "слишком много перенаправлений GitHub"
                        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "сервер вернул неподдерживаемый HTTP-код"
                        else -> "код ошибки $reason"
                    }
                    "Не удалось скачать APK: $detail. Проверь сеть и свободное место."
                }
                else -> null
            }
        }
    }

    /** Opens Android's package installer. If sideload permission is missing, opens its settings first. */
    fun install(context: Context, downloadId: Long) {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val state = downloadState(context, downloadId)
        if (state != "ready") throw IllegalStateException(state ?: "Загрузка ещё не завершена.")
        val uri = manager.getUriForDownloadedFile(downloadId)
            ?: throw IllegalStateException("Android не нашёл загруженный APK. Повтори загрузку.")
        if (Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settingsIntent)
            throw IllegalStateException("Разреши установку приложений для «Яндекс Дом», затем нажми «Установить» ещё раз.")
        }
        val installIntent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(installIntent)
    }
}
