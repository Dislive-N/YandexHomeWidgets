package ru.dislive.yandexhomewidgets.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class AppUpdateInfo(
    val version: String,
    val buildCode: Int,
    val releaseUrl: String,
    val apkUrl: String?,
    val notes: String
)

object AppUpdateChecker {
    private const val RELEASES_URL = "https://api.github.com/repos/Dislive-N/YandexHomeWidgets/releases?per_page=1"

    suspend fun check(installedVersion: String, installedBuildCode: Int): AppUpdateInfo? = withContext(Dispatchers.IO) {
        val connection = URL(RELEASES_URL).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("GitHub вернул HTTP $code")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val releases = JSONArray(body)
            if (releases.length() == 0) return@withContext null
            val release = releases.getJSONObject(0)
            val tag = release.optString("tag_name")
            val version = Regex("app-v(.+?)-build").find(tag)?.groupValues?.getOrNull(1)
                ?: tag.removePrefix("v").substringBefore("-")
            val releaseBuild = Regex("build-(\\d+)").find(tag)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
            val apkUrl = release.optJSONArray("assets")?.let { assets ->
                (0 until assets.length()).mapNotNull { assets.optJSONObject(it) }
                    .firstOrNull { it.optString("name").endsWith(".apk", ignoreCase = true) }
                    ?.optString("browser_download_url")?.takeIf(String::isNotBlank)
            }
            val versionComparison = compareVersions(version, installedVersion)
            val isNewer = versionComparison > 0 || (versionComparison == 0 && releaseBuild > installedBuildCode)
            if (apkUrl.isNullOrBlank() || !isNewer) return@withContext null
            AppUpdateInfo(
                version = version,
                buildCode = releaseBuild,
                releaseUrl = release.optString("html_url"),
                apkUrl = apkUrl,
                notes = release.optString("body").take(1200)
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun compareVersions(left: String, right: String): Int {
        val a = left.split('.').map { it.toIntOrNull() ?: 0 }
        val b = right.split('.').map { it.toIntOrNull() ?: 0 }
        for (index in 0 until maxOf(a.size, b.size)) {
            val diff = (a.getOrNull(index) ?: 0).compareTo(b.getOrNull(index) ?: 0)
            if (diff != 0) return diff
        }
        return 0
    }
}
