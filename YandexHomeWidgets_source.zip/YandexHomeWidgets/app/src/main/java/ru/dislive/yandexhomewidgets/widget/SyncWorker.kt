package ru.dislive.yandexhomewidgets.widget

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import ru.dislive.yandexhomewidgets.data.HomeCache
import ru.dislive.yandexhomewidgets.data.HomeChangeDetector
import ru.dislive.yandexhomewidgets.data.HomeNotificationCenter
import ru.dislive.yandexhomewidgets.data.SensorHistoryStore
import ru.dislive.yandexhomewidgets.data.TokenStore
import ru.dislive.yandexhomewidgets.data.YandexHomeApi

class SyncWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val clientId = applicationContext.getSharedPreferences("app_config", Context.MODE_PRIVATE)
            .getString("client_id", "").orEmpty()
        if (clientId.isBlank()) return Result.success()
        return try {
            val token = TokenStore(applicationContext).getValidAccessToken() ?: return Result.success()
            val home = YandexHomeApi(token).getHome()
            val changes = HomeChangeDetector.collect(applicationContext, home)
            HomeNotificationCenter.showChanges(applicationContext, changes)
            HomeCache.saveHome(applicationContext, home)
            SensorHistoryStore.record(applicationContext, home.devices)
            HomeWidget().updateAll(applicationContext)
            Result.success()
        } catch (_: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}
