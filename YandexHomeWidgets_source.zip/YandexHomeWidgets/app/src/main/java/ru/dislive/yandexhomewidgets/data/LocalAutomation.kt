package ru.dislive.yandexhomewidgets.data

import android.content.Context
import org.json.JSONArray
import java.time.LocalTime
import java.util.UUID
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.abs

object AutomationConditionType {
    const val DEVICE_POWER = "device_power"
    const val SENSOR_VALUE = "sensor_value"
    const val GLOBAL_VARIABLE = "global_variable"
    const val TIME_WINDOW = "time_window"
    const val TIME_AT = "time_at"
    const val WEATHER = "weather"
}

object AutomationActionType {
    const val DEVICE_POWER = "device_power"
    const val BRIGHTNESS = "brightness"
    const val SET_VARIABLE = "set_variable"
    const val RUN_YANDEX_SCENARIO = "run_yandex_scenario"
}

data class AutomationCondition(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val deviceId: String = "",
    val property: String = "temperature",
    val operator: String = ">",
    val value: String = "",
    val variableName: String = "",
    val startTime: String = "22:00",
    val endTime: String = "07:00",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)

data class AutomationAction(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val deviceId: String = "",
    val enabled: Boolean = true,
    val brightness: Int = 50,
    val variableName: String = "",
    val variableValue: String = "",
    val scenarioId: String = ""
)

data class LocalAutomation(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val enabled: Boolean = true,
    val matchAllConditions: Boolean = true,
    val conditions: List<AutomationCondition>,
    val actions: List<AutomationAction>,
    val lastMatched: Boolean = false,
    val lastTriggeredAt: Long = 0L,
    val cooldownMinutes: Int = 2,
    val iconKey: String = "sparkles"
)

data class GlobalVariable(
    val name: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)

/** Local rules and variables. These are stored on this device and do not create Yandex cloud scenarios. */
object LocalAutomationStore {
    private const val PREFS = "local_automations_v1"
    private const val KEY_AUTOMATIONS = "automations"
    private const val KEY_VARIABLES = "variables"

    @Synchronized
    fun loadAutomations(context: Context): List<LocalAutomation> = runCatching {
        val raw = prefs(context).getString(KEY_AUTOMATIONS, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val conditionsJson = item.optJSONArray("conditions") ?: JSONArray()
                val actionsJson = item.optJSONArray("actions") ?: JSONArray()
                val conditions = buildList {
                    for (j in 0 until conditionsJson.length()) {
                        val c = conditionsJson.optJSONObject(j) ?: continue
                        add(AutomationCondition(
                            id = c.optString("id", UUID.randomUUID().toString()),
                            type = c.optString("type"),
                            deviceId = c.optString("deviceId"),
                            property = c.optString("property", "temperature"),
                            operator = c.optString("operator", ">"),
                            value = c.optString("value"),
                            variableName = c.optString("variableName"),
                            startTime = c.optString("startTime", "22:00"),
                            endTime = c.optString("endTime", "07:00"),
                            latitude = c.optDouble("latitude", 0.0),
                            longitude = c.optDouble("longitude", 0.0)
                        ))
                    }
                }
                val actions = buildList {
                    for (j in 0 until actionsJson.length()) {
                        val a = actionsJson.optJSONObject(j) ?: continue
                        add(AutomationAction(
                            id = a.optString("id", UUID.randomUUID().toString()),
                            type = a.optString("type"),
                            deviceId = a.optString("deviceId"),
                            enabled = a.optBoolean("enabled", true),
                            brightness = a.optInt("brightness", 50).coerceIn(0, 100),
                            variableName = a.optString("variableName"),
                            variableValue = a.optString("variableValue"),
                            scenarioId = a.optString("scenarioId")
                        ))
                    }
                }
                val id = item.optString("id")
                val name = item.optString("name")
                if (id.isNotBlank() && name.isNotBlank() && conditions.isNotEmpty() && actions.isNotEmpty()) {
                    add(LocalAutomation(
                        id = id,
                        name = name,
                        enabled = item.optBoolean("enabled", true),
                        matchAllConditions = item.optBoolean("matchAllConditions", true),
                        conditions = conditions,
                        actions = actions,
                        lastMatched = item.optBoolean("lastMatched", false),
                        lastTriggeredAt = item.optLong("lastTriggeredAt", 0L),
                        cooldownMinutes = item.optInt("cooldownMinutes", 2).coerceIn(0, 1440),
                        iconKey = item.optString("iconKey", "sparkles").ifBlank { "sparkles" }
                    ))
                }
            }
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun saveAutomations(context: Context, automations: List<LocalAutomation>) {
        val array = JSONArray()
        automations.forEach { automation ->
            val conditions = JSONArray()
            automation.conditions.forEach { c ->
                conditions.put(JSONObject().put("id", c.id).put("type", c.type)
                    .put("deviceId", c.deviceId).put("property", c.property)
                    .put("operator", c.operator).put("value", c.value)
                    .put("variableName", c.variableName).put("startTime", c.startTime).put("endTime", c.endTime)
                    .put("latitude", c.latitude).put("longitude", c.longitude))
            }
            val actions = JSONArray()
            automation.actions.forEach { a ->
                actions.put(JSONObject().put("id", a.id).put("type", a.type)
                    .put("deviceId", a.deviceId).put("enabled", a.enabled)
                    .put("brightness", a.brightness).put("variableName", a.variableName)
                    .put("variableValue", a.variableValue).put("scenarioId", a.scenarioId))
            }
            array.put(JSONObject().put("id", automation.id).put("name", automation.name)
                .put("enabled", automation.enabled).put("matchAllConditions", automation.matchAllConditions)
                .put("conditions", conditions).put("actions", actions)
                .put("lastMatched", automation.lastMatched).put("lastTriggeredAt", automation.lastTriggeredAt)
                .put("cooldownMinutes", automation.cooldownMinutes).put("iconKey", automation.iconKey))
        }
        prefs(context).edit().putString(KEY_AUTOMATIONS, array.toString()).apply()
    }

    @Synchronized
    fun saveAutomation(context: Context, automation: LocalAutomation) {
        val current = loadAutomations(context).filterNot { it.id == automation.id }
        saveAutomations(context, current + automation.copy(lastMatched = false))
    }

    @Synchronized
    fun deleteAutomation(context: Context, id: String) {
        saveAutomations(context, loadAutomations(context).filterNot { it.id == id })
    }

    @Synchronized
    fun setAutomationEnabled(context: Context, id: String, enabled: Boolean) {
        saveAutomations(context, loadAutomations(context).map { if (it.id == id) it.copy(enabled = enabled, lastMatched = false) else it })
    }

    /** Atomically latches a matching condition so a rule fires once per false -> true transition. */
    @Synchronized
    fun claimAutomaticRun(context: Context, id: String, matched: Boolean, now: Long = System.currentTimeMillis()): Boolean {
        var shouldRun = false
        val updated = loadAutomations(context).map { automation ->
            if (automation.id != id) automation else {
                val cooldownMs = automation.cooldownMinutes * 60_000L
                shouldRun = matched && !automation.lastMatched && now - automation.lastTriggeredAt >= cooldownMs
                automation.copy(lastMatched = matched, lastTriggeredAt = if (shouldRun) now else automation.lastTriggeredAt)
            }
        }
        saveAutomations(context, updated)
        return shouldRun
    }

    @Synchronized
    fun recordManualRun(context: Context, id: String) {
        val now = System.currentTimeMillis()
        saveAutomations(context, loadAutomations(context).map {
            if (it.id == id) it.copy(lastTriggeredAt = now) else it
        })
    }

    @Synchronized
    fun loadVariables(context: Context): List<GlobalVariable> = runCatching {
        val array = JSONArray(prefs(context).getString(KEY_VARIABLES, "[]") ?: "[]")
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val name = item.optString("name").trim()
                if (name.isNotBlank()) add(GlobalVariable(name, item.optString("value"), item.optLong("updatedAt")))
            }
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun saveVariable(context: Context, variable: GlobalVariable) {
        val updated = loadVariables(context).filterNot { it.name.equals(variable.name, ignoreCase = true) } + variable
        saveVariables(context, updated)
    }

    @Synchronized
    fun deleteVariable(context: Context, name: String) {
        saveVariables(context, loadVariables(context).filterNot { it.name.equals(name, ignoreCase = true) })
    }

    @Synchronized
    private fun saveVariables(context: Context, variables: List<GlobalVariable>) {
        val array = JSONArray()
        variables.forEach { array.put(JSONObject().put("name", it.name).put("value", it.value).put("updatedAt", it.updatedAt)) }
        prefs(context).edit().putString(KEY_VARIABLES, array.toString()).apply()
    }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}

/** Deterministic local rule evaluator. No sensor values or variables are sent to a third-party AI service. */
object LocalAutomationEngine {
    suspend fun evaluate(context: Context, api: YandexHomeApi, home: HomeData) {
        for (automation in LocalAutomationStore.loadAutomations(context)) {
            if (!automation.enabled) continue
            // Reload globals before each rule so a variable changed by an earlier rule
            // is visible to the next rule in the same evaluation cycle.
            val variables = LocalAutomationStore.loadVariables(context)
            val matches = matches(automation, home, variables)
            if (LocalAutomationStore.claimAutomaticRun(context, automation.id, matches)) {
                runCatching { executeActions(context, api, home, automation.actions) }
            }
        }
    }

    suspend fun runManually(context: Context, api: YandexHomeApi, home: HomeData, automationId: String) {
        val automation = LocalAutomationStore.loadAutomations(context).firstOrNull { it.id == automationId }
            ?: throw IllegalArgumentException("Сценарий не найден")
        executeActions(context, api, home, automation.actions)
        LocalAutomationStore.recordManualRun(context, automationId)
    }

    private suspend fun matches(automation: LocalAutomation, home: HomeData, variables: List<GlobalVariable>): Boolean {
        if (automation.conditions.isEmpty()) return false
        val results = automation.conditions.map { condition -> evaluateCondition(condition, home, variables) }
        return if (automation.matchAllConditions) results.all { it } else results.any { it }
    }

    private suspend fun evaluateCondition(condition: AutomationCondition, home: HomeData, variables: List<GlobalVariable>): Boolean {
        return when (condition.type) {
            AutomationConditionType.DEVICE_POWER -> {
                val device = home.devices.firstOrNull { it.id == condition.deviceId } ?: return false
                val actual = device.onOff ?: return false
                val expected = condition.value.toBooleanStrictOrNull() ?: return false
                actual == expected
            }
            AutomationConditionType.SENSOR_VALUE -> {
                val device = home.devices.firstOrNull { it.id == condition.deviceId } ?: return false
                val actual = device.properties.firstOrNull { it.instance == condition.property }?.value as? Number ?: return false
                val expected = condition.value.toDoubleOrNull() ?: return false
                compare(actual.toDouble(), expected, condition.operator)
            }
            AutomationConditionType.GLOBAL_VARIABLE -> {
                val actual = variables.firstOrNull { it.name.equals(condition.variableName, ignoreCase = true) }?.value ?: return false
                compareTextOrNumber(actual, condition.value, condition.operator)
            }
            AutomationConditionType.TIME_WINDOW -> {
                val start = runCatching { LocalTime.parse(condition.startTime) }.getOrNull() ?: return false
                val end = runCatching { LocalTime.parse(condition.endTime) }.getOrNull() ?: return false
                val now = LocalTime.now()
                if (start == end) true
                else if (start.isBefore(end)) !now.isBefore(start) && !now.isAfter(end)
                else !now.isBefore(start) || !now.isAfter(end)
            }
            AutomationConditionType.TIME_AT -> {
                val target = runCatching { LocalTime.parse(condition.startTime) }.getOrNull() ?: return false
                val now = LocalTime.now()
                // WorkManager can be delayed; accept the 15 minutes after the selected time.
                // A modulo-day calculation also handles a schedule that crosses midnight.
                val targetMinute = target.hour * 60 + target.minute
                val currentMinute = now.hour * 60 + now.minute
                (currentMinute - targetMinute + 24 * 60) % (24 * 60) <= 15
            }
            AutomationConditionType.WEATHER -> {
                if (condition.latitude !in -90.0..90.0 || condition.longitude !in -180.0..180.0) return false
                val actual = WeatherConditionReader.valueAt(condition.latitude, condition.longitude, condition.property) ?: return false
                val expected = condition.value.toDoubleOrNull() ?: return false
                compare(actual, expected, condition.operator)
            }
            else -> false
        }
    }

    private fun compare(actual: Double, expected: Double, operator: String): Boolean = when (operator) {
        ">" -> actual > expected
        ">=" -> actual >= expected
        "<" -> actual < expected
        "<=" -> actual <= expected
        "!=" -> actual != expected
        else -> abs(actual - expected) < 0.000001
    }

    private fun compareTextOrNumber(actual: String, expected: String, operator: String): Boolean {
        val aNumber = actual.toDoubleOrNull()
        val bNumber = expected.toDoubleOrNull()
        if (aNumber != null && bNumber != null) return compare(aNumber, bNumber, operator)
        val aBool = actual.toBooleanStrictOrNull()
        val bBool = expected.toBooleanStrictOrNull()
        if (aBool != null && bBool != null) return if (operator == "!=") aBool != bBool else aBool == bBool
        return if (operator == "!=") !actual.equals(expected, ignoreCase = true)
        else actual.equals(expected, ignoreCase = true)
    }

    private suspend fun executeActions(context: Context, api: YandexHomeApi, home: HomeData, actions: List<AutomationAction>) {
        for (action in actions) {
            when (action.type) {
                AutomationActionType.DEVICE_POWER -> {
                    val device = home.devices.firstOrNull { it.id == action.deviceId && it.canToggle } ?: continue
                    api.setOnOff(device.id, action.enabled)
                }
                AutomationActionType.BRIGHTNESS -> {
                    val device = home.devices.firstOrNull { it.id == action.deviceId && it.canDim } ?: continue
                    api.setBrightness(device.id, action.brightness.coerceIn(device.brightnessMin, device.brightnessMax))
                }
                AutomationActionType.SET_VARIABLE -> {
                    if (action.variableName.isNotBlank()) {
                        LocalAutomationStore.saveVariable(context, GlobalVariable(action.variableName.trim(), action.variableValue))
                    }
                }
                AutomationActionType.RUN_YANDEX_SCENARIO -> {
                    if (action.scenarioId.isNotBlank()) api.runScenario(action.scenarioId)
                }
            }
        }
    }
}


/** Public Open-Meteo current conditions; cached for 10 minutes to avoid frequent network requests. */
private object WeatherConditionReader {
    @Volatile private var cachedAt = 0L
    @Volatile private var cachedKey = ""
    @Volatile private var cachedValues: Map<String, Double> = emptyMap()

    suspend fun valueAt(latitude: Double, longitude: Double, metric: String): Double? = withContext(Dispatchers.IO) {
        val key = "${"%.3f".format(java.util.Locale.US, latitude)},${"%.3f".format(java.util.Locale.US, longitude)}"
        val now = System.currentTimeMillis()
        val values = if (cachedKey == key && now - cachedAt < 10 * 60_000L) cachedValues else {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m&timezone=auto"
            val connection = URL(url).openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = 8_000
                connection.readTimeout = 8_000
                connection.setRequestProperty("User-Agent", "YandexHomeWidgets-Android")
                if (connection.responseCode !in 200..299) return@withContext null
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val current = JSONObject(body).optJSONObject("current") ?: return@withContext null
                buildMap<String, Double> {
                    listOf("temperature_2m", "relative_humidity_2m", "precipitation", "wind_speed_10m").forEach { field ->
                        val value = current.optDouble(field, Double.NaN)
                        if (value.isFinite()) put(field, value)
                    }
                }.also {
                    cachedKey = key
                    cachedAt = now
                    cachedValues = it
                }
            } catch (_: Exception) {
                return@withContext null
            } finally {
                connection.disconnect()
            }
        }
        values[metric]
    }
}
