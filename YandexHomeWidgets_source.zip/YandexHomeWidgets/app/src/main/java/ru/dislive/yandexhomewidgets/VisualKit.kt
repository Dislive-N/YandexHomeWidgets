package ru.dislive.yandexhomewidgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private val GlyphLavender = Color(0xFFE9DFFF)

/** Lightweight line icons drawn in Compose so every device uses one consistent visual language. */
@Composable
fun SmartGlyph(
    kind: String,
    modifier: Modifier = Modifier,
    tint: Color = GlyphLavender
) {
    Canvas(modifier) {
        val scale = size.minDimension / 100f
        val sw = 6f * scale
        fun p(x: Float, y: Float) = Offset(x * scale, y * scale)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float, width: Float = sw) {
            drawLine(tint, p(x1, y1), p(x2, y2), strokeWidth = width, cap = StrokeCap.Round)
        }
        fun outline(x: Float, y: Float, w: Float, h: Float, radius: Float = 10f) {
            drawRoundRect(tint, p(x, y), Size(w * scale, h * scale), CornerRadius(radius * scale), style = Stroke(sw))
        }
        fun circle(cx: Float, cy: Float, r: Float, width: Float = sw, fill: Boolean = false) {
            drawCircle(tint, r * scale, p(cx, cy), style = if (fill) androidx.compose.ui.graphics.drawscope.Fill else Stroke(width))
        }
        fun path(points: List<Pair<Float, Float>>, closed: Boolean = false, width: Float = sw) {
            val shape = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) moveTo(point.first * scale, point.second * scale)
                    else lineTo(point.first * scale, point.second * scale)
                }
                if (closed) close()
            }
            drawPath(shape, tint, style = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }

        when (kind.lowercase()) {
            "light", "lamp", "bulb" -> {
                drawCircle(tint, 19f * scale, p(50f, 39f), style = Stroke(sw))
                line(40f, 57f, 60f, 57f); line(42f, 65f, 58f, 65f); line(45f, 73f, 55f, 73f)
                line(50f, 7f, 50f, 13f); line(15f, 39f, 22f, 39f); line(78f, 39f, 85f, 39f)
                line(25f, 15f, 30f, 20f); line(70f, 20f, 75f, 15f)
            }
            "socket", "plug", "outlet" -> {
                outline(18f, 13f, 64f, 74f, 14f)
                circle(39f, 44f, 5f); circle(61f, 44f, 5f)
                line(50f, 53f, 50f, 61f, 4f)
            }
            "switch", "relay" -> {
                outline(13f, 19f, 74f, 62f, 17f)
                drawRoundRect(tint, p(25f, 29f), Size(50f * scale, 42f * scale), CornerRadius(18f * scale), style = Stroke(sw))
                circle(57f, 50f, 13f, fill = true)
            }
            "curtain", "blinds" -> {
                line(15f, 18f, 85f, 18f)
                line(24f, 22f, 24f, 82f); line(40f, 22f, 40f, 82f); line(60f, 22f, 60f, 82f); line(76f, 22f, 76f, 82f)
                line(24f, 82f, 40f, 88f); line(76f, 82f, 60f, 88f)
            }
            "thermostat", "climate", "display" -> {
                outline(17f, 11f, 66f, 78f, 12f)
                outline(27f, 22f, 46f, 25f, 6f)
                line(34f, 62f, 66f, 62f, 4f); line(39f, 72f, 61f, 72f, 4f)
            }
            "speaker", "station", "column" -> {
                outline(28f, 10f, 44f, 80f, 16f)
                circle(50f, 53f, 13f); circle(50f, 53f, 5f, width = 4f * scale)
                circle(50f, 25f, 3f, fill = true); line(39f, 77f, 61f, 77f, 3.5f * scale)
            }
            "fan" -> {
                circle(50f, 50f, 7f, fill = true)
                path(listOf(48f to 42f, 37f to 15f, 27f to 18f, 29f to 38f, 43f to 49f), closed = true)
                path(listOf(57f to 48f, 81f to 37f, 78f to 27f, 58f to 29f, 51f to 43f), closed = true)
                path(listOf(48f to 57f, 59f to 82f, 69f to 78f, 67f to 58f, 53f to 51f), closed = true)
            }
            "button" -> {
                circle(50f, 50f, 34f)
                circle(50f, 50f, 18f, width = 4f * scale)
                circle(50f, 50f, 5f, width = 3f * scale, fill = true)
            }
            "clock", "history" -> {
                circle(50f, 50f, 38f, width = 6f * scale)
                line(50f, 50f, 50f, 27f, 6f * scale)
                line(50f, 50f, 68f, 60f, 6f * scale)
                circle(50f, 50f, 4f, width = 3f * scale, fill = true)
            }
            "meter" -> {
                drawArc(tint, 180f, 180f, false, p(14f, 17f), Size(72f * scale, 72f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                line(50f, 54f, 69f, 37f, 5f * scale); circle(50f, 54f, 5f, width = 3f * scale, fill = true)
                line(22f, 59f, 28f, 59f, 3f * scale); line(72f, 59f, 78f, 59f, 3f * scale)
            }
            "tv", "media", "display" -> {
                outline(9f, 18f, 82f, 57f, 8f)
                line(39f, 75f, 61f, 75f, 4f * scale); line(50f, 75f, 50f, 86f, 4f * scale)
                line(34f, 87f, 66f, 87f, 4f * scale)
            }
            "kettle" -> {
                path(listOf(25f to 39f, 32f to 26f, 69f to 26f, 77f to 39f, 73f to 79f, 28f to 79f, 25f to 39f), closed = true)
                path(listOf(77f to 45f, 89f to 40f, 85f to 61f, 75f to 59f))
                line(39f, 20f, 61f, 20f, 4f * scale); line(50f, 14f, 50f, 20f, 4f * scale)
                line(35f, 84f, 65f, 84f, 4f * scale)
            }
            "coffee" -> {
                outline(19f, 11f, 62f, 78f, 10f)
                line(29f, 28f, 71f, 28f, 4f * scale); line(30f, 40f, 70f, 40f, 4f * scale)
                path(listOf(33f to 53f, 62f to 53f, 62f to 65f, 33f to 65f, 33f to 53f))
                line(62f, 56f, 69f, 56f, 3f * scale)
            }
            "multicooker" -> {
                outline(17f, 25f, 66f, 55f, 16f)
                line(26f, 25f, 74f, 25f, 5f * scale); line(40f, 14f, 60f, 14f, 4f * scale)
                circle(50f, 50f, 15f); circle(50f, 50f, 4f, width = 3f * scale, fill = true)
                line(30f, 84f, 70f, 84f, 4f * scale)
            }
            "fridge" -> {
                outline(27f, 8f, 46f, 84f, 8f)
                line(28f, 42f, 72f, 42f, 4f * scale)
                line(63f, 20f, 63f, 34f, 4f * scale); line(63f, 51f, 63f, 70f, 4f * scale)
            }
            "dishwasher" -> {
                outline(13f, 14f, 74f, 72f, 8f)
                line(15f, 30f, 85f, 30f, 4f * scale); circle(25f, 22f, 2f, width = 3f * scale, fill = true)
                outline(23f, 40f, 54f, 34f, 4f)
            }
            "washing_machine" -> {
                outline(13f, 10f, 74f, 80f, 10f)
                line(15f, 30f, 85f, 30f, 4f * scale)
                circle(50f, 59f, 22f); circle(50f, 59f, 13f, width = 3f * scale)
                circle(28f, 20f, 2.5f, width = 3f * scale, fill = true)
                circle(40f, 20f, 2.5f, width = 3f * scale, fill = true)
            }
            "iron" -> {
                path(listOf(13f to 68f, 25f to 45f, 43f to 27f, 65f to 27f, 85f to 62f, 89f to 72f, 13f to 72f, 13f to 68f), closed = true)
                path(listOf(42f to 27f, 48f to 15f, 64f to 15f, 73f to 32f))
                line(24f, 79f, 78f, 79f, 4f * scale)
            }
            "pet_feeder" -> {
                outline(29f, 9f, 42f, 59f, 12f)
                line(35f, 25f, 65f, 25f, 3f * scale); line(35f, 38f, 65f, 38f, 3f * scale)
                path(listOf(17f to 70f, 83f to 70f, 74f to 88f, 26f to 88f, 17f to 70f), closed = true)
            }
            "fountain" -> {
                path(listOf(15f to 60f, 85f to 60f, 76f to 83f, 24f to 83f, 15f to 60f), closed = true)
                drawArc(tint, 190f, 160f, false, p(31f, 27f), Size(38f * scale, 38f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                line(50f, 12f, 50f, 24f, 4f * scale)
            }
            "purifier" -> {
                outline(27f, 8f, 46f, 84f, 12f)
                for (y in listOf(30f, 40f, 50f, 60f, 70f)) line(36f, y, 64f, y, 3f * scale)
                circle(50f, 19f, 3f, width = 3f * scale, fill = true)
            }
            "valve" -> {
                line(50f, 30f, 50f, 80f, 7f * scale)
                line(23f, 30f, 77f, 30f, 6f * scale)
                line(35f, 17f, 65f, 43f, 5f * scale); line(65f, 17f, 35f, 43f, 5f * scale)
                line(35f, 80f, 65f, 80f, 5f * scale)
            }
            "gas", "smoke" -> {
                drawArc(tint, 205f, 130f, false, p(13f, 38f), Size(74f * scale, 48f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                drawArc(tint, 185f, 140f, false, p(28f, 20f), Size(45f * scale, 45f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                line(50f, 58f, 50f, 70f, 5f * scale); circle(50f, 79f, 2.5f, fill = true)
            }
            "vibration" -> {
                path(listOf(10f to 50f, 22f to 50f, 29f to 30f, 39f to 70f, 49f to 30f, 59f to 70f, 69f to 30f, 78f to 50f, 90f to 50f), width = 7f * scale)
            }
            "camera" -> {
                outline(12f, 28f, 76f, 47f, 13f)
                path(listOf(28f to 28f, 37f to 17f, 63f to 17f, 72f to 28f))
                circle(50f, 52f, 16f); circle(50f, 52f, 7f, width = 4f * scale)
            }
            "lock", "locked" -> {
                outline(22f, 43f, 56f, 43f, 10f)
                val arc = Path().apply { moveTo(32f * scale, 44f * scale); lineTo(32f * scale, 31f * scale); cubicTo(32f * scale, 7f * scale, 68f * scale, 7f * scale, 68f * scale, 31f * scale); lineTo(68f * scale, 44f * scale) }
                drawPath(arc, tint, style = Stroke(sw, cap = StrokeCap.Round))
                circle(50f, 62f, 4f, fill = true); line(50f, 65f, 50f, 72f, 4f)
            }
            "door_open" -> {
                // Open doorway: visible frame plus a leaf rotated outward from the hinge.
                line(20f, 12f, 80f, 12f); line(20f, 12f, 20f, 89f); line(80f, 12f, 80f, 89f)
                line(20f, 89f, 80f, 89f, 4f * scale)
                path(listOf(20f to 20f, 58f to 31f, 58f to 86f, 20f to 89f))
                line(58f, 31f, 58f, 86f, 4f * scale)
                circle(49f, 59f, 2.7f, width = 3f * scale, fill = true)
            }
            "door_closed", "door" -> {
                // Closed door: simple, straight, front-facing door panel.
                line(27f, 10f, 73f, 10f, 4f * scale)
                line(27f, 10f, 27f, 90f, 4f * scale)
                line(73f, 10f, 73f, 90f, 4f * scale)
                line(27f, 90f, 73f, 90f, 4f * scale)
                line(34f, 17f, 66f, 17f, 3f * scale)
                line(34f, 83f, 66f, 83f, 3f * scale)
                circle(62f, 50f, 3f, width = 3f * scale, fill = true)
            }
            "speaker_mini" -> {
                outline(27f, 26f, 46f, 50f, 18f)
                line(39f, 68f, 61f, 68f, 3f * scale)
                circle(50f, 40f, 4f, width = 3f * scale, fill = true)
            }
            "speaker_light" -> {
                circle(50f, 52f, 31f)
                path(listOf(27f to 37f, 50f to 20f, 73f to 37f), width = 4f * scale)
                line(36f, 73f, 64f, 73f, 3f * scale)
                circle(50f, 51f, 5f, width = 3f * scale, fill = true)
            }
            "speaker_station" -> {
                outline(22f, 11f, 56f, 78f, 22f)
                circle(50f, 48f, 18f); circle(50f, 48f, 6f, width = 3f * scale)
                line(39f, 77f, 61f, 77f, 3f * scale)
            }
            "speaker_midi" -> {
                outline(23f, 19f, 54f, 64f, 22f)
                circle(50f, 49f, 13f); circle(50f, 49f, 4f, width = 3f * scale)
                line(38f, 73f, 62f, 73f, 3f * scale)
            }
            "speaker_max" -> {
                outline(20f, 8f, 60f, 84f, 17f)
                circle(50f, 35f, 16f); circle(50f, 35f, 5f, width = 3f * scale)
                circle(50f, 66f, 9f); line(37f, 78f, 63f, 78f, 3f * scale)
            }
            "speaker_duo" -> {
                outline(15f, 17f, 70f, 66f, 14f)
                outline(23f, 25f, 54f, 34f, 6f)
                line(32f, 71f, 68f, 71f, 4f * scale)
                circle(76f, 69f, 2.5f, width = 3f * scale, fill = true)
            }
            "speaker_street" -> {
                outline(28f, 12f, 44f, 76f, 18f)
                circle(50f, 48f, 15f); circle(50f, 48f, 5f, width = 3f * scale)
                line(39f, 75f, 61f, 75f, 4f * scale)
                line(35f, 22f, 65f, 22f, 3f * scale)
            }
            "temperature", "thermometer" -> {
                line(50f, 15f, 50f, 65f, 9f * scale); circle(50f, 72f, 14f, width = sw)
                line(50f, 43f, 50f, 72f, 5f * scale); line(62f, 26f, 70f, 26f, 3.5f * scale)
            }
            "humidity", "water", "leak" -> {
                val drop = Path().apply { moveTo(50f * scale, 10f * scale); cubicTo(42f * scale, 25f * scale, 23f * scale, 46f * scale, 23f * scale, 61f * scale); cubicTo(23f * scale, 80f * scale, 35f * scale, 90f * scale, 50f * scale, 90f * scale); cubicTo(65f * scale, 90f * scale, 77f * scale, 80f * scale, 77f * scale, 61f * scale); cubicTo(77f * scale, 46f * scale, 58f * scale, 25f * scale, 50f * scale, 10f * scale); close() }
                drawPath(drop, tint, style = Stroke(sw, join = StrokeJoin.Round))
                line(39f, 66f, 44f, 73f, 3.5f * scale)
            }
            "motion", "presence", "radar" -> {
                circle(50f, 50f, 7f, fill = true)
                drawArc(tint, -55f, 110f, false, p(23f, 23f), Size(54f * scale, 54f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                drawArc(tint, -55f, 110f, false, p(10f, 10f), Size(80f * scale, 80f * scale), style = Stroke(sw, cap = StrokeCap.Round))
            }
            "air", "leaf", "co2" -> {
                val leaf = Path().apply { moveTo(18f * scale, 75f * scale); cubicTo(20f * scale, 24f * scale, 55f * scale, 13f * scale, 83f * scale, 17f * scale); cubicTo(83f * scale, 58f * scale, 58f * scale, 85f * scale, 18f * scale, 75f * scale); close() }
                drawPath(leaf, tint, style = Stroke(sw, join = StrokeJoin.Round)); line(25f, 75f, 69f, 31f, 4f * scale)
            }
            "vacuum", "robot", "cleaner" -> {
                circle(50f, 53f, 34f); circle(50f, 53f, 7f, width = 4f * scale)
                line(22f, 40f, 78f, 40f, 4f * scale); circle(33f, 74f, 3f, width = 3f * scale, fill = true); circle(67f, 74f, 3f, width = 3f * scale, fill = true)
            }
            "moon", "night" -> {
                val moon = Path().apply { moveTo(67f * scale, 16f * scale); cubicTo(38f * scale, 14f * scale, 18f * scale, 38f * scale, 28f * scale, 63f * scale); cubicTo(40f * scale, 91f * scale, 78f * scale, 88f * scale, 87f * scale, 58f * scale); cubicTo(59f * scale, 75f * scale, 39f * scale, 49f * scale, 67f * scale, 16f * scale) }
                drawPath(moon, tint, style = Stroke(sw, join = StrokeJoin.Round))
            }
            "sun", "morning" -> {
                circle(50f, 50f, 18f)
                for (angle in 0 until 8) {
                    val rad = Math.toRadians(angle * 45.0)
                    line(50f + (29 * kotlin.math.cos(rad)).toFloat(), 50f + (29 * kotlin.math.sin(rad)).toFloat(), 50f + (39 * kotlin.math.cos(rad)).toFloat(), 50f + (39 * kotlin.math.sin(rad)).toFloat(), 4.5f * scale)
                }
            }
            "movie", "film" -> {
                outline(12f, 23f, 76f, 55f, 9f); line(12f, 39f, 88f, 39f, 3f * scale); line(12f, 62f, 88f, 62f, 3f * scale)
                line(30f, 23f, 30f, 39f, 3f * scale); line(70f, 23f, 70f, 39f, 3f * scale)
                path(listOf(43f to 45f, 43f to 58f, 58f to 51.5f, 43f to 45f), closed = true)
            }
            "shield", "security" -> {
                path(listOf(50f to 10f, 81f to 22f, 77f to 56f, 64f to 77f, 50f to 89f, 36f to 77f, 23f to 56f, 19f to 22f, 50f to 10f), closed = true)
                line(36f, 50f, 46f, 61f); line(46f, 61f, 66f, 38f)
            }
            "home", "house" -> {
                path(listOf(13f to 49f, 50f to 17f, 87f to 49f)); path(listOf(23f to 45f, 23f to 86f, 77f to 86f, 77f to 45f))
                outline(42f, 61f, 16f, 25f, 3f)
            }
            "power", "on" -> {
                drawArc(tint, 45f, 270f, false, p(15f, 15f), Size(70f * scale, 70f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                line(50f, 9f, 50f, 49f, 8f * scale)
            }
            "off" -> {
                drawArc(tint.copy(alpha = 0.6f), 45f, 270f, false, p(15f, 15f), Size(70f * scale, 70f * scale), style = Stroke(sw, cap = StrokeCap.Round))
                line(50f, 9f, 50f, 43f, 8f * scale)
            }
            "running", "loading" -> {
                drawArc(tint, 35f, 290f, false, p(17f, 17f), Size(66f * scale, 66f * scale), style = Stroke(sw, cap = StrokeCap.Round))
            }
            "pause" -> { line(39f, 24f, 39f, 76f, 9f * scale); line(61f, 24f, 61f, 76f, 9f * scale) }
            "play" -> path(listOf(35f to 20f, 79f to 50f, 35f to 80f, 35f to 20f), closed = true)
            "sparkles", "auto" -> {
                path(listOf(50f to 8f, 57f to 39f, 88f to 50f, 57f to 61f, 50f to 92f, 43f to 61f, 12f to 50f, 43f to 39f, 50f to 8f), closed = true)
                circle(79f, 19f, 5f, fill = true); circle(20f, 78f, 4f, fill = true)
            }
            else -> {
                outline(17f, 20f, 66f, 60f, 13f)
                circle(50f, 50f, 9f)
                line(50f, 29f, 50f, 35f, 4f * scale); line(50f, 65f, 50f, 71f, 4f * scale)
            }
        }
    }
}

@Composable
fun IconTile(
    kind: String,
    modifier: Modifier = Modifier.size(42.dp),
    iconSize: Dp = 25.dp,
    active: Boolean = false
) {
    val palette = when (kind.lowercase()) {
        "light", "lamp", "bulb", "sun", "illumination" -> listOf(Color(0xFFFFC857), Color(0xFFFF8A3D), Color(0xFFFFF3C4))
        "socket", "plug", "power", "switch", "relay" -> listOf(Color(0xFF54D6C5), Color(0xFF148F9C), Color(0xFFE0FFFA))
        "thermostat", "climate", "temperature", "humidity" -> listOf(Color(0xFFFF8A9B), Color(0xFFDB477A), Color(0xFFFFE5EC))
        "speaker", "speaker_mini", "speaker_light", "speaker_midi", "speaker_max", "speaker_duo", "speaker_street", "speaker_station" -> listOf(Color(0xFF9E8BFF), Color(0xFF6346D7), Color(0xFFF0E9FF))
        "curtain", "door_closed", "door_open", "lock", "valve" -> listOf(Color(0xFF65A9FF), Color(0xFF326DD1), Color(0xFFE5F1FF))
        "gas", "smoke", "leak", "motion", "vibration" -> listOf(Color(0xFFFF9D5C), Color(0xFFE06443), Color(0xFFFFEBDD))
        "tv", "media", "camera" -> listOf(Color(0xFF55B6FF), Color(0xFF3265C9), Color(0xFFE2F3FF))
        "vacuum", "cleaner" -> listOf(Color(0xFF7CDA9A), Color(0xFF2D9D76), Color(0xFFE5FFEF))
        "clock", "history" -> listOf(Color(0xFF69B8FF), Color(0xFF4365D6), Color(0xFFE5F1FF))
        "home", "sparkles", "auto" -> listOf(Color(0xFFC18AFF), Color(0xFF7546C8), Color(0xFFF5E9FF))
        else -> listOf(Color(0xFF70C7FF), Color(0xFF5A63D9), Color(0xFFE7F4FF))
    }
    val background = if (active) {
        listOf(palette[0].copy(alpha = 0.96f), palette[1].copy(alpha = 0.96f))
    } else {
        listOf(palette[0].copy(alpha = 0.25f), palette[1].copy(alpha = 0.22f))
    }
    Box(
        modifier = modifier.background(Brush.linearGradient(background), RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        SmartGlyph(kind, Modifier.size(iconSize.coerceAtMost(28.dp)), palette[2])
    }
}

fun deviceIconKind(type: String, name: String = ""): String {
    val typeKey = type.lowercase().removePrefix("devices.types.")
    val nameKey = name.lowercase()
    val speaker = typeKey.contains("smart_speaker") || typeKey.contains("speaker") || nameKey.contains("станция") || nameKey.contains("колонка") || nameKey.contains("яндекс лайт")
    return when {
        speaker && listOf("мини 3 про", "мини 3 pro", "мини 3", "mini 3", "мини 2", "mini 2", "станция мини").any(nameKey::contains) -> "speaker_mini"
        speaker && listOf("станция лайт", "лайт 2", "лайт", "light 2", "light").any(nameKey::contains) -> "speaker_light"
        speaker && listOf("миди", "midi").any(nameKey::contains) -> "speaker_midi"
        speaker && listOf("макс", "max").any(nameKey::contains) -> "speaker_max"
        speaker && listOf("дуо", "duo").any(nameKey::contains) -> "speaker_duo"
        speaker && listOf("стрит", "street").any(nameKey::contains) -> "speaker_street"
        speaker && listOf("станция 2", "станция 3", "station 2", "station 3").any(nameKey::contains) -> "speaker_station"
        speaker -> "speaker"
        typeKey.startsWith("openable.curtain") -> "curtain"
        typeKey.startsWith("openable.valve") -> "valve"
        typeKey.startsWith("openable.door_lock") -> "lock"
        typeKey.startsWith("sensor.open") || typeKey == "openable" -> "door_closed"
        typeKey.startsWith("sensor.button") -> "button"
        typeKey.startsWith("sensor.climate") -> "thermostat"
        typeKey.startsWith("sensor.gas") -> "gas"
        typeKey.startsWith("sensor.illumination") -> "sun"
        typeKey.startsWith("sensor.motion") -> "motion"
        typeKey.startsWith("sensor.smoke") -> "smoke"
        typeKey.startsWith("sensor.vibration") -> "vibration"
        typeKey.startsWith("sensor.water_leak") -> "leak"
        typeKey.startsWith("sensor") -> "motion"
        typeKey.startsWith("smart_meter") -> "meter"
        typeKey.startsWith("media_device.tv") || typeKey.startsWith("media_device.tv_box") -> "tv"
        typeKey.startsWith("media_device") -> "media"
        typeKey.startsWith("cooking.coffee_maker") -> "coffee"
        typeKey.startsWith("cooking.kettle") -> "kettle"
        typeKey.startsWith("cooking.multicooker") -> "multicooker"
        typeKey.startsWith("cooking") -> "fridge"
        typeKey.startsWith("dishwasher") -> "dishwasher"
        typeKey.startsWith("iron") -> "iron"
        typeKey.startsWith("vacuum_cleaner") || typeKey.contains("vacuum") -> "vacuum"
        typeKey.startsWith("washing_machine") -> "washing_machine"
        typeKey.startsWith("pet_drinking_fountain") -> "fountain"
        typeKey.startsWith("pet_feeder") -> "pet_feeder"
        typeKey.startsWith("humidifier") -> "humidity"
        typeKey.startsWith("purifier") -> "purifier"
        typeKey.startsWith("thermostat.ac") -> "climate"
        typeKey.startsWith("thermostat") -> "thermostat"
        typeKey.startsWith("ventilation.fan") -> "fan"
        typeKey.startsWith("ventilation") -> "air"
        typeKey.startsWith("light.strip") -> "light"
        typeKey.startsWith("light") -> "light"
        typeKey.startsWith("socket") -> "socket"
        typeKey.startsWith("switch.relay") -> "switch"
        typeKey.startsWith("switch") -> "switch"
        typeKey.startsWith("camera") -> "camera"
        typeKey.startsWith("other") -> "home"
        "light" in nameKey || "ламп" in nameKey -> "light"
        "socket" in nameKey || "розет" in nameKey -> "socket"
        "lock" in nameKey || "замок" in nameKey -> "lock"
        "camera" in nameKey || "камер" in nameKey -> "camera"
        else -> "home"
    }
}

fun scenarioIconKind(name: String): String {
    val value = name.lowercase()
    return when {
        listOf("ноч", "сон", "спат", "night").any(value::contains) -> "moon"
        listOf("утр", "рассвет", "morning").any(value::contains) -> "sun"
        listOf("кино", "фильм", "movie", "тв").any(value::contains) -> "movie"
        listOf("охран", "безопас", "alarm", "охран").any(value::contains) -> "shield"
        listOf("уход", "выш", "никого", "away").any(value::contains) -> "lock"
        listOf("домой", "приход", "home").any(value::contains) -> "home"
        listOf("свет", "ламп", "подсвет").any(value::contains) -> "light"
        listOf("уборк", "пылесос", "clean").any(value::contains) -> "vacuum"
        listOf("колон", "музык", "станц", "music").any(value::contains) -> "speaker"
        listOf("температур", "обогрев", "тепл").any(value::contains) -> "temperature"
        listOf("двер", "замок").any(value::contains) -> "lock"
        else -> "sparkles"
    }
}
