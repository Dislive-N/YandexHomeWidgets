package ru.dislive.yandexhomewidgets.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class HomeCapability(
    val type: String,
    val instance: String,
    val value: Any?,
    val min: Int = 0,
    val max: Int = 100,
    val reportable: Boolean = false,
    val retrievable: Boolean = true,
    val lastUpdated: Double = 0.0
)

data class HomeProperty(
    val type: String,
    val instance: String,
    val value: Any?,
    val reportable: Boolean = false,
    val retrievable: Boolean = true,
    val lastUpdated: Double = 0.0
)

data class HomeDevice(
    val id: String,
    val name: String,
    val room: String,
    val type: String,
    val capabilities: List<HomeCapability>,
    val properties: List<HomeProperty>,
    val onOff: Boolean?,
    val brightness: Int?,
    val brightnessMin: Int = 0,
    val brightnessMax: Int = 100,
    val isFavorite: Boolean = false
) {
    val canToggle: Boolean get() = capabilities.any { it.type == "devices.capabilities.on_off" && it.instance == "on" }
    val canDim: Boolean get() = capabilities.any { it.type == "devices.capabilities.range" && it.instance == "brightness" }
}

data class HomeScenario(val id: String, val name: String, val isActive: Boolean)
data class HomeGroup(val id: String, val name: String, val deviceIds: List<String> = emptyList())
data class HomeData(
    val devices: List<HomeDevice>,
    val scenarios: List<HomeScenario>,
    val groups: List<HomeGroup>,
    /** Original user/info response used for complete change detection. */
    val apiSnapshot: String = "{}"
)

class YandexHomeApi(private val accessToken: String) {
    suspend fun getHome(): HomeData = withContext(Dispatchers.IO) {
        val root = request("GET", "/v1.0/user/info", null)
        val rooms = mutableMapOf<String, String>()
        val roomArray = root.optJSONArray("rooms") ?: JSONArray()
        for (i in 0 until roomArray.length()) {
            val room = roomArray.optJSONObject(i) ?: continue
            val roomId = room.optString("id")
            val name = room.optString("name")
            if (roomId.isNotBlank() && name.isNotBlank()) rooms[roomId] = name
        }

        val devices = mutableListOf<HomeDevice>()
        val deviceArray = root.optJSONArray("devices") ?: JSONArray()
        for (i in 0 until deviceArray.length()) {
            val obj = deviceArray.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isBlank()) continue
            val roomId = obj.optString("room").takeUnless { it == "null" }
                ?: obj.optJSONObject("room")?.optString("id").orEmpty()

            val capabilities = mutableListOf<HomeCapability>()
            var onOff: Boolean? = null
            var brightness: Int? = null
            var brightnessMin = 0
            var brightnessMax = 100
            val capArray = obj.optJSONArray("capabilities") ?: JSONArray()
            for (j in 0 until capArray.length()) {
                val cap = capArray.optJSONObject(j) ?: continue
                val type = cap.optString("type")
                val state = cap.optJSONObject("state")
                val params = cap.optJSONObject("parameters")
                val instance = state?.optString("instance")?.takeIf { it.isNotBlank() }
                    ?: params?.optString("instance").orEmpty()
                val value = state?.opt("value")?.takeUnless { it === JSONObject.NULL }
                val range = params?.optJSONObject("range") ?: params
                val min = range?.optInt("min", 0) ?: 0
                val max = range?.optInt("max", 100) ?: 100
                capabilities += HomeCapability(
                    type = type,
                    instance = instance,
                    value = value,
                    min = min,
                    max = max,
                    reportable = cap.optBoolean("reportable", false),
                    retrievable = cap.optBoolean("retrievable", true),
                    lastUpdated = cap.optDouble("last_updated", 0.0)
                )
                if (type == "devices.capabilities.on_off" && instance == "on" && value is Boolean) onOff = value
                if (type == "devices.capabilities.range" && instance == "brightness" && value is Number) {
                    brightness = value.toInt()
                    brightnessMin = min
                    brightnessMax = max
                }
            }

            val properties = mutableListOf<HomeProperty>()
            val propertyArray = obj.optJSONArray("properties") ?: JSONArray()
            for (j in 0 until propertyArray.length()) {
                val property = propertyArray.optJSONObject(j) ?: continue
                val state = property.optJSONObject("state")
                val params = property.optJSONObject("parameters")
                val instance = state?.optString("instance")?.takeIf { it.isNotBlank() }
                    ?: params?.optString("instance").orEmpty()
                val value = state?.opt("value")?.takeUnless { it === JSONObject.NULL }
                properties += HomeProperty(
                    type = property.optString("type"),
                    instance = instance,
                    value = value,
                    reportable = property.optBoolean("reportable", false),
                    retrievable = property.optBoolean("retrievable", true),
                    lastUpdated = property.optDouble("last_updated", 0.0)
                )
            }

            devices += HomeDevice(
                id = id,
                name = obj.optString("name").ifBlank { "Устройство" },
                room = rooms[roomId] ?: roomId,
                type = obj.optString("type"),
                capabilities = capabilities,
                properties = properties,
                onOff = onOff,
                brightness = brightness,
                brightnessMin = brightnessMin,
                brightnessMax = brightnessMax
            )
        }

        val scenarios = mutableListOf<HomeScenario>()
        val scenarioArray = root.optJSONArray("scenarios") ?: JSONArray()
        for (i in 0 until scenarioArray.length()) {
            val obj = scenarioArray.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isNotBlank()) scenarios += HomeScenario(id, obj.optString("name").ifBlank { "Сценарий" }, obj.optBoolean("is_active", false))
        }

        val groups = mutableListOf<HomeGroup>()
        val groupArray = root.optJSONArray("groups") ?: JSONArray()
        for (i in 0 until groupArray.length()) {
            val obj = groupArray.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isNotBlank()) {
                val members = obj.optJSONArray("devices") ?: JSONArray()
                val deviceIds = (0 until members.length()).mapNotNull { members.optString(it).takeIf(String::isNotBlank) }
                groups += HomeGroup(id, obj.optString("name").ifBlank { "Группа" }, deviceIds)
            }
        }
        HomeData(devices, scenarios, groups, root.toString())
    }

    suspend fun setOnOff(deviceId: String, value: Boolean) = withContext(Dispatchers.IO) {
        val action = JSONObject().put("type", "devices.capabilities.on_off")
            .put("state", JSONObject().put("instance", "on").put("value", value))
        val device = JSONObject().put("id", deviceId).put("actions", JSONArray().put(action))
        request("POST", "/v1.0/devices/actions", JSONObject().put("devices", JSONArray().put(device)))
    }

    suspend fun setBrightness(deviceId: String, value: Int) = withContext(Dispatchers.IO) {
        val action = JSONObject().put("type", "devices.capabilities.range")
            .put("state", JSONObject().put("instance", "brightness").put("value", value))
        val device = JSONObject().put("id", deviceId).put("actions", JSONArray().put(action))
        request("POST", "/v1.0/devices/actions", JSONObject().put("devices", JSONArray().put(device)))
    }

    suspend fun runScenario(scenarioId: String) = withContext(Dispatchers.IO) {
        request("POST", "/v1.0/scenarios/$scenarioId/actions", JSONObject())
    }

    private fun request(method: String, path: String, body: JSONObject?): JSONObject {
        val connection = URL("https://api.iot.yandex.net$path").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val details = try {
                    val json = JSONObject(responseText)
                    json.optString("message").ifBlank { json.optString("error").ifBlank { responseText } }
                } catch (_: Exception) { responseText }
                throw IOException("Яндекс API ($code): ${details.ifBlank { "не удалось выполнить запрос" }}")
            }
            return if (responseText.isBlank()) JSONObject() else JSONObject(responseText)
        } finally {
            connection.disconnect()
        }
    }
}
