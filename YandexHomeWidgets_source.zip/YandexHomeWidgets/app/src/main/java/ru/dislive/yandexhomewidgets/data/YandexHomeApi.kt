package ru.dislive.yandexhomewidgets.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class HomeCapability(
    val type: String,
    val instance: String,
    val value: Any?,
    val min: Int = 0,
    val max: Int = 100,
    val reportable: Boolean = false,
    val retrievable: Boolean = true,
    val lastUpdated: Double = 0.0,
    val colorModel: String? = null,
    val temperatureMin: Int = 2000,
    val temperatureMax: Int = 9000,
    val temperatureSupported: Boolean = false,
    val colorScenes: List<String> = emptyList(),
    val modeOptions: List<String> = emptyList()
)

data class HomeProperty(
    val type: String,
    val instance: String,
    val value: Any?,
    val reportable: Boolean = false,
    val retrievable: Boolean = true,
    val lastUpdated: Double = 0.0
)

data class HomeDevice(
    val id: String,
    val name: String,
    val room: String,
    val type: String,
    val capabilities: List<HomeCapability>,
    val properties: List<HomeProperty>,
    val onOff: Boolean?,
    val brightness: Int?,
    val brightnessMin: Int = 0,
    val brightnessMax: Int = 100,
    val isFavorite: Boolean = false
) {
    val canToggle: Boolean get() = capabilities.any { it.type == "devices.capabilities.on_off" && (it.instance.isBlank() || it.instance == "on") }
    val canDim: Boolean get() = capabilities.any { it.type == "devices.capabilities.range" && it.instance == "brightness" }
    val colorCapability: HomeCapability? get() = capabilities.firstOrNull { it.type == "devices.capabilities.color_setting" }
    val modeCapabilities: List<HomeCapability> get() = capabilities.filter { it.type == "devices.capabilities.mode" && it.modeOptions.isNotEmpty() }
}

data class HomeScenario(val id: String, val name: String, val isActive: Boolean)
data class HomeGroup(val id: String, val name: String, val deviceIds: List<String> = emptyList())
data class HomeData(
    val devices: List<HomeDevice>,
    val scenarios: List<HomeScenario>,
    val groups: List<HomeGroup>,
    val rooms: List<String> = emptyList(),
    /** Combined home metadata and per-device state response used for change detection. */
    val apiSnapshot: String = "{}"
)

class YandexHomeApi(private val accessToken: String) {
    suspend fun getHome(): HomeData = withContext(Dispatchers.IO) {
        val root = request("GET", "/v1.0/user/info", null)
        val rooms = mutableMapOf<String, String>()
        val roomArray = root.optJSONArray("rooms") ?: JSONArray()
        val roomNames = mutableListOf<String>()
        for (i in 0 until roomArray.length()) {
            val room = roomArray.optJSONObject(i) ?: continue
            val roomId = room.optString("id")
            val name = room.optString("name")
            if (roomId.isNotBlank() && name.isNotBlank()) {
                rooms[roomId] = name
                roomNames += name
            }
        }

        val devices = mutableListOf<HomeDevice>()
        val deviceArray = root.optJSONArray("devices") ?: JSONArray()
        val baseDevices = (0 until deviceArray.length()).mapNotNull { deviceArray.optJSONObject(it) }
            .filter { it.optString("id").isNotBlank() }
        // user/info returns the home structure; current readings and capability states
        // are obtained from the dedicated per-device status endpoint.
        val deviceDetails = coroutineScope {
            val requestLimit = Semaphore(5)
            baseDevices.map { base ->
                async(Dispatchers.IO) {
                    requestLimit.withPermit {
                        val id = base.optString("id")
                        val encodedId = java.net.URLEncoder.encode(id, "UTF-8").replace("+", "%20")
                        val details = runCatching { request("GET", "/v1.0/devices/$encodedId", null) }.getOrNull()
                        base to (details ?: base)
                    }
                }
            }.awaitAll()
        }
        val snapshotDevices = JSONArray()
        for ((base, obj) in deviceDetails) {
            snapshotDevices.put(obj)
            val id = base.optString("id")
            val roomValue = obj.opt("room")?.takeUnless { it === JSONObject.NULL } ?: base.opt("room")
            val roomId = when (roomValue) {
                is JSONObject -> roomValue.optString("id")
                null, JSONObject.NULL -> ""
                else -> roomValue.toString().takeUnless { it == "null" }.orEmpty()
            }

            val capabilities = mutableListOf<HomeCapability>()
            var onOff: Boolean? = null
            var brightness: Int? = null
            var brightnessMin = 0
            var brightnessMax = 100
            // Some Yandex responses omit capability metadata in the detail object.
            // Keep the capabilities from /user/info in that case so the power button remains available.
            val detailedCapabilities = obj.optJSONArray("capabilities")
            val capArray = detailedCapabilities?.takeIf { it.length() > 0 }
                ?: base.optJSONArray("capabilities") ?: JSONArray()
            for (j in 0 until capArray.length()) {
                val cap = capArray.optJSONObject(j) ?: continue
                val type = cap.optString("type")
                val state = cap.optJSONObject("state")
                val params = cap.optJSONObject("parameters") ?: JSONObject()
                val instance = state?.optString("instance")?.takeIf { it.isNotBlank() }
                    ?: params.optString("instance").takeIf { it.isNotBlank() }
                    ?: if (type == "devices.capabilities.on_off") "on" else ""
                val value = state?.opt("value")?.takeUnless { it === JSONObject.NULL }
                val range = params.optJSONObject("range")
                val min = range?.optInt("min", 0) ?: params.optInt("min", 0)
                val max = range?.optInt("max", 100) ?: params.optInt("max", 100)

                val temperature = params.optJSONObject("temperature_k")
                val sceneArray = params.optJSONObject("color_scene")?.optJSONArray("scenes") ?: JSONArray()
                val colorScenes = (0 until sceneArray.length()).mapNotNull { index ->
                    sceneArray.optJSONObject(index)?.optString("id")?.takeIf(String::isNotBlank)
                }
                val modesArray = params.optJSONArray("modes") ?: JSONArray()
                val modeOptions = (0 until modesArray.length()).mapNotNull { index ->
                    modesArray.optJSONObject(index)?.optString("value")?.takeIf(String::isNotBlank)
                }
                capabilities += HomeCapability(
                    type = type,
                    instance = instance,
                    value = value,
                    min = min,
                    max = max,
                    reportable = cap.optBoolean("reportable", false),
                    retrievable = cap.optBoolean("retrievable", true),
                    lastUpdated = cap.optDouble("last_updated", 0.0),
                    colorModel = params.optString("color_model").takeIf { it == "rgb" || it == "hsv" },
                    temperatureMin = temperature?.optInt("min", 2000) ?: 2000,
                    temperatureMax = temperature?.optInt("max", 9000) ?: 9000,
                    temperatureSupported = temperature != null,
                    colorScenes = colorScenes,
                    modeOptions = modeOptions
                )
                if (type == "devices.capabilities.on_off" && instance == "on" && value is Boolean) onOff = value
                if (type == "devices.capabilities.range" && instance == "brightness" && value is Number) {
                    brightness = value.toInt()
                    brightnessMin = min
                    brightnessMax = max
                }
            }

            val properties = mutableListOf<HomeProperty>()
            val detailedProperties = obj.optJSONArray("properties")
            val propertyArray = detailedProperties?.takeIf { it.length() > 0 }
                ?: base.optJSONArray("properties") ?: JSONArray()
            for (j in 0 until propertyArray.length()) {
                val property = propertyArray.optJSONObject(j) ?: continue
                val state = property.optJSONObject("state")
                val params = property.optJSONObject("parameters")
                val instance = state?.optString("instance")?.takeIf { it.isNotBlank() }
                    ?: params?.optString("instance").orEmpty()
                val value = state?.opt("value")?.takeUnless { it === JSONObject.NULL }
                properties += HomeProperty(
                    type = property.optString("type"),
                    instance = instance,
                    value = value,
                    reportable = property.optBoolean("reportable", false),
                    retrievable = property.optBoolean("retrievable", true),
                    lastUpdated = property.optDouble("last_updated", 0.0)
                )
            }

            devices += HomeDevice(
                id = id,
                name = obj.optString("name").ifBlank { base.optString("name").ifBlank { "Устройство" } },
                room = rooms[roomId] ?: roomId,
                type = obj.optString("type").ifBlank { base.optString("type") },
                capabilities = capabilities,
                properties = properties,
                onOff = onOff,
                brightness = brightness,
                brightnessMin = brightnessMin,
                brightnessMax = brightnessMax
            )
        }

        val scenarios = mutableListOf<HomeScenario>()
        val scenarioArray = root.optJSONArray("scenarios") ?: JSONArray()
        for (i in 0 until scenarioArray.length()) {
            val obj = scenarioArray.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isNotBlank()) scenarios += HomeScenario(id, obj.optString("name").ifBlank { "Сценарий" }, obj.optBoolean("is_active", false))
        }

        val groups = mutableListOf<HomeGroup>()
        val groupArray = root.optJSONArray("groups") ?: JSONArray()
        for (i in 0 until groupArray.length()) {
            val obj = groupArray.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isNotBlank()) {
                val members = obj.optJSONArray("devices") ?: JSONArray()
                val deviceIds = (0 until members.length()).mapNotNull { members.optString(it).takeIf(String::isNotBlank) }
                groups += HomeGroup(id, obj.optString("name").ifBlank { "Группа" }, deviceIds)
            }
        }
        val snapshot = JSONObject(root.toString()).put("devices", snapshotDevices)
        HomeData(devices, scenarios, groups, roomNames.distinct(), snapshot.toString())
    }

    suspend fun setOnOff(deviceId: String, value: Boolean) = setCapability(
        deviceId, "devices.capabilities.on_off", "on", value
    )

    /** Send one Yandex API request for all switchable members of a local group. */
    suspend fun setOnOffBulk(deviceIds: List<String>, value: Boolean) = withContext(Dispatchers.IO) {
        val devices = JSONArray()
        deviceIds.distinct().forEach { id ->
            val action = JSONObject().put("type", "devices.capabilities.on_off")
                .put("state", JSONObject().put("instance", "on").put("value", value))
            devices.put(JSONObject().put("id", id).put("actions", JSONArray().put(action)))
        }
        if (devices.length() == 0) return@withContext
        request("POST", "/v1.0/devices/actions", JSONObject().put("devices", devices))
    }

    suspend fun setBrightness(deviceId: String, value: Int) = setCapability(
        deviceId, "devices.capabilities.range", "brightness", value
    )

    suspend fun setColorRgb(deviceId: String, rgb: Int) = setCapability(
        deviceId, "devices.capabilities.color_setting", "rgb", rgb.coerceIn(0, 0xFFFFFF)
    )

    suspend fun setColorHsv(deviceId: String, hue: Int, saturation: Int = 100, value: Int = 100) {
        val hsv = JSONObject().put("h", hue.coerceIn(0, 360))
            .put("s", saturation.coerceIn(0, 100)).put("v", value.coerceIn(0, 100))
        setCapability(deviceId, "devices.capabilities.color_setting", "hsv", hsv)
    }

    suspend fun setColorTemperature(deviceId: String, kelvin: Int) = setCapability(
        deviceId, "devices.capabilities.color_setting", "temperature_k", kelvin
    )

    suspend fun setColorScene(deviceId: String, sceneId: String) = setCapability(
        deviceId, "devices.capabilities.color_setting", "scene", sceneId
    )

    suspend fun setMode(deviceId: String, instance: String, modeValue: String) = setCapability(
        deviceId, "devices.capabilities.mode", instance, modeValue
    )

    suspend fun runScenario(scenarioId: String) = withContext(Dispatchers.IO) {
        request("POST", "/v1.0/scenarios/$scenarioId/actions", JSONObject())
    }

    private suspend fun setCapability(deviceId: String, type: String, instance: String, value: Any) = withContext(Dispatchers.IO) {
        val action = JSONObject().put("type", type)
            .put("state", JSONObject().put("instance", instance).put("value", value))
        val device = JSONObject().put("id", deviceId).put("actions", JSONArray().put(action))
        request("POST", "/v1.0/devices/actions", JSONObject().put("devices", JSONArray().put(device)))
    }

    private fun request(method: String, path: String, body: JSONObject?): JSONObject {
        val connection = URL("https://api.iot.yandex.net$path").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val details = try {
                    val json = JSONObject(responseText)
                    json.optString("message").ifBlank { json.optString("error").ifBlank { responseText } }
                } catch (_: Exception) { responseText }
                throw IOException("Яндекс API ($code): ${details.ifBlank { "не удалось выполнить запрос" }}")
            }
            return if (responseText.isBlank()) JSONObject() else JSONObject(responseText)
        } finally {
            connection.disconnect()
        }
    }
}
