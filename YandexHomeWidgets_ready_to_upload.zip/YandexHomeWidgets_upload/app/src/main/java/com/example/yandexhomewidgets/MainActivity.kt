package com.example.yandexhomewidgets

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16, 20, 28))
        }

        val title = TextView(this).apply {
            text = "Умный дом"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Проект подготовлен к автоматической сборке APK через GitHub Actions.\n\nПодключение к Яндекс Умному дому и интерактивные виджеты ещё требуют реализации и проверки — эта сборка пока является техническим каркасом, а не готовым управляющим приложением."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        page.addView(title)
        page.addView(subtitle)
        setContentView(page)
    }
}
